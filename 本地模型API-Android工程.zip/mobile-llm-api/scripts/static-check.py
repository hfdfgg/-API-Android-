#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Repository consistency check — no Android SDK required.

    python3 scripts/static-check.py

Checks:
  1. Java core compiles and its --help smoke path exits cleanly
  2. Python / shell / workflow YAML files parse
  3. every @string/@color/@style/@xml/@drawable/@mipmap reference in the
     AndroidManifest resolves to a real resource file
  4. every R.xxx.yyy reference in Kotlin resolves to a declared resource
  5. Gradle version-catalog aliases used by build scripts are all declared
  6. package declarations match directory layout
  7. no real-looking API key or keystore is committed
"""
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "app", "src", "main", "res")
JAVA = os.path.join(ROOT, "app", "src", "main", "java", "com", "yuanbao",
                    "localmodel", "server", "LocalApiServer.java")

rows = []


def check(name, ok, detail=""):
    rows.append((name, bool(ok), detail))
    print(("[PASS] " if ok else "[FAIL] ") + name.ljust(52) + " " + str(detail))
    return ok


def walk(ext):
    out = []
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in (".git", ".gradle", "build", ".idea")]
        for f in files:
            if f.endswith(ext):
                out.append(os.path.join(base, f))
    return out


# ---------------------------------------------------------------- 1. Java
try:
    p = subprocess.run(["java", JAVA, "--help"], capture_output=True,
                       text=True, timeout=40, cwd=ROOT)
    check("Java 核心源码编译 + 冒烟", p.returncode == 0 and "Usage:" in p.stdout,
          "rc=%d" % p.returncode)
except Exception as e:
    check("Java 核心源码编译 + 冒烟", False, str(e))

# ---------------------------------------------------------------- 2. syntax
for py in walk(".py"):
    try:
        with open(py, "r", encoding="utf-8") as f:
            compile(f.read(), py, "exec")
        check("Python 语法 " + os.path.relpath(py, ROOT), True)
    except SyntaxError as e:
        check("Python 语法 " + os.path.relpath(py, ROOT), False, "line %s" % e.lineno)

for sh in walk(".sh") + [os.path.join(ROOT, "gradlew")]:
    if not os.path.isfile(sh):
        continue
    r = subprocess.run(["sh", "-n", sh], capture_output=True, text=True)
    check("Shell 语法 " + os.path.relpath(sh, ROOT), r.returncode == 0,
          r.stderr.strip()[:120])

try:
    import yaml  # noqa
    for y in walk(".yml") + walk(".yaml"):
        try:
            with open(y, "r", encoding="utf-8") as f:
                yaml.safe_load(f)
            check("YAML 语法 " + os.path.relpath(y, ROOT), True)
        except Exception as e:
            check("YAML 语法 " + os.path.relpath(y, ROOT), False, str(e)[:120])
except ImportError:
    check("YAML 解析（PyYAML 可用）", True, "跳过：环境未安装 PyYAML")

# ---------------------------------------------------------------- 3. resources
res_names = {}
for base, _, files in os.walk(RES):
    for f in files:
        path = os.path.join(base, f)
        folder = os.path.basename(base).split("-")[0]
        stem = f.rsplit(".", 1)[0]
        if f.endswith(".xml"):
            try:
                root = ET.parse(path).getroot()
                if root.tag == "resources":
                    # <string name="x"/> -> type "string", etc.
                    for node in root:
                        key = node.get("name")
                        if key:
                            res_names.setdefault(node.tag, set()).add(key)
                else:
                    # vector drawables / adaptive icons / xml configs are
                    # referenced by filename, not by an inner name attribute.
                    res_names.setdefault(folder, set()).add(stem)
            except ET.ParseError as e:
                check("资源 XML 解析 " + os.path.relpath(path, ROOT), False, str(e))
        else:
            res_names.setdefault(folder, set()).add(stem)

manifest = os.path.join(ROOT, "app", "src", "main", "AndroidManifest.xml")
try:
    text = open(manifest, "r", encoding="utf-8").read()
    refs = re.findall(r'"@(string|color|style|xml|drawable|mipmap)/([A-Za-z0-9_]+)"', text)
    missing = ["%s/%s" % (t, n) for t, n in refs if n not in res_names.get(t, set())]
    check("Manifest 资源引用全部可解析", not missing,
          "%d 个引用，缺失 %s" % (len(refs), missing or "无"))
    ET.parse(manifest)
    check("AndroidManifest.xml 格式合法", True)
except Exception as e:
    check("AndroidManifest.xml 格式合法", False, str(e))

# ---------------------------------------------------------------- 4. R.* refs
kt_refs = []
for kt in walk(".kt"):
    src = open(kt, "r", encoding="utf-8").read()
    for typ, name in re.findall(r"\bR\.(string|drawable|color|style|xml|mipmap)\.([A-Za-z0-9_]+)", src):
        kt_refs.append((typ, name, os.path.relpath(kt, ROOT)))
missing_r = ["%s.%s (%s)" % (t, n, f) for t, n, f in kt_refs
             if n not in res_names.get(t, set())]
check("Kotlin R.* 引用全部可解析", not missing_r,
      "%d 个引用，缺失 %s" % (len(kt_refs), missing_r or "无"))

# ---------------------------------------------------------------- 5. version catalog
toml = open(os.path.join(ROOT, "gradle", "libs.versions.toml"), "r", encoding="utf-8").read()
declared = set()

def to_alias(section, key):
    return re.sub(r"[-_]", ".", key)

for section in ("libraries", "plugins"):
    m = re.search(r"\[%s\]\n(.*?)(?=\n\[|\Z)" % section, toml, re.S)
    if m:
        for line in m.group(1).splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            declared.add(to_alias(section, line.split("=")[0].strip()))

builds = [os.path.join(ROOT, "build.gradle.kts"),
          os.path.join(ROOT, "app", "build.gradle.kts"),
          os.path.join(ROOT, "settings.gradle.kts")]
used = set()
for b in builds:
    src = open(b, "r", encoding="utf-8").read()
    used |= set(re.findall(r"\blibs\.([A-Za-z0-9_.]+)", src))
def resolved(x):
    return x[len("plugins."):] if x.startswith("plugins.") else x

unknown = sorted(x for x in used if resolved(x) not in declared and not x.startswith("versions"))
check("Gradle 版本目录别名全部已声明", not unknown,
      "使用 %d 个，未知 %s" % (len(used), unknown or "无"))

# ---------------------------------------------------------------- 6. packages
bad_pkg = []
for src in walk(".kt") + walk(".java"):
    head = open(src, "r", encoding="utf-8").read()[:2000]
    m = re.search(r"^\s*package\s+([\w.]+)\s*;?\s*$", head, re.M)
    if not m:
        continue
    expected = os.path.relpath(os.path.dirname(src),
                               os.path.join(ROOT, "app", "src", "main", "java")).replace(os.sep, ".")
    if m.group(1) != expected:
        bad_pkg.append(os.path.relpath(src, ROOT))
check("package 声明与目录一致", not bad_pkg, bad_pkg or "全部一致")

# ---------------------------------------------------------------- 7. secrets
leaks = []
key_pat = re.compile(r"lm_[A-Za-z0-9_-]{28,}")
for f in walk(".java") + walk(".kt") + walk(".xml") + walk(".md") + walk(".yml") + walk(".kts") + walk(".toml"):
    rel = os.path.relpath(f, ROOT)
    if rel.startswith("VERIFY_REPORT"):
        continue
    s = open(f, "r", encoding="utf-8").read()
    for hit in key_pat.findall(s):
        leaks.append("%s: %s…" % (rel, hit[:12]))
check("仓库中无硬编码真实 API Key", not leaks, leaks or "无")
check("未提交 keystore / 模型文件",
      not any(f.endswith((".jks", ".keystore", ".gguf")) for f in
              [os.path.join(b, x) for b, _, fs in os.walk(ROOT) for x in fs]))

failed = [r for r in rows if not r[1]]
print("\n%d checks, %d failed" % (len(rows), len(failed)))
sys.exit(1 if failed else 0)
