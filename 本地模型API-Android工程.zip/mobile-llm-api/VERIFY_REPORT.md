# 端到端验证报告

生成时间：2026-11-08 20:16:13 CST

验证对象：`app/src/main/java/.../LocalApiServer.java`（与 Android APK 内同一份源码）

方式：真实启动 JVM 服务，通过 TCP 发起 HTTP/SSE 请求，无 mock。

| 检查项 | 结果 | 说明 |
| --- | --- | --- |
| GET /health 200 + model | ✅ PASS | status=200 model=qwen2.5-3b-instruct-q4_k_m |
| security headers present | ✅ PASS |  |
| GET / docs page (mobile viewport) | ✅ PASS |  |
| docs page never leaks API key | ✅ PASS |  |
| missing key -> 401 | ✅ PASS | status=401 |
| 401 carries WWW-Authenticate | ✅ PASS |  |
| wrong key -> 401 | ✅ PASS |  |
| X-API-Key alternative header | ✅ PASS |  |
| GET /v1/models OpenAI shape | ✅ PASS |  |
| POST /v1/chat/completions 200 | ✅ PASS | 90ms tps=3368.4 |
| response Content-Type json utf-8 | ✅ PASS |  |
| POST /v1/completions text_completion | ✅ PASS |  |
| SSE 200 + text/event-stream | ✅ PASS |  |
| SSE chunked stream (multiple deltas) | ✅ PASS | 51 chunks |
| SSE first delta / [DONE] / finish_reason | ✅ PASS |  |
| SSE carries usage + local_timings | ✅ PASS |  |
| SSE time-to-first-byte < 500ms | ✅ PASS | 1.8ms |
| OPTIONS CORS preflight 204 | ✅ PASS |  |
| unknown route -> structured 404 | ✅ PASS |  |
| invalid JSON -> 400 | ✅ PASS |  |
| empty messages -> 400 | ✅ PASS |  |
| oversized body -> 413 | ✅ PASS | HTTP/1.1 413 Payload Too Large |
| HTTP keep-alive connection reuse | ✅ PASS |  |
| 8 concurrent requests all 200 | ✅ PASS | statuses=[200, 200, 200, 200, 200, 200, 200, 200] |
| API key never written to logs | ✅ PASS |  |
| per-key rate limit -> 429 | ✅ PASS | codes=[200, 200, 200, 429, 429] |

**合计：26 项，失败 0 项，耗时 5.9s。**
