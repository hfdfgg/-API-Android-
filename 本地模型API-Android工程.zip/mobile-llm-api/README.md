# 本地模型 API（Android）

把 GGUF 量化模型放进手机，在设备本地推理，并对外暴露一个 **OpenAI 兼容、带密钥、走 HTTPS 公网** 的 API。复制地址和 API Key，就能在任何地方用 `curl`、OpenAI SDK、自己的程序调用这台手机。

```
你的手机                                    公网
┌───────────────────────────┐        ┌──────────────────┐
│ GGUF 模型 (app 私有目录)   │        │ Cloudflare 边缘   │
│   ↓                       │        │   HTTPS + WAF    │
│ llama.cpp CPU 推理        │        │        ↑         │
│   ↓ 逐 token 回调         │        │   cloudflared    │
│ LocalApiServer            │◄───────│   tunnel         │
│   127.0.0.1:8080          │  仅回环 │        ↑         │
│   Bearer Key / 限流 / SSE │        │  外部客户端      │
└───────────────────────────┘        └──────────────────┘
```

> **验证状态（请先看）**
> ✅ 服务端协议层已在本仓库真实启动并跑通 **26 项端到端检查**（鉴权、SSE 流式、限流、并发、错误码、密钥不落日志），报告见 `VERIFY_REPORT.md`。
> ⚠️ **真机端侧 GGUF 推理**、**真机公网连通**这两段需要在你的手机上验证：我这里没有 Android 设备，也没有你的 Cloudflare 域名 / Token。文档给出了逐步操作与自检命令。
> 本仓库不含任何真实密钥、模型文件或签名证书。

---

## 一、快速开始

1. 把本目录 `git init && git push` 到你自己的 GitHub 仓库（私有仓库也可以）。
2. 打开仓库 **Actions → 构建与验证**，等待完成（约 2–4 分钟）。
3. 下载产物 `LocalModelAPI-<run_number>` 里的 `app-debug.apk`，传到手机安装（需允许「安装未知来源应用」）。
4. 打开 APP → **控制台 → 启动服务**。
5. 在「服务状态」卡片复制 **Base URL** 和 **API Key**（密钥默认隐藏，点「显示」或「复制密钥」）。
6. 用另一台设备调用：

```bash
curl http://127.0.0.1:8080/health     # 同一台手机内，免鉴权

curl https://<你的公网域名>/v1/chat/completions \
  -H "Authorization: Bearer <API_KEY>" \
  -H "Content-Type: application/json" \
  -N -d '{"model":"<模型名>","messages":[{"role":"user","content":"你好"}],"stream":true}'
```

CI 每次都会先跑协议回归，失败就不出包；产物里同时附上 `VERIFY_REPORT.md`。

---

## 二、拿到公网 HTTPS 地址

手机一般在运营商 NAT 后面，没有固定公网 IP，必须借助隧道。APP 里 **控制台 → 公网访问** 提供四档，改完点「重启生效」，地址会自动出现在「服务状态」和「调用」页。

| 模式 | 适用场景 | 你需要准备 |
| --- | --- | --- |
| 关闭 | 只在手机本机 / 局域网用 | 无 |
| Quick 隧道 | 立刻要一个临时公网地址，零配置 | 无，自动得到 `https://xxx.trycloudflare.com` |
| 命名隧道 | 固定自定义域名、长期稳定 | Cloudflare Tunnel Token + 域名 |
| 外部地址 | 最稳妥，适合正式使用 | 你在有公网的机器/Nginx 上跑隧道，把 `https://` 地址填进来 |

**命名隧道配置**
1. Cloudflare Zero Trust → Networks → Tunnels → Create a tunnel，拿到 Token。
2. Public Hostname 里把 `llm.example.com` 指向 `http://127.0.0.1:8080`（这是隧道**所在机器**视角，填本机即可）。
3. APP 里选「命名隧道」，填 Token 和域名，重启服务。
4. 强烈建议再给这个 hostname 加一条 **Access 策略**（邮箱 / Service Token），等于在 Bearer Key 之外再加一道门。

**为什么安全**：服务端默认只绑定 `127.0.0.1`，公网侧由 Cloudflare 终止 TLS；明文仅允许回环（见 `network_security_config.xml`），`usesCleartextTraffic=false`。CI 会通过 `scripts/prepare-tunnel-binary.sh` 把官方静态 `cloudflared` 随 APK 打包进 `nativeLibraryDir`——这是 Android 10+ 上唯一允许应用执行二进制的位置，避免运行时下载到私有目录被 W^X 拦掉。

> 若日志出现「Permission denied / 无法执行」，请改用 **外部地址** 模式：在你自己的服务器上运行
> `cloudflared tunnel --url http://<手机局域网IP>:8080`（或 frp / Nginx + HTTPS），把生成的 HTTPS 地址填入 APP。
>
> 若 CI 下载 release 资产失败（网络受限），可设置变量 `CLOUDFLARED_URL` 指向同版本静态二进制镜像后重跑 workflow；这一步失败只会告警，不会阻断 APK 产出。

---

## 三、调用方式（APP 自动生成）

「调用」页会按当前公网地址和密钥实时生成四种示例，点「复制完整调用包」可一次拿到 Base URL + Key + curl + Python。

**Python（OpenAI SDK）**

```python
from openai import OpenAI
client = OpenAI(base_url="https://<域名>/v1", api_key="<API_KEY>")
for chunk in client.chat.completions.create(
    model="<模型名>",
    messages=[{"role": "user", "content": "你好"}],
    stream=True,
):
    print(chunk.choices[0].delta.content or "", end="", flush=True)
```

**接口清单**

| 路径 | 鉴权 | 说明 |
| --- | --- | --- |
| `GET /health` | 免 | 状态、模型、引擎、运行时长 |
| `GET /` `/docs` | 免 | 手机适配的 API 文档页，**不显示密钥** |
| `GET /v1/models` | 需要 | OpenAI 兼容模型列表 |
| `POST /v1/chat/completions` | 需要 | 对话，支持 `stream:true` SSE |
| `POST /v1/completions` | 需要 | 传统补全接口 |

两种鉴权头都支持：`Authorization: Bearer <key>` 或 `X-API-Key: <key>`。响应额外带 `local_timings`（首 token 延迟、总耗时、tok/s），方便你观察手机上的真实速度。

---

## 四、界面与功能

四个底部 Tab，全部按手机竖屏比例设计（`screenOrientation="portrait"`）：

- **控制台**：服务开关、状态卡片、公网模式、模型导入、线程数 / 上下文长度 / 提示词模板 / 端口 / 局域网开关。
- **对话**：APP 内对话走的**就是**对外那个 API 的 SSE 流式接口，你在里面测到的行为和其他设备调用完全一致。
- **调用**：连接信息 + 自动生成的 curl / Python / Node.js / Kotlin 示例，一键复制。
- **日志**：实时运行日志，自动脱敏，密钥、请求头、正文一律不写入。

模型导入用系统文件选择器（SAF），**不需要任何存储权限**；GGUF 会被复制到 APP 私有目录并校验文件头。建议 Q4_K_M 及以下量化、7B 以内，内存 8GB+ 的手机体验更稳。

---

## 五、真机端侧推理（GGUF）

默认 CI 出的是**零 NDK 依赖**的轻量包，能装、能起服务、能对话（内置自检引擎会明确标注，不会伪装成真实模型）。要跑真实 GGUF：

```bash
# 本地（需 Android NDK 27 + CMake 3.22.1）
./gradlew assembleDebug -PwithLlama=true
```

或在 GitHub Actions 手动触发 `workflow_dispatch`，把 `with_llama` 选成 `true`。`native-llama/CMakeLists.txt` 会拉取固定 tag 的 llama.cpp，编译 CPU-only 的 `libllama_jni.so`；`LlamaCppEngine` 通过 JNI 逐 token 回调给服务端，实现真正的流式输出。

细节、模板适配（ChatML / Llama3 / 原文）和常见问题见 `native-llama/README.md`。

**速度取决于模型与手机**，不是代码能凭空保证的：量化等级、内存带宽、大核调度、上下文长度、后台温升都会影响 tok/s。可调项（线程数、ctx、量化）已在控制台开放，响应里的 `local_timings` 会给出实测值；首 token 与连续输出都走 SSE chunked，不缓冲整段。

---

## 六、权限（最小必需）

| 权限 | 用途 |
| --- | --- |
| `INTERNET` / `ACCESS_NETWORK_STATE` | 隧道与对外服务 |
| `FOREGROUND_SERVICE` / `..._DATA_SYNC` | 模型常驻内存、服务不被杀 |
| `POST_NOTIFICATIONS` | Android 13+ 前台服务通知（唯一运行时申请项） |
| `WAKE_LOCK` | 推理期间不完全休眠 |

不申请定位、通讯录、相机、短信、读取外部存储。Android 沙盒里不存在「完整权限」这一说法，过度申请只会被商店拒绝并放大风险；APK 侧载不受商店审核，但依然按最小权限实现。

---

## 七、安全设计

- **密钥**：256 位随机 `lm_...`，仅存 `MODE_PRIVATE`，`allowBackup=false` + `data_extraction_rules` 全量排除；永不写日志、永不进文档页、永不进仓库；控制台可一键重置。
- **鉴权**：所有 `/v1/*` 强制 Bearer Key，常数时间比较（SHA-256 摘要比对）；401 带 `WWW-Authenticate`。
- **限流与体积**：每 Key 120 次/分钟、请求体上限 1 MiB、请求头 100 行、连接空闲 30s、`max_tokens` 硬上限 4096、线程池上限 16。
- **传输**：公网强制 HTTPS；明文仅放行 `127.0.0.1` / `localhost`；CORS、安全响应头齐全。
- **隔离**：无导出 Provider、无备份、无外部存储写入、模型文件仅本应用可读。
- 建议在 Cloudflare Zero Trust 再加 Access 策略；密钥泄露时立刻在控制台重置。

---

## 八、已经验证 / 尚未验证

**已验证（可复现）**
```bash
python3 scripts/verify-protocol.py --report VERIFY_REPORT.md
```
真实启动 `app/src/main/java/.../LocalApiServer.java`（APK 里就是这份源码），通过 TCP 发起 HTTP/SSE 请求，26 项全通过：health / 文档页 / 401 / 错误 Key / 双鉴权头 / model 列表 / 非流式对话 / 传统补全 / SSE 多 chunk / `[DONE]` / finish_reason / usage / 首字节 < 500ms / CORS / 404 / 400 / 413 / keep-alive / 8 并发 / 限流 429 / 日志无密钥。

**需要你在真机上完成**
1. 安装 APK、授予通知权限、启动服务、导入 GGUF。
2. 配好 Quick 隧道或命名隧道，用另一台设备 `curl` 公网 `/health` 与 `/v1/chat/completions`。
3. 确认厂商后台保活策略（部分国产 ROM 会杀前台服务，需加入电池优化白名单）。
4. 若启用 `-PwithLlama=true`，确认 `libllama_jni.so` 加载成功、真实模型吐字与 tok/s 符合预期。

我没法替你完成这四步，也不会把它们描述成「已跑通」。CI 里的协议回归是自动的，真机验证是手动的。

---

## 九、已知限制

- Android 不是服务器：后台保活、温控降频、内存回收都受系统管制；长时间高负载推理建议插电。
- CPU 推理速度受硬件限制，7B 以上模型在手机上会明显慢；追求速度请换更小量化 / 更小模型。
- `cloudflared` 在部分 ROM / SELinux 策略下仍可能无法执行，备用方案是「外部地址」模式。
- 不支持 root / 系统级权限，也不申请任何敏感权限；这是系统沙盒的边界，不是实现缺口。
- 未上架应用商店，签名 release 需要你自己的 keystore（CI 已留好 secrets 接口）。

---

## 十、目录

```
app/src/main/java/com/yuanbao/localmodel/
├── server/LocalApiServer.java   # 零依赖 HTTP/SSE 服务 + 鉴权 + JSON（JVM/Android 同一份）
├── engine/LlamaCppEngine.kt     # 可选 GGUF 真机引擎（JNI）
├── service/LlmService.kt        # 前台服务：常驻模型 + API + 隧道
├── service/TunnelManager.kt     # Cloudflare Quick / 命名 / 外部 HTTPS
├── ui/                          # Compose 竖屏界面（控制台/对话/调用/日志）
└── util/                        # 密钥、模型导入、日志、APP 内 SSE 客户端
native-llama/                    # 可选 JNI 桥接与 CMake
scripts/                         # 协议验证、隧道二进制准备
.github/workflows/build.yml      # 协议回归 + 自动出 APK + 可选 Release
```

后续可继续加：模型下载器、多模型热切换、GPU/Vulkan 后端、请求级并发队列、Zero Trust 一键配置、用量统计面板。按你的反馈排优先级。
