# 交付状态

一句话：**服务端协议层已跑通并自动验证；真机推理与真机公网需要你在手机上完成下面 4 步。** 不把没验过的部分说成已跑通。

## ✅ 已跑通（本仓库可复现）

```bash
python3 scripts/static-check.py                              # 13 项，0 失败
python3 scripts/verify-protocol.py --report VERIFY_REPORT.md  # 26 项，0 失败
```

验证方式：真实启动 `LocalApiServer.java`（**APK 里用的就是这一份源码**），通过 TCP 发起 HTTP/SSE 请求，无 mock。

覆盖：健康检查、移动版文档页、Bearer 鉴权、错误密钥、双鉴权头、模型列表、非流式对话、传统补全、SSE 逐块流、`[DONE]`、`finish_reason`、usage 与计时、首字节 < 500ms、CORS 预检、结构化 400/404/413/429、keep-alive、8 并发、密钥不落日志。

静态自检覆盖：Java 编译冒烟、Python/Shell/YAML 语法、Manifest 与 Kotlin 的资源引用、Gradle 版本目录、package 与目录一致、仓库无硬编码密钥与证书。

CI（`.github/workflows/build.yml`）在每次 push 自动重跑这两组检查，**任一失败就不出 APK**。

## ⚠️ 需要你在真机上验证（4 步）

1. Actions 下载 `app-debug.apk` → 手机安装 → 允许通知权限 → **控制台 → 启动服务**。
2. **控制台 → 公网访问** 选 Quick 隧道或填命名隧道 Token/域名 → 重启生效 → 用另一台设备 `curl https://<域名>/health`。
3. 导入 GGUF → 确认日志显示「GGUF 已载入内存」；若显示「内置自检引擎」，说明 APK 未带 `libllama_jni.so`，需用 `-PwithLlama=true` 重新构建。
4. 拷走「调用」页的 Base URL + API Key，用 `curl` / OpenAI SDK 发一条 `stream:true` 请求，确认逐字返回。

我这边没有 Android 设备、没有你的 Cloudflare 域名/Token，所以这四步无法代跑。README 第八、九节写了逐步操作、自检命令和排错表。

## 📦 交付内容

- 完整 Android 工程（Compose 竖屏 UI / 前台服务 / 零依赖 HTTP+SSE 服务端 / 密钥与模型管理 / 隧道管理）
- GitHub Actions：协议回归 + 自动出 APK + 可选 release 签名 + tag 自动发 Release
- 可选 llama.cpp JNI 真机引擎（`-PwithLlama=true`）
- `README.md` 使用说明、`SECURITY.md` 安全模型、`native-llama/README.md` 构建排错、`VERIFY_REPORT.md` 验证报告

## 明确没做的

- 没有生成/编译出真机 APK（沙盒无 Android SDK/NDK）
- 没有真机端侧 GGUF 推理与公网连通的实测结果
- 没有「完整手机权限」——Android 沙盒不存在这个概念，已按最小必需权限实现并在 README 说明原因
- 没有往你的仓库推送代码、没有使用任何真实密钥或证书

## 复现命令

```bash
git init && git add . && git commit -m "init" && git push
# 打开仓库 Actions → 构建与验证 → 下载产物
```
