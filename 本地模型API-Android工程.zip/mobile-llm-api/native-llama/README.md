# 真机 GGUF 推理引擎（可选）

默认 APK **不含** 这个模块：CI 用零 NDK 依赖的方式快速出包，APP 会明确显示「内置自检引擎」，不会把自检输出伪装成真实模型。要跑真实 GGUF，按下面任选一种打开。

## 构建

```bash
# 本地：需要 Android NDK 27.x + CMake 3.22.1 + JDK 17
sdkmanager --install "ndk;27.0.12077973" "cmake;3.22.1"
./gradlew assembleDebug -PwithLlama=true
```

或在 GitHub Actions 手动运行 workflow，把 `with_llama` 选为 `true`。

`CMakeLists.txt` 用 `FetchContent` 拉取固定 tag 的 `ggml-org/llama.cpp`（默认 `v0.9.0`，可用 `-DLLAMA_CPP_TAG=...` 覆盖），编译：

- CPU-only，`n_gpu_layers=0`，跨机型可移植；
- `use_mmap=true`，多 GB 模型不会整体复制进内存；
- 只产出 `libllama_jni.so`，不编译 examples / server / tests；
- 仅 `arm64-v8a`（`app/build.gradle.kts` 里的 abiFilters）。

## 运行链路

```
LocalApiServer.Engine.generate(Prompt, TokenSink)
        │  (Kotlin)
        ▼
LlamaCppEngine.nativeGenerate()
        │  (JNI, llama_jni.cpp)
        ▼
llama.cpp: tokenize → llama_decode(prefill, 带 pos) → sampler 链
        │  每生成一个 token → llama_token_to_piece
        ▼
UTF-8 边界缓冲 → TokenSink.onToken() → SSE data: {...}\n\n
```

`llama_jni.cpp` 里几个容易踩坑、已处理好的点：

- **prefill 必须显式设置 `pos`**：`llama_batch_get_one` 只填 token，不填位置；不设置会让所有 token 都落在位置 0，输出乱码。
- **UTF-8 不能按字节切**：中文一个字 3 字节，token 可能落在字符中间；代码用 `pending` 缓冲，只在凑齐完整码点时才回调，流结束时强制冲刷残留。
- **客户端中途断开**：`onToken` 抛异常 / 断连时清掉 JNI 异常并结束生成，不会卡死线程。
- **采样链顺序**：`top_p → temp → dist`，`llama_sampler_sample` 返回最终 argmax；`temperature<=0` 走纯 greedy。
- 每个请求独立 sampler，支持 API 传入的 `temperature` / `top_p` / `max_tokens`。

## 模型与模板

- 只接受 **GGUF**（`ModelRepository` 校验文件头 `GGUF`），推荐 Q4_K_M / Q3_K_M 量化，7B 以内、手机内存 ≥ 8GB。
- 「控制台 → 提示词模板」按模型选：
  - `ChatML`：Qwen / Yi / DeepSeek 等大多数国产 chat 模型（默认）
  - `Llama3`：Llama 3 / 3.1 instruct
  - `原文`：base 模型或自定义格式
- 上下文长度 `ctx` 与推理线程数可滑杆调整；线程数超过大核数通常会变慢，温控降频也会拉低 tok/s。

## 排错

| 现象 | 原因 / 处理 |
| --- | --- |
| 日志显示「未检测到 libllama_jni.so」 | 没带 `-PwithLlama=true`，或 so 不在 `arm64-v8a` |
| 「模型加载失败」 | 非 GGUF / 文件损坏 / 内存不足，换更小量化 |
| 「prompt exceeds n_ctx」 | 调大上下文长度或缩短对话历史 |
| 输出乱码 | 模板选错，或模型本身是 base 模型 |
| 速度很慢 / 发热 | 减小模型、降低 ctx、减少线程、插电、关闭省电模式 |

## 诚实说明

这条编译链依赖 llama.cpp 上游 API，其头文件在不同 tag 之间会有变动；我这里**没有 Android NDK 与真机**，`-PwithLlama=true` 的编译结果和真机吐字需要你按上面步骤验证。若上游 API 改名，改 `llama_jni.cpp` 里对应的调用即可，服务端与 UI 层完全不用动——这也是把推理引擎做成可插拔 `Engine` 接口的原因。
