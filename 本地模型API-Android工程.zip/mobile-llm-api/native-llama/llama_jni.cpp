// JNI bridge between LocalApiServer.Engine and llama.cpp (CPU inference).
// Built only when -PwithLlama=true is supplied; see native-llama/README.md.

#include <jni.h>
#include <cstring>
#include <ctime>
#include <string>
#include <vector>
#include <cstdint>

#include "llama.h"
#include "ggml.h"
#include <android/log.h>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "llama_jni", __VA_ARGS__)

namespace {

struct EngineCtx {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    int n_threads = 0;
};

static inline EngineCtx *as_ctx(jlong h) {
    return reinterpret_cast<EngineCtx *>(h);
}

static size_t utf8_len(unsigned char c) {
    if (c < 0x80) return 1;
    if ((c & 0xE0) == 0xC0) return 2;
    if ((c & 0xF0) == 0xE0) return 3;
    if ((c & 0xF8) == 0xF0) return 4;
    return 1; // invalid leading byte: emit as-is to avoid an infinite loop
}

/** Emit only complete UTF-8 code points; keep any dangling tail for the next token. */
static bool flush_utf8(JNIEnv *env, jobject sink, jmethodID mid,
                       std::string &pending, bool force) {
    size_t i = 0;
    while (i < pending.size()) {
        const size_t n = utf8_len(static_cast<unsigned char>(pending[i]));
        if (i + n > pending.size()) break;
        jstring js = env->NewStringUTF(pending.substr(i, n).c_str());
        if (js == nullptr) return false;
        env->CallVoidMethod(sink, mid, js);
        env->DeleteLocalRef(js);
        if (env->ExceptionCheck()) {
            env->ExceptionClear();   // client disconnected mid-stream
            return false;
        }
        i += n;
    }
    pending.erase(0, i);
    if (force && !pending.empty()) {
        jstring js = env->NewStringUTF(pending.c_str());
        if (js != nullptr) {
            env->CallVoidMethod(sink, mid, js);
            env->DeleteLocalRef(js);
        }
        pending.clear();
    }
    return true;
}

static std::vector<llama_token> tokenize(const llama_vocab *vocab,
                                         const char *text, bool add_special) {
    const int32_t len = static_cast<int32_t>(std::strlen(text));
    std::vector<llama_token> out(len + 16);
    int32_t n = llama_tokenize(vocab, text, len, out.data(),
                               static_cast<int32_t>(out.size()), add_special, true);
    if (n < 0) {
        out.resize(static_cast<size_t>(-n));
        n = llama_tokenize(vocab, text, len, out.data(),
                           static_cast<int32_t>(out.size()), add_special, true);
    }
    if (n < 0) return {};
    out.resize(static_cast<size_t>(n));
    return out;
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeLoad(
        JNIEnv *env, jobject /*thiz*/, jstring jpath, jint threads, jint n_ctx) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    if (path == nullptr) return 0;

    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;                 // CPU-only: portable across all phones
    mp.use_mmap = true;                  // don't copy a multi-GB model into RAM
    llama_model *model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);

    if (model == nullptr) {
        LOGE("llama_model_load_from_file failed");
        llama_backend_free();
        return 0;
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = n_ctx;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    cp.n_batch = 512;
    cp.n_ubatch = 128;
    llama_context *ctx = llama_init_from_model(model, cp);
    if (ctx == nullptr) {
        LOGE("llama_init_from_model failed");
        llama_model_free(model);
        llama_backend_free();
        return 0;
    }

    auto *c = new EngineCtx();
    c->model = model;
    c->ctx = ctx;
    c->vocab = llama_model_get_vocab(model);
    c->n_ctx = n_ctx;
    c->n_threads = threads;
    return reinterpret_cast<jlong>(c);
}

JNIEXPORT void JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeFree(
        JNIEnv *, jobject, jlong handle) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr) return;
    if (c->ctx) llama_free(c->ctx);
    if (c->model) llama_model_free(c->model);
    llama_backend_free();
    delete c;
}

JNIEXPORT jint JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeTokenCount(
        JNIEnv *env, jobject, jlong handle, jstring jtext) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->vocab == nullptr) return 0;
    const char *text = env->GetStringUTFChars(jtext, nullptr);
    if (text == nullptr) return 0;
    auto tokens = tokenize(c->vocab, text, true);
    env->ReleaseStringUTFChars(jtext, text);
    return static_cast<jint>(tokens.size());
}

JNIEXPORT jint JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeGenerate(
        JNIEnv *env, jobject, jlong handle, jstring jprompt,
        jint max_tokens, jfloat temperature, jfloat top_p, jobject sink) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->ctx == nullptr || c->vocab == nullptr || sink == nullptr) return 0;

    jclass sink_cls = env->GetObjectClass(sink);
    jmethodID on_token = env->GetMethodID(sink_cls, "onToken", "(Ljava/lang/String;)V");
    env->DeleteLocalRef(sink_cls);
    if (on_token == nullptr) return 0;

    const char *prompt = env->GetStringUTFChars(jprompt, nullptr);
    if (prompt == nullptr) return 0;
    auto tokens = tokenize(c->vocab, prompt, true);
    env->ReleaseStringUTFChars(jprompt, prompt);
    if (tokens.empty()) return 0;

    if (static_cast<int>(tokens.size()) >= c->n_ctx - 8) {
        LOGE("prompt exceeds n_ctx");
        return 0;
    }

    // Fresh sampler per request so temperature / top_p can be set by the caller.
    llama_sampler *sp = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temperature <= 0.0f) {
        llama_sampler_chain_add(sp, llama_sampler_init_greedy());
    } else {
        // Standard upstream order: shape the distribution, then sample from it.
        // llama_sampler_init_dist already collapses the candidates down to the
        // chosen token, and llama_sampler_sample() returns that argmax. Adding a
        // greedy sampler afterwards would be redundant.
        llama_sampler_chain_add(sp, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(sp, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(sp, llama_sampler_init_dist(
                static_cast<uint32_t>(std::time(nullptr))));
    }

    // Prefill: positions 0..n-1 are mandatory, otherwise every token lands on pos 0.
    std::vector<llama_pos> positions(tokens.size());
    for (size_t i = 0; i < tokens.size(); ++i) positions[i] = static_cast<llama_pos>(i);
    llama_batch prefill = llama_batch_get_one(tokens.data(),
                                              static_cast<int32_t>(tokens.size()));
    prefill.pos = positions.data();
    if (llama_decode(c->ctx, prefill) != 0) {
        LOGE("prefill decode failed");
        llama_sampler_free(sp);
        return 0;
    }

    llama_pos pos = static_cast<llama_pos>(tokens.size());
    std::string pending;
    int generated = 0;

    for (int i = 0; i < max_tokens; ++i) {
        llama_token id = llama_sampler_sample(sp, c->ctx, -1);
        llama_sampler_accept(sp, id);
        if (llama_vocab_is_eog(c->vocab, id)) break;

        std::vector<char> piece(32);
        int32_t n = llama_token_to_piece(c->vocab, id, piece.data(),
                                         static_cast<int32_t>(piece.size()), 0, true);
        if (n < 0) {
            piece.resize(static_cast<size_t>(-n));
            n = llama_token_to_piece(c->vocab, id, piece.data(),
                                     static_cast<int32_t>(piece.size()), 0, true);
        }
        if (n > 0) pending.append(piece.data(), static_cast<size_t>(n));
        if (!flush_utf8(env, sink, on_token, pending, false)) break;
        ++generated;

        llama_token next_token = id;
        llama_batch step = llama_batch_get_one(&next_token, 1);
        step.pos = &pos;
        if (llama_decode(c->ctx, step) != 0) break;
        ++pos;
        if (pos >= c->n_ctx) break;
    }

    flush_utf8(env, sink, on_token, pending, true);
    llama_sampler_free(sp);
    return generated;
}

} // extern "C"
