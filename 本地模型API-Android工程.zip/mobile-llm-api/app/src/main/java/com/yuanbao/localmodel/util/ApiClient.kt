package com.yuanbao.localmodel.util

import com.yuanbao.localmodel.ChatLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * The in-app chat goes through the SAME OpenAI-compatible API that external
 * clients use. So what you test inside the app is exactly what your other
 * devices will call over the public HTTPS tunnel.
 */
object ApiClient {

    data class ChatResult(val text: String, val firstTokenMs: Long, val tps: Double)

    suspend fun streamChat(
        port: Int,
        apiKey: String,
        model: String,
        history: List<ChatLine>,
        userText: String,
        onDelta: (String) -> Unit,
    ): ChatResult = withContext(Dispatchers.IO) {
        val messages = JSONArray()
        // Keep the last 12 turns to protect the phone's limited context window.
        history.takeLast(12).forEach { messages.put(JSONObject().put("role", it.role).put("content", it.text)) }
        messages.put(JSONObject().put("role", "user").put("content", userText))

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("stream", true)
            .put("max_tokens", 512)
            .put("temperature", 0.7)
            .toString()

        val conn = (URL("http://127.0.0.1:$port/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 5_000
            readTimeout = 180_000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "text/event-stream")
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Connection", "close")
        }

        try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code != 200) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw IllegalStateException("HTTP $code ${err.take(200)}")
            }

            val sb = StringBuilder()
            var first: Long = 0
            var tps = 0.0
            BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data: ")) continue
                    val data = line.removePrefix("data: ").trim()
                    if (data == "[DONE]") break
                    val obj = JSONObject(data)
                    val delta = obj.getJSONArray("choices").getJSONObject(0).optJSONObject("delta")
                    val piece = delta?.optString("content") ?: ""
                    if (piece.isNotEmpty()) {
                        sb.append(piece)
                        onDelta(piece)
                    }
                    obj.optJSONObject("local_timings")?.let {
                        tps = it.optDouble("tokens_per_second", 0.0)
                        first = it.optLong("first_token_ms", 0L)
                    }
                }
            }
            ChatResult(sb.toString(), first, tps)
        } finally {
            conn.disconnect()
        }
    }
}
