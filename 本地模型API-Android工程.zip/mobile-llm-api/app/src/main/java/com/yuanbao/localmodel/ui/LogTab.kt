package com.yuanbao.localmodel.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuanbao.localmodel.AppGraph

@Composable
fun LogTab() {
    val s by AppGraph.ui.collectAsState()
    val listState = rememberLazyListState()

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        SectionCard(
            title = "运行日志（自动脱敏）",
            trailing = { TextButton(onClick = { AppGraph.logs.clear() }) { Text("清空") } },
        ) {
            Text(
                "记录服务启停、请求耗时与隧道状态；API Key、Authorization 头、请求正文均不写入。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            androidx.compose.foundation.layout.Spacer(Modifier.height(10.dp))
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxWidth().height(460.dp),
            ) {
                items(s.logs) { line ->
                    Text(
                        text = line,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = when {
                            line.contains("ERROR") -> MaterialTheme.colorScheme.error
                            line.contains("WARN") -> MaterialTheme.colorScheme.secondary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(vertical = 2.dp),
                    )
                }
            }
        }
    }
}
