package com.yuanbao.localmodel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.ChatLine
import com.yuanbao.localmodel.util.ApiClient
import kotlinx.coroutines.launch

@Composable
fun ChatTab() {
    val s by AppGraph.ui.collectAsState()
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(s.chat.size, s.chat.lastOrNull()?.text?.length) {
        if (s.chat.isNotEmpty()) listState.animateScrollToItem(s.chat.size - 1)
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text(
            if (s.running) "走本机 127.0.0.1:${s.port} 的 OpenAI 兼容接口，逐 token 流式输出"
            else "请先到「控制台」启动服务",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 10.dp),
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(s.chat) { Bubble(it) }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("问点什么…", fontSize = 14.sp) },
                modifier = Modifier.weight(1f).heightIn(min = 52.dp, max = 120.dp),
                maxLines = 4,
                enabled = s.running && !s.streaming,
            )
            Button(
                onClick = send@{
                    val text = input.trim()
                    if (text.isEmpty() || !s.running || s.streaming) return@send
                    input = ""
                    val history = s.chat
                    val port = s.port
                    val key = s.apiKey
                    val model = s.modelName
                    scope.launch {
                        AppGraph.update {
                            it.copy(
                                chat = it.chat + ChatLine("user", text) + ChatLine("assistant", ""),
                                streaming = true,
                            )
                        }
                        try {
                            val result = ApiClient.streamChat(port, key, model, history, text) { delta ->
                                AppGraph.update { st ->
                                    val last = st.chat.lastOrNull()
                                    val next = if (last != null && last.role == "assistant")
                                        st.chat.dropLast(1) + ChatLine("assistant", last.text + delta)
                                    else st.chat + ChatLine("assistant", delta)
                                    st.copy(chat = next)
                                }
                            }
                            AppGraph.update {
                                it.copy(
                                    streaming = false,
                                    firstTokenMs = result.firstTokenMs,
                                    tps = result.tps,
                                )
                            }
                        } catch (e: Exception) {
                            AppGraph.update { st ->
                                val last = st.chat.lastOrNull()
                                val next = if (last != null && last.role == "assistant" && last.text.isEmpty())
                                    st.chat.dropLast(1) + ChatLine("assistant", "调用失败：${e.message}")
                                else st.chat
                                st.copy(chat = next, streaming = false)
                            }
                            AppGraph.logs.error("对话失败：${e.message}")
                        }
                    }
                },
                enabled = s.running && !s.streaming,
                modifier = Modifier.padding(start = 8.dp).heightIn(min = 52.dp),
            ) { Text(if (s.streaming) "生成中" else "发送") }
        }
    }
}

@Composable
private fun Bubble(line: ChatLine) {
    val user = line.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start,
    ) {
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .background(
                    if (user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    RoundedCornerShape(12.dp),
                )
                .padding(horizontal = 12.dp, vertical = 9.dp),
        ) {
            Text(
                text = line.text.ifEmpty { "…" },
                color = if (user) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp,
                lineHeight = 20.sp,
            )
        }
    }
}
