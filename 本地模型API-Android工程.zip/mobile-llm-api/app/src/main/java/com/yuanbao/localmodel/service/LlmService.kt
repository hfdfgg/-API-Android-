package com.yuanbao.localmodel.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.MainActivity
import com.yuanbao.localmodel.R
import com.yuanbao.localmodel.engine.LlamaCppEngine
import com.yuanbao.localmodel.server.LocalApiServer
import com.yuanbao.localmodel.util.ModelInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface

class LlmService : Service() {

    companion object {
        const val ACTION_START = "com.yuanbao.localmodel.START"
        const val ACTION_STOP = "com.yuanbao.localmodel.STOP"
        const val ACTION_RESET_KEY = "com.yuanbao.localmodel.RESET_KEY"
        private const val CHANNEL = "llm_service"
        private const val NOTIF_ID = 1001

        fun start(ctx: Context) = ctx.startForegroundService(
            Intent(ctx, LlmService::class.java).setAction(ACTION_START)
        )

        fun stop(ctx: Context) = ctx.startService(
            Intent(ctx, LlmService::class.java).setAction(ACTION_STOP)
        )

        fun resetKey(ctx: Context) = ctx.startForegroundService(
            Intent(ctx, LlmService::class.java).setAction(ACTION_RESET_KEY)
        )
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var server: LocalApiServer? = null
    private var engine: LocalApiServer.Engine? = null
    private var llama: LlamaCppEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var tunnel: TunnelManager

    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
        tunnel = TunnelManager(this, AppGraph.logs)
        createChannel()
        observeFlows()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAll()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_RESET_KEY -> {
                AppGraph.prefs.resetApiKey()
                AppGraph.logs.info("API Key 已重置，服务重启中")
                stopAll()
                startAll()
            }
            else -> startAll()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopAll()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ lifecycle

    private fun startAll() {
        stopAll()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        val prefs = AppGraph.prefs
        val model = AppGraph.models.current()
        val engineName = buildEngine(model, prefs)

        val cfg = LocalApiServer.Config().apply {
            host = if (prefs.lanMode) "0.0.0.0" else "127.0.0.1"
            port = prefs.port
            apiKey = prefs.apiKey()
            modelId = model?.name ?: "local-selfcheck"
            requestsPerMinute = 120
            maxConcurrent = 8
        }

        // If the port is taken, roll forward instead of failing outright.
        var attempts = 0
        while (attempts < 6) {
            try {
                val s = LocalApiServer(cfg, engine, AppGraph.logs)
                s.start()
                server = s
                break
            } catch (e: Exception) {
                attempts++
                cfg.port++
                AppGraph.logs.warn("端口 ${cfg.port - 1} 被占用，尝试 ${cfg.port}")
            }
        }
        if (server == null) {
            AppGraph.logs.error("端口全部被占用，服务启动失败")
        } else {
            holdWakeLock()
            val mode = prefs.tunnelMode
            if (mode != "off") {
                tunnel.start(
                    cfg.port, mode, prefs.tunnelToken, prefs.publicHostname, prefs.externalBase
                )
            }
            AppGraph.logs.info("本地 API 已就绪：${server!!.baseUrl()}")
        }
        publish(engineName, cfg, model)
    }

    private fun buildEngine(model: ModelInfo?, prefs: com.yuanbao.localmodel.util.Prefs): String {
        if (model != null && model.validGguf && LlamaCppEngine.available) {
            try {
                val e = LlamaCppEngine(model.path, prefs.threads, prefs.ctxSize, prefs.promptTemplate)
                e.load()
                llama = e
                engine = e
                AppGraph.logs.info("GGUF 已载入内存：${model.name}（${prefs.threads} 线程 / ${prefs.ctxSize} ctx）")
                return "llama.cpp · 真实模型"
            } catch (e: Exception) {
                AppGraph.logs.error("GGUF 加载失败：${e.message}")
                llama?.close()
                llama = null
            }
        } else if (model != null && !LlamaCppEngine.available) {
            AppGraph.logs.warn("未检测到 libllama_jni.so，使用自检引擎；详见 native-llama/README.md")
        }

        val fallback = LocalApiServer.BuiltinEngine(model?.name ?: "local-selfcheck")
        engine = fallback
        return "内置自检引擎（未加载真实模型）"
    }

    private fun stopAll() {
        tunnel.stop()
        try { server?.stop() } catch (t: Throwable) { }
        server = null
        try { llama?.close() } catch (t: Throwable) { }
        llama = null
        engine = null
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (t: Throwable) { }
        wakeLock = null
        AppGraph.update { it.copy(running = false, publicUrl = "", tunnelStatus = "未开启", streaming = false) }
    }

    private fun publish(engineName: String, cfg: LocalApiServer.Config, model: ModelInfo?) {
        val lan = if (cfg.host == "0.0.0.0") "http://${lanIp()}:${cfg.port}" else ""
        AppGraph.update { s ->
            s.copy(
                running = server?.isRunning == true,
                port = cfg.port,
                lanMode = cfg.host == "0.0.0.0",
                threads = AppGraph.prefs.threads,
                ctxSize = AppGraph.prefs.ctxSize,
                promptTemplate = AppGraph.prefs.promptTemplate,
                tunnelMode = AppGraph.prefs.tunnelMode,
                tunnelToken = AppGraph.prefs.tunnelToken,
                publicHostname = AppGraph.prefs.publicHostname,
                externalBase = AppGraph.prefs.externalBase,
                localUrl = server?.baseUrl() ?: "",
                lanUrl = lan,
                apiKey = cfg.apiKey,
                modelName = model?.name ?: "未导入模型",
                modelSize = if (model != null) AppGraph.models.formatSize(model.sizeBytes) else "",
                modelPath = model?.path ?: "",
                engineName = engineName,
            )
        }
    }

    private fun observeFlows() {
        scope.launch {
            AppGraph.logs.lines.collect { lines -> AppGraph.update { it.copy(logs = lines) } }
        }
        scope.launch {
            tunnel.url.collect { url -> AppGraph.update { it.copy(publicUrl = url) } }
        }
        scope.launch {
            tunnel.status.collect { st -> AppGraph.update { it.copy(tunnelStatus = st) } }
        }
    }

    // ------------------------------------------------------------------ notification / wake lock

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(
            CHANNEL, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
        ).apply { description = getString(R.string.notif_channel_desc) }
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun holdWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalModelAPI:inference").apply {
            setReferenceCounted(false)
            acquire(60 * 60 * 1000L)
        }
    }

    private fun lanIp(): String {
        return try {
            val nifs = NetworkInterface.getNetworkInterfaces()
            while (nifs.hasMoreElements()) {
                val addrs = nifs.nextElement().inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress ?: ""
                }
            }
            ""
        } catch (t: Throwable) {
            ""
        }
    }
}
