package com.yuanbao.localmodel

import android.app.Application
import android.content.Context
import com.yuanbao.localmodel.util.LogBus
import com.yuanbao.localmodel.util.ModelRepository
import com.yuanbao.localmodel.util.Prefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ChatLine(val role: String, val text: String)

data class UiState(
    val running: Boolean = false,
    val port: Int = 8080,
    val lanMode: Boolean = false,
    val threads: Int = 4,
    val ctxSize: Int = 2048,
    val promptTemplate: String = "chatml",
    val tunnelMode: String = "off",      // off | quick | token
    val tunnelToken: String = "",
    val publicHostname: String = "",
    val tunnelStatus: String = "未开启",
    val publicUrl: String = "",
    val externalBase: String = "",
    val localUrl: String = "",
    val lanUrl: String = "",
    val apiKey: String = "",
    val modelName: String = "未导入模型",
    val modelSize: String = "",
    val modelPath: String = "",
    val engineName: String = "",
    val logs: List<String> = emptyList(),
    val chat: List<ChatLine> = emptyList(),
    val streaming: Boolean = false,
    val firstTokenMs: Long = 0L,
    val tps: Double = 0.0,
)

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
    }
}

/** Single-process in-memory graph: Activity and Service share the same instance. */
object AppGraph {
    private lateinit var ctx: Context
    val prefs: Prefs by lazy { Prefs(ctx) }
    val models: ModelRepository by lazy { ModelRepository(ctx) }
    val logs: LogBus by lazy { LogBus() }

    private val _state = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _state.asStateFlow()

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    fun context(): Context = ctx

    fun update(block: (UiState) -> UiState) {
        _state.value = block(_state.value)
    }
}
