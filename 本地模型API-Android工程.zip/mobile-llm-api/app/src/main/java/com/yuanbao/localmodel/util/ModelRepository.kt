package com.yuanbao.localmodel.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

data class ModelInfo(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val validGguf: Boolean,
)

/**
 * Models are copied into app-private storage via Storage Access Framework.
 * ACTION_OPEN_DOCUMENT needs NO storage permission, and the copy stays readable
 * only by this app (and by our own native engine).
 */
class ModelRepository(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "models").apply { mkdirs() }
    private val sp = ctx.getSharedPreferences("models", Context.MODE_PRIVATE)

    fun import(uri: Uri): ModelInfo {
        val rawName = displayName(uri) ?: "model_${System.currentTimeMillis()}.gguf"
        val safe = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        val dest = File(dir, safe)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().buffered(1024 * 1024).use { out -> input.copyTo(out) }
        } ?: throw IllegalArgumentException("无法读取所选文件，请重新选择")

        val info = describe(dest)
        sp.edit().putString("current", dest.absolutePath).apply()
        return info
    }

    fun current(): ModelInfo? {
        val path = sp.getString("current", null) ?: return null
        val f = File(path)
        return if (f.isFile) describe(f) else null
    }

    fun clear() {
        sp.edit().remove("current").apply()
        dir.listFiles()?.forEach { it.delete() }
    }

    fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return "%.1f KB".format(kb)
        val mb = kb / 1024.0
        if (mb < 1024) return "%.1f MB".format(mb)
        return "%.2f GB".format(mb / 1024.0)
    }

    private fun describe(f: File) = ModelInfo(
        name = f.name,
        path = f.absolutePath,
        sizeBytes = f.length(),
        validGguf = isGguf(f),
    )

    private fun isGguf(f: File): Boolean {
        if (f.length() < 4) return false
        f.inputStream().use {
            val h = ByteArray(4)
            if (it.read(h) != 4) return false
            return h[0].toInt() == 0x47 && h[1].toInt() == 0x47 &&
                    h[2].toInt() == 0x55 && h[3].toInt() == 0x46 // "GGUF"
        }
    }

    private fun displayName(uri: Uri): String? {
        return try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
