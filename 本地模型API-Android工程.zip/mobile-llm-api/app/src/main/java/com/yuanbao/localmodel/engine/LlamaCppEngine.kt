package com.yuanbao.localmodel.engine

import com.yuanbao.localmodel.server.LocalApiServer
import java.io.File

/**
 * Real on-device GGUF inference through llama.cpp.
 *
 * The native library is produced by `scripts/build-native.sh` (or by building
 * with -PwithLlama=true). If it is absent the app transparently falls back to
 * the built-in self-test engine, so the APK always boots and the API always works.
 */
class LlamaCppEngine(
    private val modelPath: String,
    private val threads: Int,
    private val ctxSize: Int,
    private val template: String = "chatml",
) : LocalApiServer.Engine {

    companion object {
        @Volatile
        var available: Boolean = false
            private set

        private var loadError: String = ""

        init {
            try {
                System.loadLibrary("llama_jni")
                available = true
            } catch (t: Throwable) {
                loadError = t.message ?: t.javaClass.simpleName
                available = false
            }
        }

        fun reason(): String = loadError
    }

    private var handle: Long = 0L
    private val id: String = File(modelPath).nameWithoutExtension

    // ---- JNI surface (see native-llama/llama_jni.cpp) ----
    private external fun nativeLoad(path: String, threads: Int, ctx: Int): Long
    private external fun nativeFree(handle: Long)
    private external fun nativeGenerate(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        sink: LocalApiServer.TokenSink,
    ): Int

    private external fun nativeTokenCount(handle: Long, text: String): Int

    fun load() {
        check(available) { "未找到 libllama_jni.so：${reason()}" }
        handle = nativeLoad(modelPath, threads, ctxSize)
        check(handle != 0L) { "模型加载失败，请确认是量化 GGUF 且内存充足" }
    }

    fun close() {
        if (handle != 0L) {
            nativeFree(handle)
            handle = 0L
        }
    }

    override fun modelId(): String = id

    override fun isLoaded(): Boolean = handle != 0L

    override fun generate(prompt: LocalApiServer.Prompt, sink: LocalApiServer.TokenSink) {
        check(handle != 0L) { "模型未加载" }
        nativeGenerate(
            handle,
            render(prompt),
            prompt.maxTokens,
            prompt.temperature.toFloat(),
            prompt.topP.toFloat(),
            sink,
        )
    }

    override fun estimatePromptTokens(prompt: LocalApiServer.Prompt): Int {
        if (handle == 0L) return render(prompt).length / 3
        return try {
            nativeTokenCount(handle, render(prompt))
        } catch (t: Throwable) {
            render(prompt).length / 3
        }
    }

    /** ChatML covers Qwen / Yi / DeepSeek chat models; "raw" for base models. */
    private fun render(p: LocalApiServer.Prompt): String {
        when (template) {
            "raw" -> {
                val last = p.messages.lastOrNull()?.content ?: ""
                return last
            }
            "llama3" -> {
                val sb = StringBuilder("<|begin_of_text|>")
                for (m in p.messages) {
                    sb.append("<|start_header_id|>").append(m.role)
                        .append("<|end_header_id|>\n\n").append(m.content)
                        .append("<|eot_id|>")
                }
                sb.append("<|start_header_id|>assistant<|end_header_id|>\n\n")
                return sb.toString()
            }
            else -> {
                val sb = StringBuilder()
                for (m in p.messages) {
                    sb.append("<|im_start|>").append(m.role).append('\n')
                        .append(m.content).append("<|im_end|>\n")
                }
                sb.append("<|im_start|>assistant\n")
                return sb.toString()
            }
        }
    }
}
