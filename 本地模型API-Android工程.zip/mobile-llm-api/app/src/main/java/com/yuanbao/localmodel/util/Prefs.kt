package com.yuanbao.localmodel.util

import android.content.Context
import com.yuanbao.localmodel.server.LocalApiServer
import java.io.File

/**
 * API key lives in app-private storage only (MODE_PRIVATE + allowBackup=false +
 * data-extraction-rules exclude). It is never logged, never backed up, never exported.
 */
class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val keyFile = File(ctx.filesDir, "api_key.txt")

    fun apiKey(): String {
        if (!keyFile.exists()) return resetApiKey()
        val k = keyFile.readText().trim()
        return if (k.startsWith("lm_") && k.length >= 40) k else resetApiKey()
    }

    /** 256-bit random key, base64url. Call when the user taps "reset key". */
    fun resetApiKey(): String {
        val k = LocalApiServer.generateApiKey()
        keyFile.writeText(k)
        return k
    }

    var port: Int
        get() = sp.getInt("port", 8080)
        set(v) = sp.edit().putInt("port", v).apply()

    var lanMode: Boolean
        get() = sp.getBoolean("lan", false)
        set(v) = sp.edit().putBoolean("lan", v).apply()

    var threads: Int
        get() = sp.getInt("threads", Runtime.getRuntime().availableProcessors().coerceIn(2, 8))
        set(v) = sp.edit().putInt("threads", v).apply()

    var ctxSize: Int
        get() = sp.getInt("ctx", 2048)
        set(v) = sp.edit().putInt("ctx", v).apply()

    /** off | quick | token */
    var tunnelMode: String
        get() = sp.getString("tunnel", "off") ?: "off"
        set(v) = sp.edit().putString("tunnel", v).apply()

    var tunnelToken: String
        get() = sp.getString("tunnel_token", "") ?: ""
        set(v) = sp.edit().putString("tunnel_token", v).apply()

    /** For named tunnels: the hostname you configured in Cloudflare Zero Trust. */
    var publicHostname: String
        get() = sp.getString("public_hostname", "") ?: ""
        set(v) = sp.edit().putString("public_hostname", v).apply()

    /** "external" mode: the public HTTPS base URL you expose yourself. */
    var externalBase: String
        get() = sp.getString("external_base", "") ?: ""
        set(v) = sp.edit().putString("external_base", v).apply()

    /** chatml | llama3 | raw */
    var promptTemplate: String
        get() = sp.getString("template", "chatml") ?: "chatml"
        set(v) = sp.edit().putString("template", v).apply()
}
