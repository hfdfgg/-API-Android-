package com.yuanbao.localmodel.ui

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.MainActivity
import com.yuanbao.localmodel.service.LlmService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun syncFromPrefs() {
    val p = AppGraph.prefs
    AppGraph.update {
        it.copy(
            port = p.port, lanMode = p.lanMode, threads = p.threads, ctxSize = p.ctxSize,
            promptTemplate = p.promptTemplate, tunnelMode = p.tunnelMode,
            tunnelToken = p.tunnelToken, publicHostname = p.publicHostname,
            externalBase = p.externalBase,
        )
    }
}

private fun restartService(ctx: Context) {
    ctx.startForegroundService(
        Intent(ctx, LlmService::class.java).setAction(LlmService.ACTION_START)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen() {
    val s by AppGraph.ui.collectAsState()
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("控制台", "对话", "调用", "日志")
    val icons = listOf(Icons.Default.Home, Icons.Default.Send, Icons.Default.Share, Icons.Default.List)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("本地模型 API", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text("端侧推理 · OpenAI 兼容 · 公网 HTTPS", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp) },
                    )
                }
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> ConsoleTab()
                1 -> ChatTab()
                2 -> SnippetsTab()
                else -> LogTab()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConsoleTab() {
    val s by AppGraph.ui.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = AppGraph.prefs

    val importModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            AppGraph.logs.info("正在导入模型文件…")
            try {
                val info = withContext(Dispatchers.IO) { AppGraph.models.import(uri) }
                AppGraph.update {
                    it.copy(
                        modelName = info.name,
                        modelSize = AppGraph.models.formatSize(info.sizeBytes),
                        modelPath = info.path,
                    )
                }
                AppGraph.logs.info(
                    "导入完成：${info.name} · ${AppGraph.models.formatSize(info.sizeBytes)} · " +
                            if (info.validGguf) "GGUF 校验通过" else "⚠ 非 GGUF 文件"
                )
                if (s.running) restartService(ctx)
            } catch (e: Exception) {
                AppGraph.logs.error("导入失败：${e.message}")
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        StatusCard(s, onResetKey = { LlmService.resetKey(ctx) })

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { if (s.running) LlmService.stop(ctx) else restartService(ctx) },
                modifier = Modifier.weight(1f).height(48.dp),
                colors = if (s.running)
                    ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                else ButtonDefaults.buttonColors(),
            ) { Text(if (s.running) "停止服务" else "启动服务", fontSize = 15.sp) }
            OutlinedButton(
                onClick = { restartService(ctx) },
                enabled = s.running,
                modifier = Modifier.width(110.dp).height(48.dp),
            ) { Text("重启生效") }
        }

        // ------------------------------------------------------------ public access
        SectionCard("公网访问 · 强制 HTTPS") {
            Text("手机通常在运营商 NAT 后，需要隧道才能拿到公网地址。服务端始终只监听回环地址。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            val modes = listOf("off" to "关闭", "quick" to "Quick 隧道", "token" to "命名隧道", "external" to "外部地址")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(2) { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        repeat(2) { col ->
                            val (key, label) = modes[row * 2 + col]
                            FilterChip(
                                selected = s.tunnelMode == key,
                                onClick = { p.tunnelMode = key; syncFromPrefs(); AppGraph.logs.info("公网模式：$label（重启服务生效）") },
                                label = { Text(label, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            when (s.tunnelMode) {
                "token" -> {
                    OutlinedTextField(
                        value = s.tunnelToken,
                        onValueChange = { p.tunnelToken = it; syncFromPrefs() },
                        label = { Text("Cloudflare Tunnel Token") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = s.publicHostname,
                        onValueChange = { p.publicHostname = it; syncFromPrefs() },
                        label = { Text("自定义域名，如 llm.example.com") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                }
                "external" -> OutlinedTextField(
                    value = s.externalBase,
                    onValueChange = { p.externalBase = it; syncFromPrefs() },
                    label = { Text("https:// 开头的公网 Base URL") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                "quick" -> Text("无需账号，启动后自动获得 https://xxx.trycloudflare.com（随机域名 + Bearer Key 双保护）。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("当前：${s.tunnelStatus}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary)
        }

        // ------------------------------------------------------------ model
        SectionCard("本地模型 · GGUF") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { importModel.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                    Text("导入 GGUF 文件")
                }
                OutlinedButton(onClick = {
                    AppGraph.models.clear()
                    AppGraph.update { it.copy(modelName = "未导入模型", modelSize = "", modelPath = "") }
                    AppGraph.logs.info("已移除模型")
                    if (s.running) restartService(ctx)
                }) { Text("移除") }
            }
            Spacer(Modifier.height(10.dp))
            MonoLine(s.modelName)
            if (s.modelSize.isNotBlank()) {
                Text("大小 ${s.modelSize}", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("建议 Q4_K_M 及以下量化；模型文件复制到 APP 私有目录，不需要任何存储权限。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // ------------------------------------------------------------ performance
        SectionCard("性能与端口 · 重启后生效") {
            Text("推理线程：${s.threads}（按大核数调整，过多反而变慢）",
                style = MaterialTheme.typography.bodySmall)
            Slider(
                value = s.threads.toFloat(), onValueChange = { p.threads = it.toInt(); syncFromPrefs() },
                valueRange = 2f..8f, steps = 5, modifier = Modifier.fillMaxWidth(),
            )
            Text("上下文长度：${s.ctxSize} tokens", style = MaterialTheme.typography.bodySmall)
            Slider(
                value = s.ctxSize.toFloat(), onValueChange = { p.ctxSize = (it.toInt() / 512) * 512; syncFromPrefs() },
                valueRange = 512f..8192f, steps = 14, modifier = Modifier.fillMaxWidth(),
            )
            Text("提示词模板", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("chatml" to "ChatML", "llama3" to "Llama3", "raw" to "原文").forEach { (k, label) ->
                    FilterChip(
                        selected = s.promptTemplate == k,
                        onClick = { p.promptTemplate = k; syncFromPrefs() },
                        label = { Text(label, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = s.port.toString(),
                onValueChange = { v ->
                    v.filter { it.isDigit() }.toIntOrNull()?.let { if (it in 1024..65535) { p.port = it; syncFromPrefs() } }
                },
                label = { Text("本地端口") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("允许局域网访问（0.0.0.0）", modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall)
                Switch(checked = s.lanMode, onCheckedChange = { p.lanMode = it; syncFromPrefs() })
            }
            if (s.lanUrl.isNotBlank()) MonoLine(s.lanUrl, color = MaterialTheme.colorScheme.secondary)
        }

        Text("提示：修改设置或导入模型后点「重启生效」。真机端侧推理需要 libllama_jni.so，构建方式见 native-llama/README.md。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
    }
}
