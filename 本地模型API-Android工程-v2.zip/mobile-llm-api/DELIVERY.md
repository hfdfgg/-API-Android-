# 交付状态（v2）

一句话：**截图中那个报错已定位并从架构层修掉；慢、卡顿、兼容性、UI、代码结构按同一套策略重做；协议层与工程层 55 项检查全绿。真机端侧推理与公网连通仍需要你在手机上复核。**

## 截图里发生了什么

```
22:22:45  GGUF 已载入内存: Qwen2.5-1.5B-Instruct-Q4_K_M.gguf (4 线程 / 2048 ctx)
22:22:45  engine=LlamaCppEngine        ← 真实模型其实加载成功了
22:23:40  chat/completions 200 46621ms stream=true
22:23:40  ERROR 对话失败: The coroutine scope left the composition
```

真实模型跑起来了，但：
1. 默认 512 token 上限 + 每 token 一次 JNI 回调 + 一次 SSE 写/flush → 46.6 秒；
2. 你切到「日志」页看进度，`rememberCoroutineScope()` 随组合销毁，正在跑的请求被取消并误报为失败。

## ✅ 本轮已完成

| 你的 8 条 | 落地 |
| --- | --- |
| 1 慢 | KV `q8_0` 量化、独立 context 预热、JNI 6token / SSE 4token 微批、APP 默认 256 token、大核自适应线程、降低 flush 次数 |
| 2 兼容/加载/流畅 | `auto` 用 GGUF 自带 chat template；多模型列表/切换/删除；加载失败不伪装；16KB 页对齐；低内存自动降级 |
| 3 UI + 不屎山 | 新增 `core/` 业务层，UI 只渲染；日志页自适应高度、中文排版、运行概览；加速器/设备/保活卡片 |
| 4 API 流畅 | `CallerRunsPolicy` → `AbortPolicy` + 结构化 503；accept 线程不再被慢推理占用；`usage.completion_tokens` 用真实 token 数 |
| 5 大部分手机 / vivo Y300 | 后台保活一键跳转、设备画像降级、`-Pabis=` 扩展 32 位/x86_64、Android 15 16KB 页对齐 |
| 6 多模型格式 | GGUF 真跑；`.task`/LiteRT、TFLite、ONNX、MNN 可识别与切换，明确标注「引擎未接入」 |
| 7 加速器 | 省电 / 均衡 / 极速三档，统一驱动线程、ctx、KV 量化、预热、预填批、微批、并发、max_tokens |
| 8 取消打字机 | 客户端聚合完整文本，生成完成一次回填；生成中显示「正在生成…」，可取消 |

**核心修复**：请求移到 `AppGraph.appScope`，切页/旋转/离开 Activity 都不中断。已写成静态检查，改回去 CI 会失败。

## ✅ 已跑通（可复现）

```bash
python3 scripts/static-check.py                              # 27 项，0 失败
python3 scripts/verify-protocol.py --report VERIFY_REPORT.md  # 28 项，0 失败
```

- 协议层真实启动 JVM 服务端（与 APK 内同一份 `LocalApiServer.java`），通过 TCP 发 HTTP/SSE 请求，无 mock。
- 新增断言：**微批合并生效**（16 个 SSE chunk < 48 个真实 token）、`completion_tokens` 为真实生成数。
- 静态层新增 14 条**防回归架构约束**（应用级协程、无逐字刷新、微批、503、KV 量化、自动模板、预热、16KB 对齐、多格式路由、保活引导等）。
- CI 每次 push 自动重跑两组检查，任一失败不出 APK。

## ⚠️ 仍需你在真机上复核（我没法代跑）

1. 重新 push 触发 Actions → 下载新 APK → 安装（覆盖安装即可，设置会保留）。
2. 控制台选「均衡」或「极速」→ 重启服务 → 看日志是否出现「预热完成」和新的策略行。
3. 对话页发一条消息：**切到日志页再切回来，请求不应再中断**；输出应一次性出现，不再逐字蹦。
4. 看 `首 token xx ms · xx tok/s`，对比之前的 46621ms。
5. 若日志仍显示「内置自检引擎」，说明 APK 未带 `libllama_jni.so`，需 `with_llama=true` 重新构建（你上一版显然带了，保留同样构建方式即可）。
6. 点「后台保活设置」把应用加入白名单，避免 vivo/OPPO 冻结前台服务。

沙盒没有 Android SDK/NDK，也没有你的 Cloudflare 域名与 Token，所以这些步骤不描述为「已跑通」。

## 📦 交付内容

完整 Android 工程（core / server / engine / service / ui / util 分层）、GitHub Actions 自动出包与签名、可选 llama.cpp JNI 引擎、`README.md` 修复清单、`SECURITY.md`、`native-llama/README.md`、`VERIFY_REPORT.md`、`CHANGELOG.md`。

## 明确没做的

- 没有编译出真机 APK，没有真机 tok/s 实测数据
- LiteRT / ONNX / MNN 只做了格式识别与路由占位，**没有实现推理引擎**，不会假装能跑
- 没有「完整手机权限」——Android 沙盒边界，按最小必需权限实现
- 没有往你的仓库推代码，没有使用任何真实密钥或证书
