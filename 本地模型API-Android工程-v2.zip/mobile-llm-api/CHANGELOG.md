# 变更日志

## v2（真机截图反馈修复）

**修复**
- 对话请求从 `rememberCoroutineScope()` 移到 `AppGraph.appScope`：切换 Tab / 旋转 / 离开页面不再产生 `The coroutine scope left the composition`，也不会误报「对话失败」。
- `CallerRunsPolicy` 改为 `AbortPolicy` + 结构化 503：并发满载不再让慢推理占用 accept 线程。
- `usage.completion_tokens` 改用 `Engine.generate()` 返回的真实 token 数，不再用 SSE 写入次数冒充。
- 修复 `parse_chat` 中 vector 扩容导致 `c_str()` 悬空的潜在崩溃。
- `llama_chat_apply_template` 长度探测改用非空缓冲，兼容不同上游实现。

**性能（加速器）**
- 新增 `core/AppCore.kt`：统一常量、设备画像（大核数/内存/ABI/Android 版本）、三档 `PerfPolicy`、多模型格式识别。
- KV cache `q8_0` 量化、独立 context 预热、大核自适应线程、低内存自动降级。
- JNI 6 token 微批回调、SSE 4 token / 24ms 微批写出；首片仍立即发送保持低首字节延迟。
- APP 默认 `max_tokens` 512 → 256；`Engine.generate` 返回真实 token 数用于 usage/tps 统计。
- 验证结果：SSE chunk 从 51 降到 16（48 token），协议层首字节 1.5ms。

**兼容性**
- `auto` 模板：读取 GGUF 自带 chat template，自动适配 Qwen / Llama3 / Gemma / Phi / Mistral 等；保留手写模板兜底。
- 多模型列表、切换、逐项删除；GGUF / LiteRT `.task` / TFLite / ONNX / MNN 格式识别与诚实路由。
- CMake 对所有 `.so` 加 16KB 页对齐（Android 15 新机）；`-Pabis=` 可扩展 `armeabi-v7a` / `x86_64`。
- 控制台新增「后台保活设置」一键跳转，应对 vivo / OPPO / 小米冻结前台服务。

**UI / 结构**
- 新增 `core/` 业务层与 `ChatController`，Composable 不再承载业务逻辑。
- 取消打字机：生成完成一次性回填，生成中显示占位，可取消。
- 日志页自适应高度、运行概览、中文排版；控制台新增加速器、设备画像、多模型、模板、公网、端口卡片。
- 状态卡片显示真实引擎标识、模型格式与当前性能策略。

**验证**
- 协议回归 26 → 28 项（新增微批合并、真实 token 计数）。
- 工程自检 13 → 27 项（新增 14 条防回归架构约束）。
- 两组检查均 0 失败，已接入 CI。

## v1

初版：Android 工程 + 零依赖 OpenAI 兼容服务端 + Cloudflare 隧道 + 最小权限 + 自动打包；协议 26 项、静态 13 项通过。
