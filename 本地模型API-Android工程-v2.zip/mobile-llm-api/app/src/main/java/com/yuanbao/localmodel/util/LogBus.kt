package com.yuanbao.localmodel.util

import com.yuanbao.localmodel.server.LocalApiServer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogBus : LocalApiServer.LogSink {
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines.asStateFlow()
    private val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val lock = Any()

    override fun log(level: String, message: String) {
        val line = "${stamp.format(Date())}  $level  $message"
        synchronized(lock) {
            _lines.value = (_lines.value + line).takeLast(200)
        }
    }

    fun info(msg: String) = log("INFO", msg)
    fun warn(msg: String) = log("WARN", msg)
    fun error(msg: String) = log("ERROR", msg)

    fun clear() {
        synchronized(lock) { _lines.value = emptyList() }
    }

    /** Pushes the ring buffer into the UI state. */
    fun snapshot(): List<String> = _lines.value
}
