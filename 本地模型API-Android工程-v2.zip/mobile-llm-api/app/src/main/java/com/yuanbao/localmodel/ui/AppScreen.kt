package com.yuanbao.localmodel.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.core.PerfMode
import com.yuanbao.localmodel.service.LlmService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun syncFromPrefs() {
    val p = AppGraph.prefs
    AppGraph.refreshPolicy()
    AppGraph.update {
        it.copy(
            port = p.port, lanMode = p.lanMode, perfMode = p.perfMode,
            promptTemplate = p.promptTemplate, tunnelMode = p.tunnelMode,
            tunnelToken = p.tunnelToken, publicHostname = p.publicHostname,
            externalBase = p.externalBase,
        )
    }
}

private fun restartService(ctx: Context) = ctx.startForegroundService(
    Intent(ctx, LlmService::class.java).setAction(LlmService.ACTION_START))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen() {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("控制台", "对话", "调用", "日志")
    val icons = listOf(Icons.Default.Home, Icons.Default.Send, Icons.Default.Share, Icons.Default.List)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("本地模型 API", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text("端侧推理 · OpenAI 兼容 · 公网 HTTPS", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onSurface),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp) })
                }
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> ConsoleTab()
                1 -> ChatTab()
                2 -> SnippetsTab()
                else -> LogTab()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConsoleTab() {
    val s by AppGraph.ui.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = AppGraph.prefs

    val importModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            AppGraph.logs.info("正在导入模型文件…")
            try {
                val info = withContext(Dispatchers.IO) { AppGraph.models.import(uri) }
                AppGraph.update {
                    it.copy(modelName = info.name,
                        modelSize = AppGraph.models.formatSize(info.sizeBytes),
                        modelPath = info.path, modelFormat = info.format.label)
                }
                AppGraph.logs.info("导入完成：${info.name} · ${AppGraph.models.formatSize(info.sizeBytes)} · ${info.format.label}"
                        + if (info.runnable) " · 可执行" else " · 需对应引擎插件")
                if (s.running) restartService(ctx)
            } catch (e: Exception) {
                AppGraph.logs.error("导入失败：${e.message}")
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        StatusCard(s, onResetKey = { LlmService.resetKey(ctx) })

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { if (s.running) LlmService.stop(ctx) else restartService(ctx) },
                modifier = Modifier.weight(1f).height(48.dp),
                colors = if (s.running) ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error) else ButtonDefaults.buttonColors(),
            ) { Text(if (s.running) "停止服务" else "启动服务", fontSize = 15.sp) }
            OutlinedButton(onClick = { restartService(ctx) }, enabled = s.running,
                modifier = Modifier.width(110.dp).height(48.dp)) { Text("重启生效") }
        }

        // ------------------------------------------------------------ accelerator
        SectionCard("加速器 · 性能档位") {
            Text(s.deviceInfo, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PerfMode.values().forEach { m ->
                    FilterChip(
                        selected = s.perfMode == m.id,
                        onClick = { p.perfMode = m.id; syncFromPrefs(); AppGraph.logs.info("性能档位：${m.label}（重启生效）") },
                        label = { Text(m.label, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(s.policyInfo, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary, lineHeight = 18.sp)
            Text("KV 量化减半内存带宽、预热消除首 token 缺页、JNI/SSE 微批减少跨层调用；低内存设备自动降并发。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e2: Exception) {
                        AppGraph.logs.warn("请手动把本应用加入后台保活 / 电池优化白名单")
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) {
                Text("后台保活设置（vivo / OPPO / 小米等）")
            }
            Text("国产 ROM 会冻结前台服务；加入白名单后长时间推理更稳。",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // ------------------------------------------------------------ public access
        SectionCard("公网访问 · 强制 HTTPS") {
            Text("服务端只监听回环；公网流量经 Cloudflare 强制 TLS，外部拿不到原始端口。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            val modes = listOf("off" to "关闭", "quick" to "Quick", "token" to "命名隧道", "external" to "外部地址")
            repeat(2) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    repeat(2) { col ->
                        val (key, label) = modes[row * 2 + col]
                        FilterChip(selected = s.tunnelMode == key,
                            onClick = { p.tunnelMode = key; syncFromPrefs() },
                            label = { Text(label, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f))
                    }
                }
            }
            when (s.tunnelMode) {
                "token" -> {
                    OutlinedTextField(value = s.tunnelToken,
                        onValueChange = { p.tunnelToken = it; syncFromPrefs() },
                        label = { Text("Cloudflare Tunnel Token") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = s.publicHostname,
                        onValueChange = { p.publicHostname = it; syncFromPrefs() },
                        label = { Text("自定义域名 llm.example.com") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth())
                }
                "external" -> OutlinedTextField(value = s.externalBase,
                    onValueChange = { p.externalBase = it; syncFromPrefs() },
                    label = { Text("https:// 开头的公网 Base URL") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
                "quick" -> Text("无需账号，启动后自动获得随机 HTTPS 域名（随机域名 + Bearer Key 双重保护）。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("当前：${s.tunnelStatus}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary)
        }

        // ------------------------------------------------------------ models
        SectionCard("模型 · 多格式 / 多文件") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { importModel.launch(arrayOf("*/*")) },
                    modifier = Modifier.weight(1f)) { Text("导入模型") }
            }
            Spacer(Modifier.height(10.dp))
            val models = AppGraph.models.list()
            if (models.isEmpty()) {
                Text("尚未导入。支持 GGUF；.task / TFLite / ONNX / MNN 可识别与管理，但需对应引擎插件才会执行。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                models.forEach { m ->
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(m.name, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            Text("${AppGraph.models.formatSize(m.sizeBytes)} · ${m.format.label}"
                                    + if (m.runnable) " · 可运行" else " · 引擎未接入",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (m.runnable) MaterialTheme.colorScheme.secondary
                                        else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (m.path == s.modelPath) {
                            Text("使用中", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary)
                        } else {
                            androidx.compose.material3.TextButton(onClick = {
                                AppGraph.models.select(m.path)
                                AppGraph.update { it.copy(modelName = m.name, modelPath = m.path,
                                    modelSize = AppGraph.models.formatSize(m.sizeBytes),
                                    modelFormat = m.format.label) }
                                AppGraph.logs.info("已切换模型：${m.name}")
                                if (s.running) restartService(ctx)
                            }) { Text("使用") }
                        }
                        androidx.compose.material3.TextButton(onClick = {
                            AppGraph.models.remove(m.path)
                            AppGraph.models.current()?.let { cur ->
                                AppGraph.update { it.copy(modelName = cur.name, modelPath = cur.path,
                                    modelSize = AppGraph.models.formatSize(cur.sizeBytes),
                                    modelFormat = cur.format.label) }
                            }
                            AppGraph.logs.info("已移除：${m.name}")
                        }) { Text("删除") }
                    }
                }
            }
        }

        // ------------------------------------------------------------ compatibility
        SectionCard("兼容性 · 提示词模板") {
            Text("默认 auto：读取 GGUF 自带 chat template（Qwen / Llama3 / Gemma / Phi / Mistral 等自动适配）。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            val tpls = listOf("auto" to "自动", "chatml" to "ChatML", "llama3" to "Llama3",
                "gemma" to "Gemma", "phi" to "Phi", "raw" to "原文")
            repeat(2) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                    repeat(3) { col ->
                        val (k, label) = tpls[row * 3 + col]
                        FilterChip(selected = s.promptTemplate == k,
                            onClick = { p.promptTemplate = k; syncFromPrefs() },
                            label = { Text(label, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // ------------------------------------------------------------ network
        SectionCard("端口与局域网") {
            OutlinedTextField(
                value = s.port.toString(),
                onValueChange = { v ->
                    v.filter { it.isDigit() }.toIntOrNull()?.let {
                        if (it in 1024..65535) { p.port = it; syncFromPrefs() }
                    }
                },
                label = { Text("本地端口") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("允许局域网访问", modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall)
                Switch(checked = s.lanMode, onCheckedChange = { p.lanMode = it; syncFromPrefs() })
            }
            if (s.lanUrl.isNotBlank()) MonoLine(s.lanUrl,
                color = MaterialTheme.colorScheme.secondary)
        }

        Text("修改设置后点「重启生效」。真机 GGUF 推理需要 -PwithLlama=true 构建，详见 native-llama/README.md。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
    }
}
