package com.yuanbao.localmodel.core

import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.ChatLine
import com.yuanbao.localmodel.util.ApiClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Chat lives in the APPLICATION scope, not rememberCoroutineScope().
 *
 * The bug in the screenshot ("The coroutine scope left the composition") happened
 * because switching from 对话 to 日志 destroyed the composition, cancelling the
 * in-flight generation and reporting it as a failure. Requests now survive any
 * tab switch, screen rotation and even leaving the Activity.
 *
 * No typewriter: tokens are accumulated in the client and written to the UI once,
 * when generation finishes. The SSE transport stays intact for external callers.
 */
class ChatController {

    private var job: Job? = null

    val busy: Boolean get() = job?.isActive == true

    fun send(text: String) {
        val state = AppGraph.ui.value
        val clean = text.trim()
        if (clean.isEmpty() || !state.running || busy) return

        val history = state.chat.filter { it.text.isNotEmpty() }
        val port = state.port
        val key = state.apiKey
        val model = state.modelName
        val maxTokens = AppGraph.policy.value?.appMaxTokens ?: 256

        // Placeholder only. No per-token recomposition.
        AppGraph.update {
            it.copy(
                chat = it.chat + ChatLine("user", clean) + ChatLine("assistant", ""),
                streaming = true,
                firstTokenMs = 0L,
                tps = 0.0,
            )
        }

        job = AppGraph.appScope.launch {
            try {
                val result = ApiClient.streamChat(
                    port = port,
                    apiKey = key,
                    model = model,
                    history = history,
                    userText = clean,
                    maxTokens = maxTokens,
                )
                // One atomic UI update -> no逐字刷新, no jank.
                AppGraph.update { st ->
                    st.copy(
                        chat = replaceLast(st.chat, result.text.ifEmpty { "（模型没有输出内容）" }),
                        streaming = false,
                        firstTokenMs = result.firstTokenMs,
                        tps = result.tps,
                    )
                }
                AppGraph.logs.info("生成完成：首 token ${result.firstTokenMs}ms · ${"%.1f".format(result.tps)} tok/s")
            } catch (e: CancellationException) {
                // User stopped the service or explicitly cancelled: not an error.
                AppGraph.update { st ->
                    st.copy(chat = dropEmptyTail(st.chat), streaming = false)
                }
                throw e
            } catch (e: Exception) {
                AppGraph.update { st ->
                    st.copy(
                        chat = replaceLast(st.chat, "调用失败：${friendly(e)}"),
                        streaming = false,
                    )
                }
                AppGraph.logs.error("对话失败：${friendly(e)}")
            } finally {
                job = null
            }
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        AppGraph.update { st -> st.copy(chat = dropEmptyTail(st.chat), streaming = false) }
    }

    private fun replaceLast(list: List<ChatLine>, text: String): List<ChatLine> {
        val last = list.lastOrNull()
        return if (last != null && last.role == "assistant")
            list.dropLast(1) + ChatLine("assistant", text)
        else list + ChatLine("assistant", text)
    }

    private fun dropEmptyTail(list: List<ChatLine>): List<ChatLine> {
        val last = list.lastOrNull()
        return if (last != null && last.role == "assistant" && last.text.isEmpty())
            list.dropLast(1) else list
    }

    private fun friendly(e: Exception): String {
        val m = e.message ?: e.javaClass.simpleName
        return when {
            m.contains("coroutine", true) -> "请求已被取消"
            m.contains("timeout", true) || m.contains("timed out", true) -> "生成超时，可切「省电」档或缩短问题"
            m.contains("503", true) -> "模型未就绪，请检查控制台日志"
            m.contains("401", true) -> "密钥不匹配，请重置密钥后重试"
            m.contains("ConnectException", true) || m.contains("ECONNREFUSED", true) -> "本地服务未启动"
            else -> m.take(160)
        }
    }
}
