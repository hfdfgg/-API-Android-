package com.yuanbao.localmodel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.ChatLine

@Composable
fun ChatTab() {
    val s by AppGraph.ui.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(s.chat.size) {
        if (s.chat.isNotEmpty()) listState.animateScrollToItem(s.chat.size - 1)
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text(
            if (s.running) {
                if (s.engineReal) "真实 GGUF 推理 · 走本机 OpenAI 兼容接口 · 生成完成后一次显示"
                else "当前为内置自检引擎（未加载真实模型）· 导入 GGUF 后切换"
            } else "请先到「控制台」启动服务",
            style = MaterialTheme.typography.bodySmall,
            color = if (s.engineReal) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp),
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(s.chat) { i, line ->
                Bubble(
                    line,
                    generating = s.streaming && i == s.chat.lastIndex &&
                            line.role == "assistant" && line.text.isEmpty(),
                )
            }
            if (s.chat.isEmpty()) {
                item {
                    Text(
                        "问点什么吧。输出会在生成完成后一次性出现，没有逐字动画；切换页面也不会中断请求。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 24.dp),
                    )
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
            verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("问点什么…", fontSize = 14.sp) },
                modifier = Modifier.weight(1f).heightIn(min = 52.dp, max = 120.dp),
                maxLines = 4,
                enabled = s.running && !s.streaming,
            )
            if (s.streaming) {
                TextButton(
                    onClick = { AppGraph.chat.cancel() },
                    modifier = Modifier.heightIn(min = 52.dp),
                ) { Text("取消") }
            } else {
                Button(
                    onClick = send@{
                        val text = input.trim()
                        if (text.isEmpty() || !s.running) return@send
                        input = ""
                        AppGraph.chat.send(text)
                    },
                    enabled = s.running,
                    modifier = Modifier.padding(start = 8.dp).heightIn(min = 52.dp),
                ) { Text("发送") }
            }
        }

        if (s.firstTokenMs > 0 || s.tps > 0) {
            Text(
                "首 token ${s.firstTokenMs}ms · ${"%.1f".format(s.tps)} tok/s",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}

@Composable
private fun Bubble(line: ChatLine, generating: Boolean) {
    val user = line.role == "user"
    Row(modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier.widthIn(max = 300.dp)
                .background(
                    if (user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    RoundedCornerShape(12.dp),
                )
                .padding(horizontal = 12.dp, vertical = 9.dp),
        ) {
            Text(
                text = when {
                    line.text.isNotEmpty() -> line.text
                    generating -> "正在生成…"
                    else -> "（无输出）"
                },
                color = if (user) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurface,
                fontSize = 14.sp,
                lineHeight = 20.sp,
            )
        }
    }
}
