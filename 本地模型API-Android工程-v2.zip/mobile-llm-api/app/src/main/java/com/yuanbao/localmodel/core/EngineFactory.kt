package com.yuanbao.localmodel.core

import com.yuanbao.localmodel.engine.LlamaCppEngine
import com.yuanbao.localmodel.server.LocalApiServer
import com.yuanbao.localmodel.util.LogBus
import com.yuanbao.localmodel.util.ModelInfo
import com.yuanbao.localmodel.util.Prefs

/** Result of an engine attempt: the engine plus an honest one-line status. */
data class EngineResult(
    val engine: LocalApiServer.Engine,
    val label: String,
    val real: Boolean,
)

/**
 * The only place that decides which engine runs. Everything else depends on the
 * LocalApiServer.Engine interface, so adding a new format = adding one branch here.
 */
object EngineFactory {

    fun create(model: ModelInfo?, policy: PerfPolicy, prefs: Prefs, log: LogBus): EngineResult {
        if (model == null) {
            log.info("未导入模型：启动内置自检引擎（输出会明确标注，不伪装成真实模型）")
            return EngineResult(
                LocalApiServer.BuiltinEngine("local-selfcheck"),
                "内置自检引擎 · 未导入模型",
                false,
            )
        }

        if (model.format != ModelFormat.GGUF) {
            log.warn("${model.name} 是 ${model.format.label}，当前 APK 未包含 ${model.format.engine}")
            log.warn("该模型可导入与管理，但不会执行推理；请导入 GGUF 或接入对应引擎插件")
            return EngineResult(
                UnavailableEngine(model.name, model.format.label),
                "${model.format.label} · 引擎未接入",
                false,
            )
        }

        if (!LlamaCppEngine.available) {
            log.warn("未检测到 libllama_jni.so，回退自检引擎；真机推理请用 -PwithLlama=true 重新构建")
            return EngineResult(
                LocalApiServer.BuiltinEngine(model.name),
                "内置自检引擎 · 缺少原生库",
                false,
            )
        }

        return try {
            val e = LlamaCppEngine(
                modelPath = model.path,
                policy = policy,
                templateId = prefs.promptTemplate,
            )
            e.load()
            if (policy.warmup) {
                log.info("预热中：触发权重页加载与 CPU 后端初始化…")
                e.warmup()
                log.info("预热完成，首 token 延迟会明显下降")
            }
            log.info("GGUF 已载入：${model.name}（${policy.threads} 线程 / ${policy.ctxSize} ctx / KV ${policy.kvQuant}）")
            EngineResult(e, "llama.cpp · 真实 GGUF 推理", true)
        } catch (t: Throwable) {
            log.error("GGUF 加载失败：${t.message ?: t.javaClass.simpleName}")
            log.warn("常见原因：内存不足、文件损坏、上下文过大；可在控制台切「省电」档后重试")
            EngineResult(
                LocalApiServer.BuiltinEngine(model.name),
                "内置自检引擎 · 模型加载失败",
                false,
            )
        }
    }

    /** Honest stub: never generates text, server answers 503 instead of faking output. */
    private class UnavailableEngine(
        private val id: String,
        private val fmt: String,
    ) : LocalApiServer.Engine {
        override fun modelId(): String = id
        override fun isLoaded(): Boolean = false
        override fun estimatePromptTokens(prompt: LocalApiServer.Prompt): Int = 0
        override fun generate(prompt: LocalApiServer.Prompt, sink: LocalApiServer.TokenSink): Int {
            throw IllegalStateException("$fmt 需要对应引擎插件")
        }
    }
}
