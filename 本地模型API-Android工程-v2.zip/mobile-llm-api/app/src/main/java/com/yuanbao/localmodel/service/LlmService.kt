package com.yuanbao.localmodel.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder // 🌟 修复1：补充了 IBinder 的引入
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.MainActivity
import com.yuanbao.localmodel.R
import com.yuanbao.localmodel.core.EngineFactory
import com.yuanbao.localmodel.core.PerfPolicy
import com.yuanbao.localmodel.engine.LlamaCppEngine
import com.yuanbao.localmodel.server.LocalApiServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface

class LlmService : Service() {

    companion object {
        const val ACTION_START = "com.yuanbao.localmodel.START"
        const val ACTION_STOP = "com.yuanbao.localmodel.STOP"
        const val ACTION_RESET_KEY = "com.yuanbao.localmodel.RESET_KEY"
        private const val CHANNEL = "llm_service"
        private const val NOTIF_ID = 1001

        fun start(ctx: Context) = ctx.startForegroundService(
            Intent(ctx, LlmService::class.java).setAction(ACTION_START))

        fun stop(ctx: Context) = ctx.startService(
            Intent(ctx, LlmService::class.java).setAction(ACTION_STOP))

        fun resetKey(ctx: Context) = ctx.startForegroundService(
            Intent(ctx, LlmService::class.java).setAction(ACTION_RESET_KEY))
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var server: LocalApiServer? = null
    private var llama: LlamaCppEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var tunnel: TunnelManager

    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
        tunnel = TunnelManager(this, AppGraph.logs)
        createChannel()
        observeFlows()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAll()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_RESET_KEY -> {
                AppGraph.prefs.resetApiKey()
                AppGraph.logs.info("API Key 已重置，服务重启中")
                stopAll()
                startAll()
            }
            else -> startAll()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopAll()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ lifecycle

    private fun startAll() {
        stopAll()
        AppGraph.refreshPolicy()
        val policy = AppGraph.policy.value ?: return
        val prefs = AppGraph.prefs

        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        val model = AppGraph.models.current()
        val result = EngineFactory.create(model, policy, prefs, AppGraph.logs)
        llama = result.engine as? LlamaCppEngine

        val cfg = LocalApiServer.Config().apply {
            host = if (prefs.lanMode) "0.0.0.0" else "127.0.0.1"
            port = prefs.port
            apiKey = prefs.apiKey()
            modelId = model?.name ?: "local-selfcheck"
            requestsPerMinute = 120
            maxConcurrent = policy.maxConcurrent
            sseBatchTokens = policy.sseBatchTokens
            sseBatchMs = policy.sseBatchMs
            maxTokensDefault = policy.appMaxTokens
            maxTokensHardCap = 2048
        }

        // Port collision: roll forward instead of failing outright.
        var attempts = 0
        while (attempts < 6) {
            try {
                val s = LocalApiServer(cfg, result.engine, AppGraph.logs)
                s.start()
                server = s
                break
            } catch (e: Exception) {
                attempts++
                cfg.port++
                AppGraph.logs.warn("端口 ${cfg.port - 1} 被占用，尝试 ${cfg.port}")
            }
        }

        if (server == null) {
            AppGraph.logs.error("端口全部被占用，服务启动失败")
        } else {
            holdWakeLock()
            if (prefs.tunnelMode != "off") {
                tunnel.start(cfg.port, prefs.tunnelMode, prefs.tunnelToken,
                    prefs.publicHostname, prefs.externalBase)
            }
            AppGraph.logs.info("本地 API 已就绪：${server!!.baseUrl()}")
        }
        publish(cfg, model, result.label, result.real, policy)
    }

    private fun stopAll() {
        tunnel.stop()
        try { server?.stop() } catch (t: Throwable) { }
        server = null
        try { llama?.close() } catch (t: Throwable) { }
        llama = null
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (t: Throwable) { }
        wakeLock = null
        AppGraph.update {
            it.copy(running = false, publicUrl = "", tunnelStatus = "未开启", streaming = false)
        }
        AppGraph.chat.cancel()
    }

    private fun publish(
        cfg: LocalApiServer.Config,
        model: com.yuanbao.localmodel.util.ModelInfo?,
        engineLabel: String,
        engineReal: Boolean,
        policy: PerfPolicy,
    ) {
        val lan = if (cfg.host == "0.0.0.0") "http://${lanIp()}:${cfg.port}" else ""
        AppGraph.update { s ->
            s.copy(
                running = server?.isRunning == true,
                port = cfg.port,
                lanMode = cfg.host == "0.0.0.0",
                perfMode = AppGraph.prefs.perfMode,
                promptTemplate = AppGraph.prefs.promptTemplate,
                tunnelMode = AppGraph.prefs.tunnelMode,
                tunnelToken = AppGraph.prefs.tunnelToken,
                publicHostname = AppGraph.prefs.publicHostname,
                externalBase = AppGraph.prefs.externalBase,
                localUrl = server?.baseUrl() ?: "",
                lanUrl = lan,
                apiKey = cfg.apiKey,
                modelName = model?.name ?: "未导入模型",
                modelSize = if (model != null) AppGraph.models.formatSize(model.sizeBytes) else "",
                modelPath = model?.path ?: "",
                modelFormat = model?.format?.label ?: "",
                engineName = engineLabel,
                engineReal = engineReal,
                deviceInfo = AppGraph.device.summary,
                policyInfo = com.yuanbao.localmodel.core.Accelerator.explain(policy, AppGraph.device),
            )
        }
    }

    private fun observeFlows() {
        scope.launch { AppGraph.logs.lines.collect { l -> AppGraph.update { it.copy(logs = l) } } }
        scope.launch { tunnel.url.collect { u -> AppGraph.update { it.copy(publicUrl = u) } } }
        scope.launch { tunnel.status.collect { t -> AppGraph.update { it.copy(tunnelStatus = t) } } }
    }

    // ------------------------------------------------------------------ notification / wake lock

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.notif_channel_desc)
            })
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun holdWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalModelAPI:inference").apply {
            setReferenceCounted(false)
            acquire(60 * 60 * 1000L)
        }
    }

    // 🌟 修复2：把 = try 改成了 { return try，用标准的块体写法，内部 return 合法了
    private fun lanIp(): String {
        return try {
            val nifs = NetworkInterface.getNetworkInterfaces()
            while (nifs.hasMoreElements()) {
                val addrs = nifs.nextElement().inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress ?: ""
                }
            }
            ""
        } catch (t: Throwable) {
            ""
        }
    }
}