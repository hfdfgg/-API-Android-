package com.yuanbao.localmodel

import android.app.Application
import android.content.Context
import com.yuanbao.localmodel.core.Accelerator
import com.yuanbao.localmodel.core.ChatController
import com.yuanbao.localmodel.core.DeviceProbe
import com.yuanbao.localmodel.core.DeviceProfile
import com.yuanbao.localmodel.core.PerfMode
import com.yuanbao.localmodel.core.PerfPolicy
import com.yuanbao.localmodel.util.LogBus
import com.yuanbao.localmodel.util.ModelRepository
import com.yuanbao.localmodel.util.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ChatLine(val role: String, val text: String)

data class UiState(
    val running: Boolean = false,
    val port: Int = 8080,
    val lanMode: Boolean = false,
    val perfMode: String = PerfMode.BALANCED.id,
    val promptTemplate: String = "auto",
    val tunnelMode: String = "off",
    val tunnelToken: String = "",
    val publicHostname: String = "",
    val externalBase: String = "",
    val tunnelStatus: String = "未开启",
    val publicUrl: String = "",
    val localUrl: String = "",
    val lanUrl: String = "",
    val apiKey: String = "",
    val modelName: String = "未导入模型",
    val modelSize: String = "",
    val modelPath: String = "",
    val modelFormat: String = "",
    val engineName: String = "",
    val engineReal: Boolean = false,
    val deviceInfo: String = "",
    val policyInfo: String = "",
    val logs: List<String> = emptyList(),
    val chat: List<ChatLine> = emptyList(),
    val streaming: Boolean = false,
    val firstTokenMs: Long = 0L,
    val tps: Double = 0.0,
)

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(applicationContext)
    }
}

/**
 * One process-wide graph. Activity, Service and background jobs all read/write
 * the same StateFlow; no business logic lives inside Composables.
 */
object AppGraph {
    private lateinit var ctx: Context

    /** Independent of any Activity/Compose lifecycle — chat requests survive tab switches. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val prefs: Prefs by lazy { Prefs(ctx) }
    val models: ModelRepository by lazy { ModelRepository(ctx) }
    val logs: LogBus by lazy { LogBus() }
    val device: DeviceProfile by lazy { DeviceProbe.detect(ctx) }
    val chat: ChatController by lazy { ChatController() }

    private val _policy = MutableStateFlow<PerfPolicy?>(null)
    val policy: StateFlow<PerfPolicy?> = _policy.asStateFlow()

    private val _state = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _state.asStateFlow()

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        refreshPolicy()
        update {
            it.copy(
                perfMode = prefs.perfMode,
                promptTemplate = prefs.promptTemplate,
                tunnelMode = prefs.tunnelMode,
                tunnelToken = prefs.tunnelToken,
                publicHostname = prefs.publicHostname,
                externalBase = prefs.externalBase,
                port = prefs.port,
                lanMode = prefs.lanMode,
                apiKey = prefs.apiKey(),
                deviceInfo = device.summary,
            )
        }
        val m = models.current()
        if (m != null) {
            update {
                it.copy(
                    modelName = m.name,
                    modelSize = models.formatSize(m.sizeBytes),
                    modelPath = m.path,
                    modelFormat = m.format.label,
                )
            }
        }
    }

    fun context(): Context = ctx

    fun refreshPolicy() {
        val p = Accelerator.policy(PerfMode.from(prefs.perfMode), device)
        _policy.value = p
        update { it.copy(policyInfo = Accelerator.explain(p, device)) }
    }

    fun update(block: (UiState) -> UiState) {
        _state.value = block(_state.value)
    }
}
