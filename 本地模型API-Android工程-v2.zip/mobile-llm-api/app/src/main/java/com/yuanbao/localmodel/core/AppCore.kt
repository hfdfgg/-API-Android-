package com.yuanbao.localmodel.core

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File

/** Single place for tunables. No magic numbers scattered across UI / service / engine. */
object AppConfig {
    const val DEFAULT_PORT = 8080
    const val MIN_PORT = 1024
    const val MAX_PORT = 65535

    const val RPM = 120
    const val MAX_BODY_BYTES = 1024 * 1024
    const val MAX_CONCURRENT = 8
    const val HARD_MAX_TOKENS = 2048

    // Stream micro-batching: 1 JNI callback / 1 SSE write per N tokens.
    const val JNI_BATCH_TOKENS = 6
    const val SSE_BATCH_TOKENS = 4
    const val SSE_BATCH_MS = 24

    const val CONNECT_TIMEOUT_MS = 5_000
    const val READ_TIMEOUT_MS = 180_000
}

// ---------------------------------------------------------------------------
// Device capability probe
// ---------------------------------------------------------------------------

data class DeviceProfile(
    val abis: List<String>,
    val totalCores: Int,
    val bigCores: Int,
    val totalMemMb: Long,
    val availMemMb: Long,
    val lowRam: Boolean,
    val sdk: Int,
    val model: String,
) {
    val is64Bit: Boolean get() = abis.any { it.contains("64") }
    val summary: String
        get() = "${Build.MANUFACTURER} $model · ${abis.firstOrNull() ?: "unknown"} · " +
                "${bigCores}大核/${totalCores}核 · ${totalMemMb / 1024}GB · Android $sdk"
}

object DeviceProbe {
    fun detect(ctx: Context): DeviceProfile {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val big = bigCoreCount().coerceIn(1, cores)
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val mi = ActivityManager.MemoryInfo()
        try { am?.getMemoryInfo(mi) } catch (t: Throwable) { }
        val totalMb = mi.totalMem / 1024 / 1024
        val availMb = mi.availMem / 1024 / 1024
        return DeviceProfile(
            abis = Build.SUPPORTED_ABIS.toList(),
            totalCores = cores,
            bigCores = big,
            totalMemMb = totalMb,
            availMemMb = availMb,
            lowRam = (am?.isLowRamDevice == true) || totalMb in 1..4096,
            sdk = Build.VERSION.SDK_INT,
            model = Build.MODEL,
        )
    }

    /** Count cores whose max frequency is >= 90% of the fastest core. */
    private fun bigCoreCount(): Int {
        val freqs = mutableListOf<Long>()
        for (i in 0..15) {
            val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
            if (!f.isFile) continue
            try { f.readText().trim().toLongOrNull()?.let { freqs.add(it) } } catch (t: Throwable) { }
        }
        if (freqs.isEmpty()) return (Runtime.getRuntime().availableProcessors() / 2).coerceAtLeast(1)
        val max = freqs.maxOrNull() ?: return 1
        return freqs.count { it >= max * 9 / 10 }.coerceAtLeast(1)
    }
}

// ---------------------------------------------------------------------------
// Accelerator
// ---------------------------------------------------------------------------

enum class PerfMode(val id: String, val label: String) {
    POWER_SAVE("power", "省电"),
    BALANCED("balanced", "均衡"),
    TURBO("turbo", "极速"),
    ;
    companion object {
        fun from(id: String) = values().firstOrNull { it.id == id } ?: BALANCED
    }
}

/**
 * One policy object drives EVERY layer that affects perceived speed:
 * native KV cache quantization, prefill batch, warmup, JNI/SSE micro-batching,
 * context size and the app's own max_tokens. No per-layer ad-hoc tuning.
 */
data class PerfPolicy(
    val threads: Int,
    val ctxSize: Int,
    val kvQuant: String,          // f16 | q8_0 | q4_0
    val nBatch: Int,
    val nUbatch: Int,
    val warmup: Boolean,
    val mmap: Boolean,
    val jniBatchTokens: Int,
    val sseBatchTokens: Int,
    val sseBatchMs: Int,
    val appMaxTokens: Int,
    val maxConcurrent: Int,
)

object Accelerator {
    fun policy(mode: PerfMode, d: DeviceProfile): PerfPolicy {
        // Low-memory / 32-bit phones: protect against OOM and thermal throttling.
        val constrained = d.lowRam || !d.is64Bit || d.totalMemMb in 1..4096
        val baseThreads = d.bigCores.coerceIn(2, 6)

        return when (mode) {
            PerfMode.POWER_SAVE -> PerfPolicy(
                threads = baseThreads.coerceAtMost(2),
                ctxSize = 1024,
                kvQuant = "q8_0",
                nBatch = 256, nUbatch = 64,
                warmup = false, mmap = true,
                jniBatchTokens = AppConfig.JNI_BATCH_TOKENS,
                sseBatchTokens = AppConfig.SSE_BATCH_TOKENS,
                sseBatchMs = AppConfig.SSE_BATCH_MS,
                appMaxTokens = 192,
                maxConcurrent = 2,
            )
            PerfMode.BALANCED -> PerfPolicy(
                threads = baseThreads.coerceAtMost(if (constrained) 4 else 6),
                ctxSize = if (constrained) 1024 else 2048,
                kvQuant = "q8_0",
                nBatch = 512, nUbatch = 128,
                warmup = true, mmap = true,
                jniBatchTokens = AppConfig.JNI_BATCH_TOKENS,
                sseBatchTokens = AppConfig.SSE_BATCH_TOKENS,
                sseBatchMs = AppConfig.SSE_BATCH_MS,
                appMaxTokens = 256,
                maxConcurrent = if (constrained) 2 else 4,
            )
            PerfMode.TURBO -> PerfPolicy(
                threads = d.bigCores.coerceIn(2, 8).coerceAtMost(if (constrained) 4 else 8),
                ctxSize = if (constrained) 2048 else 4096,
                kvQuant = "q8_0",
                nBatch = 512, nUbatch = 256,
                warmup = true, mmap = true,
                jniBatchTokens = (AppConfig.JNI_BATCH_TOKENS / 2).coerceAtLeast(2),
                sseBatchTokens = 2,
                sseBatchMs = 12,
                appMaxTokens = 512,
                maxConcurrent = if (constrained) 3 else AppConfig.MAX_CONCURRENT,
            )
        }
    }

    /** Human-readable reason shown in the UI, so the user knows why it's fast/slow. */
    fun explain(p: PerfPolicy, d: DeviceProfile): String {
        val kv = when (p.kvQuant) {
            "q8_0" -> "KV 8bit（带宽减半）"
            "q4_0" -> "KV 4bit（省内存）"
            else -> "KV F16"
        }
        return "${p.threads} 线程 · ${p.ctxSize} ctx · $kv · 预填 ${p.nBatch} · " +
                "预热${if (p.warmup) "开" else "关"} · 微批 ${p.jniBatchTokens}tok" +
                if (d.lowRam) " · 低内存保护已启用" else ""
    }
}

// ---------------------------------------------------------------------------
// Model formats
// ---------------------------------------------------------------------------

/**
 * Format routing. `runnable` is explicit: formats we do not actually execute are
 * never presented as working models. GGUF goes through llama.cpp; the others are
 * recognized, listed and clearly marked as needing an engine plugin.
 */
enum class ModelFormat(val label: String, val engine: String, val runnable: Boolean) {
    GGUF("GGUF", "llama.cpp", true),
    LITERT_LM("LiteRT / .task", "MediaPipe LLM（预留插件）", false),
    TFLITE("TFLite", "预留插件", false),
    ONNX("ONNX", "预留插件", false),
    MNN("MNN", "预留插件", false),
    UNKNOWN("未知格式", "无可用引擎", false),
}

object FormatDetector {
    fun detect(f: File): ModelFormat {
        val head = ByteArray(16)
        try {
            f.inputStream().use { it.read(head) }
        } catch (t: Throwable) {
            return ModelFormat.UNKNOWN
        }
        fun ascii(a: Int, b: Int) = String(head.copyOfRange(a, b), Charsets.US_ASCII)
        if (ascii(0, 4) == "GGUF") return ModelFormat.GGUF
        if (ascii(4, 8) == "TFL3") return ModelFormat.TFLITE
        val ext = f.name.substringAfterLast('.', "").lowercase()
        return when {
            head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() && ext in listOf("task", "litertlm") ->
                ModelFormat.LITERT_LM
            ext == "onnx" -> ModelFormat.ONNX
            ext == "mnn" -> ModelFormat.MNN
            ext == "gguf" -> ModelFormat.GGUF
            else -> ModelFormat.UNKNOWN
        }
    }
}
