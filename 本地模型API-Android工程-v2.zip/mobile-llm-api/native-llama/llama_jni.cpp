// JNI bridge: LocalApiServer.Engine <-> llama.cpp (CPU inference on Android).
// Built only with -PwithLlama=true. See native-llama/README.md.
//
// Performance work in this file:
//  * KV cache quantization (q8_0) halves decode memory bandwidth
//  * explicit prefill positions, large n_batch / n_ubatch
//  * warmup in a throwaway context -> no first-token mmap stall, no KV pollution
//  * token micro-batching: 1 JNI callback per N tokens instead of per token
//  * GGUF-native chat template via llama_chat_apply_template()

#include <jni.h>
#include <cstring>
#include <ctime>
#include <string>
#include <vector>
#include <cstdint>

#include "llama.h"
#include "ggml.h"
#include <android/log.h>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "llama_jni", __VA_ARGS__)
#define SEP '\x01'

namespace {

struct EngineCtx {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    int n_threads = 0;
};

static inline EngineCtx *as_ctx(jlong h) { return reinterpret_cast<EngineCtx *>(h); }

static size_t utf8_len(unsigned char c) {
    if (c < 0x80) return 1;
    if ((c & 0xE0) == 0xC0) return 2;
    if ((c & 0xF0) == 0xE0) return 3;
    if ((c & 0xF8) == 0xF0) return 4;
    return 1;
}

/** Move complete code points from `pending` into `out`; keep the dangling tail. */
static void drain_utf8(std::string &pending, std::string &out, bool force) {
    size_t i = 0;
    while (i < pending.size()) {
        const size_t n = utf8_len(static_cast<unsigned char>(pending[i]));
        if (i + n > pending.size()) break;
        out.append(pending, i, n);
        i += n;
    }
    pending.erase(0, i);
    if (force && !pending.empty()) {
        out.append(pending);
        pending.clear();
    }
}

/** One JNI callback for the whole accumulated string. Returns false on disconnect / abort. */
static bool emit(JNIEnv *env, jobject sink, jmethodID mid, std::string &out) {
    if (out.empty()) return true;
    jstring js = env->NewStringUTF(out.c_str());
    out.clear();
    if (js == nullptr) return false;
    env->CallVoidMethod(sink, mid, js);
    env->DeleteLocalRef(js);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();   // client disconnected mid-stream
        return false;
    }
    return true;
}

static std::vector<llama_token> tokenize(const llama_vocab *vocab,
                                         const char *text, bool add_special) {
    const int32_t len = static_cast<int32_t>(std::strlen(text));
    std::vector<llama_token> out(static_cast<size_t>(len) + 16);
    int32_t n = llama_tokenize(vocab, text, len, out.data(),
                               static_cast<int32_t>(out.size()), add_special, true);
    if (n < 0) {
        out.resize(static_cast<size_t>(-n));
        n = llama_tokenize(vocab, text, len, out.data(),
                           static_cast<int32_t>(out.size()), add_special, true);
    }
    if (n < 0) return {};
    out.resize(static_cast<size_t>(n));
    return out;
}

static bool decode_with_positions(llama_context *ctx,
                                  const std::vector<llama_token> &tokens,
                                  llama_pos start_pos) {
    if (tokens.empty()) return true;
    std::vector<llama_pos> pos(tokens.size());
    for (size_t i = 0; i < tokens.size(); ++i) {
        pos[i] = static_cast<llama_pos>(start_pos + static_cast<llama_pos>(i));
    }
    llama_batch b = llama_batch_get_one(tokens.data(), static_cast<int32_t>(tokens.size()));
    b.pos = pos.data();
    return llama_decode(ctx, b) == 0;
}

/** Split "role SEP content SEP role SEP content SEP" into llama_chat_message[]. */
static std::vector<llama_chat_message> parse_chat(const std::string &flat,
                                                  std::vector<std::string> &storage) {
    // IMPORTANT: copy all strings into stable storage BEFORE taking any c_str(),
    // otherwise vector reallocation would leave dangling pointers.
    size_t start = 0;
    while (true) {
        size_t p = flat.find(SEP, start);
        if (p == std::string::npos) break;
        storage.push_back(flat.substr(start, p - start));
        start = p + 1;
    }
    std::vector<llama_chat_message> msgs;
    for (size_t i = 0; i + 1 < storage.size(); i += 2) {
        llama_chat_message m;
        m.role = storage[i].c_str();
        m.content = storage[i + 1].c_str();
        msgs.push_back(m);
    }
    return msgs;
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeLoad(
        JNIEnv *env, jobject, jstring jpath, jint threads, jint n_ctx,
        jstring jkv, jint n_batch, jint n_ubatch) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    const char *kv = env->GetStringUTFChars(jkv, nullptr);
    if (path == nullptr || kv == nullptr) return 0;

    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;    // CPU-only: portable across every phone
    mp.use_mmap = true;     // never copy a multi-GB model into RAM

    llama_model *model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (model == nullptr) {
        LOGE("llama_model_load_from_file failed");
        env->ReleaseStringUTFChars(jkv, kv);
        llama_backend_free();
        return 0;
    }

    ggml_type kv_type = GGML_TYPE_Q8_0;
    if (std::strcmp(kv, "f16") == 0) kv_type = GGML_TYPE_F16;
    else if (std::strcmp(kv, "q4_0") == 0) kv_type = GGML_TYPE_Q4_0;
    else if (std::strcmp(kv, "q8_0") == 0) kv_type = GGML_TYPE_Q8_0;
    env->ReleaseStringUTFChars(jkv, kv);

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = n_ctx;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    cp.n_batch = n_batch;
    cp.n_ubatch = n_ubatch;
    cp.type_k = kv_type;    // KV quantization: main decode bandwidth win
    cp.type_v = kv_type;

    llama_context *ctx = llama_init_from_model(model, cp);
    if (ctx == nullptr) {
        LOGE("llama_init_from_model failed");
        llama_model_free(model);
        llama_backend_free();
        return 0;
    }

    auto *c = new EngineCtx();
    c->model = model;
    c->ctx = ctx;
    c->vocab = llama_model_get_vocab(model);
    c->n_ctx = n_ctx;
    c->n_threads = threads;
    return reinterpret_cast<jlong>(c);
}

JNIEXPORT void JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeWarmup(
        JNIEnv *, jobject, jlong handle) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->model == nullptr || c->vocab == nullptr) return;

    // Throwaway context: warms mmap pages + CPU backend, leaves the real KV empty.
    llama_context_params wp = llama_context_default_params();
    wp.n_ctx = 32;
    wp.n_threads = c->n_threads;
    wp.n_threads_batch = c->n_threads;
    wp.n_batch = 32;
    wp.n_ubatch = 32;
    wp.type_k = GGML_TYPE_Q8_0;
    wp.type_v = GGML_TYPE_Q8_0;
    llama_context *wctx = llama_init_from_model(c->model, wp);
    if (wctx == nullptr) return;
    auto toks = tokenize(c->vocab, "Hello", true);
    decode_with_positions(wctx, toks, 0);
    llama_free(wctx);
}

/** Returns the GGUF's own rendered chat prompt, or null when the model has no template. */
JNIEXPORT jstring JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeRenderChat(
        JNIEnv *env, jobject, jlong handle, jstring jflat) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->model == nullptr || jflat == nullptr) return nullptr;

    const char *raw = env->GetStringUTFChars(jflat, nullptr);
    if (raw == nullptr) return nullptr;
    std::string flat(raw);
    env->ReleaseStringUTFChars(jflat, raw);

    const char *tmpl = llama_model_chat_template(c->model, nullptr);
    if (tmpl == nullptr || tmpl[0] == '\0') return nullptr;

    std::vector<std::string> storage;
    auto msgs = parse_chat(flat, storage);
    if (msgs.empty()) return nullptr;

    // Probe with a small non-null buffer: upstream returns the required size
    // when the buffer is too small. Some versions reject nullptr outright.
    char probe[8] = {0};
    int32_t need = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(),
                                             true, probe, sizeof(probe));
    if (need <= 0) return nullptr;
    std::vector<char> buf(static_cast<size_t>(need) + 16);
    int32_t n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true,
                                          buf.data(), static_cast<int32_t>(buf.size()));
    if (n < 0 || n >= static_cast<int32_t>(buf.size())) return nullptr;
    buf[static_cast<size_t>(n)] = '\0';
    return env->NewStringUTF(buf.data());
}

JNIEXPORT void JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeFree(
        JNIEnv *, jobject, jlong handle) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr) return;
    if (c->ctx) llama_free(c->ctx);
    if (c->model) llama_model_free(c->model);
    llama_backend_free();
    delete c;
}

JNIEXPORT jint JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeTokenCount(
        JNIEnv *env, jobject, jlong handle, jstring jtext) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->vocab == nullptr || jtext == nullptr) return 0;
    const char *text = env->GetStringUTFChars(jtext, nullptr);
    if (text == nullptr) return 0;
    auto tokens = tokenize(c->vocab, text, true);
    env->ReleaseStringUTFChars(jtext, text);
    return static_cast<jint>(tokens.size());
}

JNIEXPORT jint JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeGenerate(
        JNIEnv *env, jobject, jlong handle, jstring jprompt,
        jint max_tokens, jfloat temperature, jfloat top_p,
        jint jni_batch, jobject sink) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->ctx == nullptr || c->vocab == nullptr || sink == nullptr) return 0;

    jclass sink_cls = env->GetObjectClass(sink);
    jmethodID on_token = env->GetMethodID(sink_cls, "onToken", "(Ljava/lang/String;)V");
    env->DeleteLocalRef(sink_cls);
    if (on_token == nullptr) return 0;

    const char *prompt = env->GetStringUTFChars(jprompt, nullptr);
    if (prompt == nullptr) return 0;
    auto tokens = tokenize(c->vocab, prompt, true);
    env->ReleaseStringUTFChars(jprompt, prompt);
    if (tokens.empty()) return 0;
    if (static_cast<int>(tokens.size()) >= c->n_ctx - 8) {
        LOGE("prompt exceeds n_ctx");
        return 0;
    }
    if (!decode_with_positions(c->ctx, tokens, 0)) {
        LOGE("prefill decode failed");
        return 0;
    }

    // Standard upstream sampler order: shape distribution, then sample.
    llama_sampler *sp = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temperature <= 0.0f) {
        llama_sampler_chain_add(sp, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(sp, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(sp, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(sp, llama_sampler_init_dist(
                static_cast<uint32_t>(std::time(nullptr))));
    }

    const int batch_n = jni_batch > 0 ? jni_batch : 6;
    llama_pos pos = static_cast<llama_pos>(tokens.size());
    std::string pending, outgoing;
    int since_emit = 0;
    int generated = 0;

    for (int i = 0; i < max_tokens; ++i) {
        llama_token id = llama_sampler_sample(sp, c->ctx, -1);
        llama_sampler_accept(sp, id);
        if (llama_vocab_is_eog(c->vocab, id)) break;

        std::vector<char> piece(32);
        int32_t n = llama_token_to_piece(c->vocab, id, piece.data(),
                                         static_cast<int32_t>(piece.size()), 0, true);
        if (n < 0) {
            piece.resize(static_cast<size_t>(-n));
            n = llama_token_to_piece(c->vocab, id, piece.data(),
                                     static_cast<int32_t>(piece.size()), 0, true);
        }
        if (n > 0) pending.append(piece.data(), static_cast<size_t>(n));
        drain_utf8(pending, outgoing, false);
        ++generated;
        ++since_emit;

        // Micro-batch: fewer JNI crossings, fewer Java-side SSE writes.
        if (since_emit >= batch_n || outgoing.size() >= 48) {
            if (!emit(env, sink, on_token, outgoing)) break;
            since_emit = 0;
        }

        llama_token next = id;
        llama_pos step_pos = pos;
        llama_batch step = llama_batch_get_one(&next, 1);
        step.pos = &step_pos;
        if (llama_decode(c->ctx, step) != 0) break;
        ++pos;
        if (pos >= c->n_ctx) break;
    }

    drain_utf8(pending, outgoing, true);
    emit(env, sink, on_token, outgoing);
    llama_sampler_free(sp);
    return generated;
}

} // extern "C"
