# 真机 GGUF 推理引擎（可选）

默认 APK **不含**本模块：CI 用零 NDK 依赖的方式快速出包，APP 会明确显示「内置自检引擎」，不伪装成真实模型。你上一版截图里 `engine=LlamaCppEngine` 说明已经带过这个库，保持同样构建方式即可。

## 构建

```bash
sdkmanager --install "ndk;27.0.12077973" "cmake;3.22.1"
./gradlew assembleDebug -PwithLlama=true
# 需要更多机型：
./gradlew assembleDebug -PwithLlama=true -Pabis=arm64-v8a,armeabi-v7a,x86_64
```

或在 GitHub Actions 手动运行 workflow，把 `with_llama` 选为 `true`。

`CMakeLists.txt` 用 `FetchContent` 拉取固定 tag 的 `ggml-org/llama.cpp`（默认 `v0.9.0`，`-DLLAMA_CPP_TAG=` 可覆盖），CPU-only（`n_gpu_layers=0`），并对 **所有** `.so` 加 `-z max-page-size=16384`——Android 15 新机（含新 vivo / OPPO）要求 16KB 页对齐，不对齐会直接装不上或加载失败。

## 运行链路（v2）

```
LocalApiServer.Engine.generate(Prompt, TokenSink) -> int
        │  Kotlin: auto 模板渲染（nativeRenderChat）
        ▼
LlamaCppEngine.nativeGenerate()
        │  JNI，llama_jni.cpp
        ▼
tokenize → llama_decode(prefill, 显式 pos) → sampler 链
        │  每 6 个 token 合并成一段文本
        ▼
UTF-8 边界缓冲 → 1 次 TokenSink.onToken(String)（含多个 token）
        ▼
服务端 MicroBatchSink 再按 4 token / 24ms 合并 → 1 次 SSE chunk
```

跨层调用从「每 token 一次 JNI + 一次 SSE 写 + 一次 flush」降到约 1/6 与 1/4，首片仍立即发出，首字节延迟不受影响。

## 关键实现点

- **KV cache 量化**：`cp.type_k/type_v = GGML_TYPE_Q8_0`（可切 `q4_0` / `f16`）。decode 阶段主要吃内存带宽，KV 减半通常是最明显的一项提速，精度损失很小。
- **预热**：`nativeWarmup` 用**独立的 32-token 临时 context** 跑一次短 prefill，触发 mmap 缺页与 CPU 后端初始化，不污染主 context 的 KV，避免首 token 卡顿。
- **自动 chat template**：`nativeRenderChat` 调用 `llama_model_chat_template()` 取 GGUF 自带模板，再用 `llama_chat_apply_template()` 渲染；覆盖 Qwen / Llama3 / Gemma / Phi / Mistral / DeepSeek。Kotlin 侧用 `\u0001` 分隔 role/content 传给 native，避免手写模板错配。模型没有内置模板时回退到本地 `chatml / llama3 / gemma / phi / raw`。
- **prefill 必须显式设置 `pos`**：`llama_batch_get_one` 只填 token；不设置会让所有 token 落在位置 0，输出乱码。
- **UTF-8 边界**：中文一个字 3 字节，token 可能切在字符中间；`pending` 只吐完整码点，流结束强制冲刷残留。
- **客户端断开**：`onToken` 抛异常时清掉 JNI 异常并结束生成，不卡死线程。
- **采样链**：`temp → top_p → dist`，`llama_sampler_sample` 返回最终 argmax；`temperature<=0` 走纯 greedy。
- 每个请求独立 sampler，支持 API 传入的 `temperature` / `top_p` / `max_tokens`。

## 模型与模板

- 只**执行** GGUF（推荐 Q4_K_M / Q3_K_M，7B 以内、内存 ≥ 8GB）。其他格式（`.task` / TFLite / ONNX / MNN）可以导入和管理，APP 会明确标注「引擎未接入」，不会假装推理。
- 控制台「提示词模板」默认 `auto`，即读取 GGUF 自带模板；只有当模型没有模板或输出格式明显不对时才手动切。
- 「省电 / 均衡 / 极速」三档由 `core/AppCore.kt` 的 `PerfPolicy` 统一决定线程、ctx、KV 类型、批大小、微批与并发，改一档全部生效，不需要在多个地方分别调。

## 排错

| 现象 | 原因 / 处理 |
| --- | --- |
| 「未检测到 libllama_jni.so」 | 没带 `-PwithLlama=true`，或 so 不在当前 ABI 目录 |
| 安装失败 / `load failed` on Android 15 | `.so` 未 16KB 对齐，确认用了本仓库 CMakeLists |
| 「模型加载失败」 | 非 GGUF / 文件损坏 / 内存不足，切「省电」档或换更小量化 |
| 「prompt exceeds n_ctx」 | 调大上下文或缩短对话历史 |
| 输出乱码 | 把模板切回 `auto`；若模型无内置模板再试对应手写模板 |
| 速度慢 / 发热 | 减小模型、降低 ctx、减少线程、插电、关闭省电模式；看响应 `local_timings` 的真实 tok/s |
| 切页后对话中断 | 已由 `AppGraph.appScope` 修复；若复现请检查是否用了旧版 APK |

## 诚实说明

这条编译链依赖 llama.cpp 上游头文件（`llama_model_chat_template` / `llama_chat_apply_template` / `llama_sampler_*` / `llama_batch_get_one`），不同 tag 之间偶有改名。我这边**没有 Android NDK 与真机**，`-PwithLlama=true` 的编译结果和真机吐字需要你按上面步骤验证；若上游 API 变动，只改 `llama_jni.cpp` 里对应调用即可，服务端与 UI 层完全不用动——这正是把推理做成可插拔 `Engine` 接口的原因。
