#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v2 工程静态校验：XML / Gradle / CI / 资源引用 / Kotlin 词法 / 合规 / 常量一致性"""
import re, sys
import xml.etree.ElementTree as ET
from pathlib import Path
from vcheck import ROOT, ok, sec, finish, lex

sec('1. 工程文件')
need = ['settings.gradle', 'build.gradle', 'gradle.properties', 'app/build.gradle',
        'app/src/main/AndroidManifest.xml', '.github/workflows/build.yml', 'README.md',
        'tools/selfcheck.py', 'tools/verify_project.py', 'tools/verify_offline_site.py',
        'tools/verify_dedupe.py', 'tools/verify_bridge.py', 'tools/verify_regex.py', 'tools/verify_api.py',
        'docs/架构与数据边界.md', 'docs/战场功能说明书.md', 'docs/合规声明.md',
        'app/src/main/assets/index.html', 'app/src/main/assets/avatar.png',
        'app/src/main/assets/avatar_square.png', 'sample/sample.pcap']
for f in need:
    p = ROOT / f
    ok(p.exists() and p.stat().st_size > 0, f, p.stat().st_size if p.exists() else 'missing')
kt = sorted((ROOT / 'app/src/main/java/com/zsm/terminal').glob('*.kt'))
ok(len(kt) >= 20, 'Kotlin 源文件 >= 20 个', len(kt))
for dead in ['Ui.kt', 'SupabaseClient.kt']:
    ok(not (ROOT / 'app/src/main/java/com/zsm/terminal' / dead).exists(),
       '旧 demo 文件已移除 ' + dead)

sec('2. XML / 资源引用')
xmls = list((ROOT / 'app/src/main/res').rglob('*.xml')) + [ROOT / 'app/src/main/AndroidManifest.xml']
for x in xmls:
    try:
        ET.parse(x); ok(True, 'XML 合法 ' + str(x.relative_to(ROOT)))
    except Exception as e:
        ok(False, 'XML 合法 ' + str(x.relative_to(ROOT)), e)
allkt = '\n'.join(f.read_text(encoding='utf-8') for f in kt)
allxml = '\n'.join(p.read_text(encoding='utf-8') for p in xmls)
# 代码里引用的 R.drawable / R.mipmap / R.string / R.color 必须存在
for kind, prefix, suffix in [('drawable', 'R.drawable.', '.xml'),
                             ('string', 'R.string.', ''),
                             ('color', 'R.color.', '')]:
    used = set(re.findall(r'(?<!android\.)' + re.escape(prefix) + r'(\w+)', allkt))
    if kind == 'drawable':
        have = {p.stem for p in (ROOT / 'app/src/main/res/drawable').glob('*.xml')}
    elif kind == 'string':
        have = set(re.findall(r'<string name="(\w+)"', allxml))
    else:
        have = set(re.findall(r'<color name="(\w+)"', allxml))
    miss = used - have
    ok(not miss, '资源引用齐全 R.%s' % kind, miss)
for ref in ['@mipmap/ic_launcher', '@mipmap/ic_launcher_round', '@string/app_name',
            '@style/AppTheme', '@color/bg', '@mipmap/ic_launcher_foreground']:
    ok(ref in allxml, 'XML 引用 ' + ref)
for cls in ['.ZsmApp', '.MainActivity', '.CaptureService']:
    stem = cls[1:]
    ok((ROOT / ('app/src/main/java/com/zsm/terminal/' + stem + '.kt')).exists(),
       'Manifest 类存在 ' + cls)

sec('3. 合规（用户明确要求：不要无障碍，会封号）')
man = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
ok(not re.search(r'<uses-permission[^>]*ACCESSIBILITY', man, re.I), 'Manifest 无无障碍权限声明')
ok(not re.search(r'<service[^>]*accessibility', man, re.I), 'Manifest 无无障碍服务注册')
ok(not re.search(r':\s*AccessibilityService|extends AccessibilityService', allkt), '源码未继承无障碍服务')
ok(not re.search(r'MediaProjectionManager|createScreenCaptureIntent', allkt), '无系统录屏调用')
ok('usesCleartextTraffic="false"' in man, '禁用明文流量')
ok('无障碍' in man or '合规声明' in man, 'Manifest 写明合规声明')
for kw in ['不模拟点击', '不读取游戏界面', '不使用无障碍']:
    ok(any(kw in f.read_text(encoding='utf-8') for f in kt), '源码/文档含声明 ' + kw)
ok('SYSTEM_ALERT_WINDOW' in man, '保留悬浮窗权限')

sec('4. Gradle / CI')
g = (ROOT / 'app/build.gradle').read_text(encoding='utf-8')
ok('buildConfig = true' in g, 'AGP 8 显式开启 BuildConfig')
ok('versionCode 2' in g and '2.0.0' in g, '版本号 v2.0.0')
ok('androidx.webkit:webkit' in g, '离线站点用 WebViewAssetLoader')
ok('namespace' in g and 'compileSdk 34' in g and 'minSdk 26' in g, 'SDK 版本')
wf_text = (ROOT / '.github/workflows/build.yml').read_text(encoding='utf-8')
try:
    import yaml
    wf = yaml.safe_load(wf_text)
    steps = wf['jobs']['build']['steps']
    ok(True, 'workflow YAML 解析')
    runs = '\n'.join(str(s.get('run', '')) for s in steps)
    for key in ['assembleDebug', 'selfcheck.py', 'verify_project.py',
                'verify_offline_site.py', 'verify_dedupe.py', 'verify_bridge.py']:
        ok(key in runs, 'CI 跑 ' + key)
    ok(any('upload-artifact' in str(s.get('uses', '')) for s in steps), 'CI 上传 APK')
    ok(any('setup-android' in str(s.get('uses', '')) for s in steps), 'CI 装 Android SDK')
    ok(any('gradle wrapper' in str(s.get('run', '')) for s in steps), 'CI 自举 Wrapper')
except ImportError:
    ok(True, 'workflow YAML（无 PyYAML，退回文本断言）')
    for key in ['assembleDebug', 'verify_offline_site.py', 'verify_dedupe.py', 'upload-artifact']:
        ok(key in wf_text, 'CI 含 ' + key)

sec('5. Kotlin 词法')
for f in kt:
    src = f.read_text(encoding='utf-8')
    err = lex(src)
    ok(err is None, '词法/括号 ' + f.name, err)
    ok('""""' not in src, '无 raw string 四引号边界 ' + f.name)
for kw in ['val def:', 'fun object', 'var class ', 'val class ', '{ on, ->']:
    ok(kw not in allkt, '无关键字/语法误用 ' + kw)

sec('6. 常量与接线')
svc = (ROOT / 'app/src/main/java/com/zsm/terminal/CaptureService.kt').read_text(encoding='utf-8')
act = (ROOT / 'app/src/main/java/com/zsm/terminal/MainActivity.kt').read_text(encoding='utf-8')
for a in ['ACTION_START', 'ACTION_STOP', 'ACTION_SHOW_OVERLAY', 'ACTION_HIDE_OVERLAY',
          'ACTION_IMPORT', 'ACTION_SYNC', 'ACTION_MUSIC', 'ACTION_CLEAR']:
    ok(('const val ' + a) in svc, 'CaptureService 定义 ' + a)
used = set(re.findall(r'CaptureService\.(ACTION_\w+)', act))
defined = set(re.findall(r'const val (ACTION_\w+)', svc))
ok(used <= defined, 'Activity 未引用未定义常量', used - defined)
ok('ACTION_GO_VIP' in act and 'ACTION_GO_VIP' in (ROOT / 'app/src/main/java/com/zsm/terminal/OverlayManager.kt').read_text(encoding='utf-8'),
   '悬浮窗 → VIP 页 深链一致')
for sym in ['WebViewAssetLoader', 'addJavascriptInterface', 'ZsmNative',
            'appassets.androidplatform.net']:
    ok(sym in act, 'WebView 离线宿主接线 ' + sym)
for sym in ['TeamCardBus.attach', 'PacketImporter(', 'BattleStore(', 'LocalVault(']:
    ok(sym in act, 'MainActivity 接线 ' + sym)

sec('7. VIP 门禁 / 本地存储边界')
ov = (ROOT / 'app/src/main/java/com/zsm/terminal/OverlayManager.kt').read_text(encoding='utf-8')
bc = (ROOT / 'app/src/main/java/com/zsm/terminal/BattleCenterView.kt').read_text(encoding='utf-8')
ok('settings.isVip()' in ov and 'settings.isVip()' in bc, '悬浮窗与战场搜索均有 VIP 门禁')
ok('ClipboardManager' in ov and 'clipboardPick' in ov, '剪贴板取词（零权限）')
ok('importTexts' in svc and 'importTexts' in (ROOT / 'app/src/main/java/com/zsm/terminal/PacketImporter.kt').read_text(encoding='utf-8'),
   '实时流写入本地账包')
ok('Crypto.encryptStream' in (ROOT / 'app/src/main/java/com/zsm/terminal/LocalVault.kt').read_text(encoding='utf-8'),
   '账包分块加密')
ok('fp TEXT PRIMARY KEY' in (ROOT / 'app/src/main/java/com/zsm/terminal/BattleStore.kt').read_text(encoding='utf-8'),
   '去重主键 fp')
cs = (ROOT / 'app/src/main/java/com/zsm/terminal/CaptureService.kt').read_text(encoding='utf-8')
ok(not any(k in cs for k in ['dbClient', 'supabase.rpc', 'save_battles', 'createClient']),
   '前台服务不写云端库')
ok('不上传' in bc or '不上传' in (ROOT / 'app/src/main/java/com/zsm/terminal/VaultView.kt').read_text(encoding='utf-8'),
   '界面写明「不上传数据库」')

sec('8. 9 组白名单双端一致')
names = (ROOT / 'app/src/main/java/com/zsm/terminal/Names.kt').read_text(encoding='utf-8')
selfc = (ROOT / 'tools/selfcheck.py').read_text(encoding='utf-8')
for gname in ['武陵', '天门', '桂阳', '长沙', '南', '襄阳', '南阳', '江夏', '铺路组']:
    ok(('"' + gname + '"') in names and ("'" + gname + "'") in selfc,
       '9 组白名单双端一致 ' + gname)
ok('6 to "武陵"' in names and '50 to "铺路组"' in names, 'gid 映射完整')

sec('9. 样本 pcap')
data = (ROOT / 'sample/sample.pcap').read_bytes()
ok(data[:4] == b'\xd4\xc3\xb2\xa1', '样本是 little-endian classic pcap', data[:4].hex())
ok(len(data) > 200, '样本非空', len(data))

finish('v2 工程静态校验')
