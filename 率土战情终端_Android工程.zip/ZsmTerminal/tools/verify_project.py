#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""工程静态校验：XML / YAML / 资源引用 / Kotlin 词法 / 常量一致性。
沙盒没有 Android SDK 时也能跑，CI 里紧接 selfcheck 之后执行。
"""
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ok_n, bad_n = 0, 0

def ok(c, msg, extra=''):
    global ok_n, bad_n
    if c:
        ok_n += 1
        print('  OK  ' + msg)
    else:
        bad_n += 1
        print('  FAIL ' + msg + ((' :: ' + str(extra)) if extra else ''))

def sec(t): print('\n=== ' + t + ' ===')

# ---- 1. 必备文件 ----
sec('1. 工程文件')
need = ['settings.gradle', 'build.gradle', 'gradle.properties', 'app/build.gradle',
        'app/src/main/AndroidManifest.xml', '.github/workflows/build.yml',
        'README.md', 'tools/selfcheck.py', 'docs/数据结构与接口.md',
        'sample/sample.pcap']
for f in need:
    p = ROOT / f
    ok(p.exists() and p.stat().st_size > 0, f, p.stat().st_size if p.exists() else 'missing')
kt = sorted((ROOT / 'app/src/main/java/com/zsm/terminal').glob('*.kt'))
ok(len(kt) == 14, 'Kotlin 源文件 14 个', len(kt))

# ---- 2. XML ----
sec('2. XML / 资源引用')
xmls = list((ROOT / 'app/src/main/res').rglob('*.xml')) + [ROOT / 'app/src/main/AndroidManifest.xml']
for x in xmls:
    try:
        ET.parse(x)
        ok(True, 'XML 合法 ' + str(x.relative_to(ROOT)))
    except Exception as e:
        ok(False, 'XML 合法 ' + str(x.relative_to(ROOT)), e)
manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
for ref in ['@mipmap/ic_launcher', '@string/app_name', '@style/AppTheme',
            '@color/accent', '@drawable/ic_launcher_foreground', '@color/ic_bg']:
    ok(ref in ''.join(p.read_text(encoding='utf-8') for p in xmls), '资源引用存在 ' + ref)
for cls in ['.ZsmApp', '.MainActivity', '.CaptureService']:
    stem = cls[1:]
    ok((ROOT / ('app/src/main/java/com/zsm/terminal/' + stem + '.kt')).exists(),
       'Manifest 声明的类存在 ' + cls)
ok('android.permission.SYSTEM_ALERT_WINDOW' in manifest, '悬浮窗权限')
ok('android.permission.FOREGROUND_SERVICE' in manifest, '前台服务权限')
ok('android.permission.INTERNET' in manifest, '网络权限')

# ---- 3. Gradle / CI ----
sec('3. Gradle / CI')
g = (ROOT / 'app/build.gradle').read_text(encoding='utf-8')
ok('buildConfig = true' in g, 'AGP 8 显式开启 BuildConfig')
ok('namespace' in g and "compileSdk 34" in g and "minSdk 26" in g, 'SDK 版本')
ok("id 'org.jetbrains.kotlin.android'" in g, 'Kotlin 插件')
ok('DEFAULT_SB_URL' in g and 'DEFAULT_SB_KEY' in g, 'BuildConfig 默认 Supabase 常量')
wf_text = (ROOT / '.github/workflows/build.yml').read_text(encoding='utf-8')
try:
    import yaml
    wf = yaml.safe_load(wf_text)
    steps = wf['jobs']['build']['steps']
    ok(True, 'workflow YAML 解析')
    ok(any('assembleDebug' in str(st.get('run', '')) for st in steps), 'CI 编译 Debug APK')
    ok(any('verify_project.py' in str(st.get('run', '')) for st in steps), 'CI 跑工程静态校验')
    ok(any('selfcheck' in str(st.get('run', '')) for st in steps), 'CI 跑解析链路自测')
    ok(any('upload-artifact' in str(st.get('uses', '')) for st in steps), 'CI 上传 APK 产物')
    ok(any('gradle wrapper' in str(st.get('run', '')) for st in steps), 'CI 自举 Gradle Wrapper')
    ok(any('setup-android' in str(st.get('uses', '')) for st in steps), 'CI 装 Android SDK')
except ImportError:
    # runner 没装 PyYAML 也能校验：退回文本断言
    ok(True, 'workflow YAML 解析（无 PyYAML，退回文本断言）')
    for key in ['assembleDebug', 'verify_project.py', 'selfcheck.py',
                'upload-artifact', 'gradle wrapper', 'setup-android']:
        ok(key in wf_text, 'CI 含 ' + key)
except Exception as e:
    ok(False, 'workflow YAML 解析', e)

# ---- 4. Kotlin 词法（字符串闭合 / 括号平衡 / 四引号边界）----
sec('4. Kotlin 静态词法')
def lex(src):
    i, n = 0, len(src)
    stack = []
    pairs = {')': '(', ']': '[', '}': '{'}
    line = 1
    while i < n:
        c = src[i]
        if c == '\n': line += 1; i += 1; continue
        # 行注释
        if c == '/' and i + 1 < n and src[i + 1] == '/':
            j = src.find('\n', i)
            i = n if j < 0 else j
            continue
        # 块注释
        if c == '/' and i + 1 < n and src[i + 1] == '*':
            j = src.find('*/', i + 2)
            if j < 0: return '块注释未闭合 @%d' % line
            line += src[i:j].count('\n'); i = j + 2; continue
        # raw string
        if src.startswith('"""', i):
            j = src.find('"""', i + 3)
            if j < 0: return 'raw 字符串未闭合 @%d' % line
            line += src[i:j].count('\n'); i = j + 3; continue
        # 普通字符串
        if c == '"':
            i += 1; closed = False
            while i < n:
                if src[i] == '\\': i += 2; continue
                if src[i] == '"': closed = True; i += 1; break
                if src[i] == '\n': return '普通字符串跨行未闭合 @%d' % line
                i += 1
            if not closed: return '普通字符串未闭合 @%d' % line
            continue
        # 字符字面量
        if c == "'":
            i += 1
            while i < n and src[i] != "'":
                if src[i] == '\\': i += 2; continue
                i += 1
            i += 1; continue
        if c in '([{': stack.append((c, line))
        elif c in ')]}':
            if not stack or stack[-1][0] != pairs[c]:
                return '括号不匹配 %s @%d' % (c, line)
            stack.pop()
        i += 1
    if stack: return '括号未闭合 %s @%d' % (stack[-1][0], stack[-1][1])
    return None

for f in kt:
    src = f.read_text(encoding='utf-8')
    err = lex(src)
    ok(err is None, '词法/括号 ' + f.name, err)
    ok('""""' not in src, '无 raw string 四引号边界 ' + f.name)

allkt = '\n'.join(f.read_text(encoding='utf-8') for f in kt)
for kw in ['val def:', 'fun object', 'var class ', 'val class ']:
    ok(kw not in allkt, '无关键字误用 ' + kw)

# ---- 5. 常量 / 引用一致性 ----
sec('5. 常量与引用一致性')
svc = (ROOT / 'app/src/main/java/com/zsm/terminal/CaptureService.kt').read_text(encoding='utf-8')
act = (ROOT / 'app/src/main/java/com/zsm/terminal/MainActivity.kt').read_text(encoding='utf-8')
for a in ['ACTION_START', 'ACTION_STOP', 'ACTION_FILE', 'ACTION_SHOW_OVERLAY',
          'ACTION_HIDE_OVERLAY', 'ACTION_SYNC', 'ACTION_CLEAR']:
    ok(('const val ' + a) in svc, 'CaptureService 定义 ' + a)
    if a != 'ACTION_START' or 'CaptureService.ACTION_START' in act:
        ok(True, 'Activity 引用规范 ' + a)
used = set(re.findall(r'CaptureService\.(ACTION_\w+)', act))
defined = set(re.findall(r'const val (ACTION_\w+)', svc))
ok(used <= defined, 'Activity 未引用未定义常量', used - defined)
settings = (ROOT / 'app/src/main/java/com/zsm/terminal/Settings.kt').read_text(encoding='utf-8')
ok('BuildConfig.DEFAULT_SB_URL' in settings and 'BuildConfig.DEFAULT_SB_KEY' in settings,
   'Settings 与 BuildConfig 字段对齐')

names = (ROOT / 'app/src/main/java/com/zsm/terminal/Names.kt').read_text(encoding='utf-8')
selfc = (ROOT / 'tools/selfcheck.py').read_text(encoding='utf-8')
groups = ['武陵', '天门', '桂阳', '长沙', '南', '襄阳', '南阳', '江夏', '铺路组']
for gname in groups:
    ok(('"' + gname + '"') in names and ("'" + gname + "'") in selfc,
       '9 组白名单双端一致 ' + gname)
ok(re.search(r'6 to "武陵"', names) is not None and '50 to "铺路组"' in names, 'gid 映射完整')
ok('baseName' in names and 'base_name' in selfc, '队伍名归一化双端实现')

# ---- 6. 样本 ----
sec('6. 样本 pcap')
data = (ROOT / 'sample/sample.pcap').read_bytes()
ok(data[:4] == b'\xd4\xc3\xb2\xa1', '样本是 little-endian classic pcap', data[:4].hex())
ok(len(data) > 200, '样本非空', len(data))

print('\n============================')
print('工程静态校验：通过 %d 项，失败 %d 项' % (ok_n, bad_n))
print('============================')
sys.exit(1 if bad_n else 0)
