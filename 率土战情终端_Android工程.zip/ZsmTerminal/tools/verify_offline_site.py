#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""离线全站校验：网站全部功能零丢失、CDN 本地化、原生桥注入"""
import re
from pathlib import Path
from vcheck import ROOT, ok, sec, finish

src = Path('/data/workspace/率土战情中枢_v4_上市版.html')
site = ROOT / 'app/src/main/assets/index.html'
s = site.read_text(encoding='utf-8')
old = src.read_text(encoding='utf-8') if src.exists() else ''

sec('1. 离线站点')
ok(site.exists(), 'assets/index.html 存在')
ok(len(s) > 1_000_000, '内联后 > 1MB（3 个 CDN 已本地化）', len(s))
ok(s.startswith('<!DOCTYPE html>'), 'HTML 头完整')
ok(s.rstrip().endswith('</html>'), 'HTML 尾完整')
ext = re.findall(r'<script[^>]*src="(https?://[^"]+)"', s)
ok(not ext, '无任何外链 script（完全离线）', ext)
for lib in ['supabase-js', 'pako 2.1.0', 'xlsx.js', 'window.supabase', 'createClient']:
    ok(lib in s, '内联依赖存在 ' + lib)

sec('2. 网站功能零丢失')
rpcs = lambda t: set(re.findall(r"\.rpc\(\s*['\"]([^'\"]+)", t))
fns = lambda t: set(re.findall(r'function\s+([A-Za-z_$][\w$]*)\s*\(', t))
ok(len(rpcs(s)) >= 53, 'RPC 数量 >= 53', len(rpcs(s)))
if old:
    ok(not (rpcs(old) - rpcs(s)), '原 53 个 RPC 零丢失', sorted(rpcs(old) - rpcs(s)))
    ok(not (fns(old) - fns(s)), '原函数零丢失', sorted(fns(old) - fns(s)))
for key in ['SITE_MUSIC', 'get_my_battles', 'use_redeem_code', 'daily_check_in',
            'exportTableDirect', 'postMyVipNotice', 'chargeAttendance', 'chargeBattle',
            'openCoinShop', 'COIN_PLANS', 'alliance-title', 'zsm_attendance_records_v3']:
    ok(key in s, '网站功能保留 ' + key)

sec('3. 原生桥与入口')
for key in ['__zsmSyncProfile', '__zsmRequestSync', 'ZsmNative',
            'onProfile', 'openBattle', 'openVault', 'zsm-battle-fab', 'avatar.png']:
    ok(key in s, '桥接脚本 ' + key)
ok(s.rfind('zsm-battle-fab') > s.rfind('</style>'), '入口浮标注入在样式之后')
ok(s.count('</body>') >= 1, 'body 闭合存在')

sec('4. 资产')
for n in ['avatar.png', 'avatar_square.png']:
    p = ROOT / 'app/src/main/assets' / n
    ok(p.exists() and p.stat().st_size > 10000, '头像资产 ' + n, p.stat().st_size if p.exists() else 'missing')

finish('离线全站校验')
