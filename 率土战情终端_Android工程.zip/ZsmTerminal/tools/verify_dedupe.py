#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""去重逻辑同构验证：与 Kotlin Dedupe.canonical / BattleStore.put 规则一致"""
import copy, hashlib, json, re, sys
from pathlib import Path
from vcheck import ROOT, ok, sec, finish
sys.path.insert(0, str(ROOT / 'tools'))
import selfcheck as sc

KEYS = ['battle_id', 'id', 'attack_name', 'defend_name', 'atk', 'def',
        'wid_name', 'city_name', 'city', 'x', 'y', 'time', 'battle_time', 'result',
        'attack_all_hero_info', 'defend_all_hero_info', 'atk_heroes', 'def_heroes',
        'all_skill_info', 'skills', 'attack_advance', 'defend_advance',
        'attack_union_name', 'defend_union_name', 'attack_role_id', 'defend_role_id',
        'attack_hp', 'defend_hp', 'attacker_gongxun', 'defender_gongxun']

def norm(v):
    t = str(v).strip()
    return re.sub(r'\s+', '', t).replace('\x00', '')

def canonical(o):
    parts = []
    for k in KEYS:
        if k not in o or o[k] is None: continue
        v = o[k]
        if isinstance(v, list): val = ','.join(norm(x) for x in v)
        elif isinstance(v, dict): val = norm(json.dumps(v, ensure_ascii=False, sort_keys=True))
        else: val = norm(v)
        parts.append(k + '=' + val)
    return '|'.join(parts) + '|'

def fp(o): return hashlib.sha256(canonical(o).encode('utf-8')).hexdigest()

class Store:
    def __init__(self): self.by_fp = {}; self.by_id = {}
    def put(self, o):
        f = fp(o); bid = str(o.get('battle_id') or o.get('id') or '')
        if f in self.by_fp: return 1                      # 一模一样 → 丢弃
        if bid and bid in self.by_id and self.by_id[bid][0] != canonical(o):
            oldf = self.by_id[bid][1]
            self.by_fp.pop(oldf, None)
            self.by_fp[f] = o; self.by_id[bid] = (canonical(o), f)
            return 2                                      # 同 id 内容变化 → 更新
        self.by_fp[f] = o; self.by_id[bid] = (canonical(o), f)
        return 0

sec('1. 规范化指纹')
data = sc.build_sample()
texts = []
for st in sc.assemble(sc.parse_pcap(data)):
    sc.inflate_all(st, texts)
raw = json.loads(texts[0])['data']['packet']
ok(len(canonical(raw)) > 100, 'canonical 产出稳定', len(canonical(raw)))
ok(fp(raw) == fp(copy.deepcopy(raw)), '同一战报指纹一致')
noise = copy.deepcopy(raw); noise['uploaded_at'] = 1794459999; noise['client_ver'] = '2.0.1'
ok(fp(noise) == fp(raw), '上传时戳/客户端版本等噪声不影响指纹')
changed = copy.deepcopy(raw); changed['result'] = 0
ok(fp(changed) != fp(raw), '结果变化 → 指纹变化')
alias = copy.deepcopy(raw); alias['attack_name'] = '知夏丨江东 '
ok(fp(alias) == fp(raw), '尾部空格归一化')

sec('2. 导入两次（一模一样的不要）')
store = Store()
a = store.put(copy.deepcopy(raw))
b = store.put(copy.deepcopy(raw))
ok(a == 0 and b == 1, '第一次新增 / 第二次重复丢弃', (a, b))
ok(len(store.by_fp) == 1, '仓库只留 1 条', len(store.by_fp))

sec('3. 同 battle_id 不同内容 → 更新')
v2 = copy.deepcopy(raw); v2['attack_all_hero_info'] = raw['attack_all_hero_info'] + ';100042,50,9000,8000,500,2'
c = store.put(v2)
ok(c == 2, '记为更新', c)
ok(len(store.by_fp) == 1, '仍只留最新 1 条', len(store.by_fp))
ok(store.by_fp[fp(v2)]['attack_all_hero_info'] == v2['attack_all_hero_info'], '保留最新内容')

sec('4. 不同战报并存')
v3 = copy.deepcopy(raw); v3['battle_id'] = 'B20261114190402'
ok(store.put(v3) == 0, '新 battle_id 正常新增')
ok(len(store.by_fp) == 2, '仓库共 2 条', len(store.by_fp))

sec('5. 同盟战报包 → 去重 → 搜索 → 队伍卡 全链路')
r = sc.decode(texts)
battles = [raw, copy.deepcopy(raw), v2, v3]
st2 = Store()
res = [st2.put(x) for x in battles]
ok(res == [0, 1, 2, 0], '整包导入：新增/重复/更新/新增', res)
ok(len(st2.by_fp) == 2, '去重后剩 2 条', len(st2.by_fp))
card = sc.card_for('知夏丨江东', r)
ok(card['group'] == '天门' and card['groupId'] == 7, '搜「知夏丨江东」命中 7 天门', card['group'])
ok(card['city'] == '零陵' and (card['x'], card['y']) == (1315, 374), '城池名字来自战报', card['city'])
ok(card['units'][0]['name'] == '甄洛' and card['units'][0]['skills'][0]['name'] == '先驱突击',
   '队伍卡含武将 + 战法')

sec('6. Kotlin 侧规则一致')
kt = (ROOT / 'app/src/main/java/com/zsm/terminal/Dedupe.kt').read_text(encoding='utf-8')
for k in KEYS[:14]:
    ok('"' + k + '"' in kt, 'Dedupe.kt 含字段 ' + k)
bs = (ROOT / 'app/src/main/java/com/zsm/terminal/BattleStore.kt').read_text(encoding='utf-8')
ok('if (dup) return 1' in bs, 'BattleStore 重复直接丢弃')
ok('updated = true' in bs and 'oldVer + 1' in bs, 'BattleStore 同 id 更新并加版本')

finish('v2 去重逻辑验证')
