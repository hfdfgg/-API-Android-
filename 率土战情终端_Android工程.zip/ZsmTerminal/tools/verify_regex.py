#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 BattleDecoder.kt 里的正则字面量抽出来，用 Python re 编译并喂真实解压文本，
确认 Kotlin 侧写的模式确实能匹配抓包里的内容（Java Regex 与 Python re 语法兼容）。
"""
import ast
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import selfcheck as sc

kt = (ROOT / 'app/src/main/java/com/zsm/terminal/BattleDecoder.kt').read_text(encoding='utf-8')
pats = {}
for m in re.finditer(r'private val (\w+) = Regex\(("(?:[^"\\]|\\.)*")\)', kt):
    try:
        pats[m.group(1)] = ast.literal_eval(m.group(2))
    except Exception as e:
        print('  FAIL 解析正则字面量', m.group(1), e)
        sys.exit(1)

need = ['TRIPLE', 'STUB', 'SERVER_ARR', 'SERVER_NUM', 'ALLIANCE', 'ALLIANCE_NAME',
        'CHANNEL', 'TOKEN', 'DNS']
ok_n = bad_n = 0
def ok(c, m, e=''):
    global ok_n, bad_n
    if c: ok_n += 1; print('  OK  ' + m)
    else: bad_n += 1; print('  FAIL ' + m + ((' :: ' + str(e)) if e else ''))

for k in need:
    ok(k in pats, 'Kotlin 定义正则 ' + k)
for k, p in pats.items():
    try:
        re.compile(p); ok(True, '正则可编译 ' + k)
    except Exception as e:
        ok(False, '正则可编译 ' + k, e)

# 真实样本解压文本
data = sc.build_sample()
segs = sc.parse_pcap(data)
texts = []
for st in sc.assemble(segs):
    sc.inflate_all(st, texts)
text = '\n'.join(texts)
ok(bool(texts), '样本可解压出 JSON 文本', len(texts))

def find(k):
    return re.findall(pats[k], text)

ok(len(find('TRIPLE')) >= 4, 'TRIPLE 抓到分组三元组', find('TRIPLE')[:5])
ok(any(g == '天门' for _, _, g in find('TRIPLE')), 'TRIPLE 含 天门')
ok(any(n == '知夏' for _, n in find('STUB')), 'STUB 抢救名字前缀', find('STUB')[:5])
sa = find('SERVER_ARR')
ok(bool(sa) and sa[0] == ('X6201', '45176'), 'SERVER_ARR 抓到 X6201 / 45176', sa)
ok(bool(find('ALLIANCE')) and find('ALLIANCE')[0] == '1005', 'ALLIANCE 抓到 1005', find('ALLIANCE'))
ok(bool(find('CHANNEL')), 'CHANNEL 抓到渠道码', find('CHANNEL')[:2])
ok(bool(find('TOKEN')), 'TOKEN 抓到会话令牌')
ok(bool(find('DNS')), 'DNS 抓到域名标签', find('DNS')[:5])

# 分组白名单双端一致
r = sc.decode(texts)
ok(r['groupByName'].get('知夏') == '天门', '样本分组解析 → 知夏=天门')
card = sc.card_for('知夏丨江东', r)
ok(card['group'] == '天门' and card['city'] == '零陵', '队伍卡 = 天门 / 零陵', card)
ok(card['units'] and card['units'][0]['name'] == '甄洛', '队伍卡含武将阵容')

print('\n============================')
print('Kotlin 正则跨语言验证：通过 %d 项，失败 %d 项' % (ok_n, bad_n))
print('============================')
sys.exit(1 if bad_n else 0)
