#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""率土战情终端 · 解析链路自测（与 Kotlin 内核同构）

生成合成 pcap → 解析 → 流重组 → zlib 解压 → 战报/分组/情报 → 队伍卡。
CI 与本地均可零依赖运行：python3 tools/selfcheck.py
"""
import io
import json
import re
import struct
import zlib

GID_MAP = {6: '武陵', 7: '天门', 8: '桂阳', 9: '长沙', 10: '南',
           11: '襄阳', 12: '南阳', 13: '江夏', 50: '铺路组'}
WHITE = set(GID_MAP.values())
HERO = {100015: '甄洛', 100024: '荀彧', 100029: '大乔', 100042: '张春华',
        100268: '花鬘', 100372: '妲己', 100424: '小乔＆大乔', 100479: '孙坚',
        100498: '曹纯', 100507: '曹彰', 100520: '典韦'}
SKILL = {200001: '先驱突击', 200002: '浑水摸鱼', 200004: '反计之策',
         200009: '战必断金', 200012: '避其锋芒', 200014: '神兵天降',
         200017: '大赏三军', 200024: '始计', 200026: '妖术',
         200028: '重整旗鼓', 200029: '众谋不懈', 200033: '垒实迎击'}

# ---- 1. 合成 pcap（PCAPdroid TCP 导出器同款：24B global header + records）----
def eth_ip_tcp(payload, seq):
    eth = b'\x00\x11\x22\x33\x44\x55' + b'\x66\x77\x88\x99\xaa\xbb' + struct.pack('!H', 0x0800)
    src, dst = bytes([10, 215, 173, 1]), bytes([42, 186, 97, 110])
    ip = struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20 + 20 + len(payload), 1, 0, 64, 6, 0, src, dst)
    tcp = struct.pack('!HHIIBBHHH', 36628, 8001, seq, 0, 5 << 4, 0x18, 65535, 0, 0)
    return eth + ip + tcp + payload

def make_pcap(chunks):
    out = io.BytesIO()
    out.write(struct.pack('<IHHIIII', 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))
    seq = 1000
    for c in chunks:
        pkt = eth_ip_tcp(c, seq)
        out.write(struct.pack('<IIII', 1760000000, 0, len(pkt), len(pkt)))
        out.write(pkt)
        seq += len(c)
    return out.getvalue()

def member_row(rid, name, gid, city, power):
    a = [rid, name, power, 1, 0, 0, 13360386, power, 3551, 0, 0, 0,
         gid, city, 0, 0, 11109401, '101612,1762877353', 0, 0, 0, 0, 0,
         '130403', 0, 0, 0, 0, 0, '', 1794456657, 1, 0, '']
    return a

BATTLE = {
    'battle_id': 'B20261114190401',
    'attack_name': '知夏丨江东',
    'defend_name': '云祁丨阿彪',
    'attack_union_name': '知盟',
    'defend_union_name': '敌盟',
    'wid_name': '零陵',
    'city_name': '零陵',
    'x': 1315, 'y': 374,
    'time': 1794456657,
    'result': 1,
    'attack_all_hero_info': '100015,50,12000,9000,2000,3;100024,48,11000,8000,1500,2;100029,46,10000,7000,1200,1',
    'defend_all_hero_info': '100479,45,10000,6000,2000,0;100498,44,9500,5000,2000,0;100520,43,9000,4000,2000,0',
    'all_skill_info': '1,200001,10,200002,8;2,200009,10,200004,9;3,200014,9,200017,8;4,200024,10;5,200026,8;6,200033,9',
    'attack_advance': '3,2,1',
    'defend_advance': '',
    'log': {'role_name': '知夏丨江东', 'role_id': '11381', 'server': ['X6201', 204, 45176, 4],
            'alliance_id': 1005},
    'personal': ['知夏丨江东'],
    'session_token': '67cf07c5f264d81d52cf407da4e453f63',
    'dns_labels': ['drpf-g10', 'proxima', 'netease', 'sdkgate', 'pushv3', 'omega01', 'ntes53'],
}

def build_sample():
    c1 = zlib.compress(json.dumps({'data': {'packet': BATTLE}}, ensure_ascii=False).encode('utf-8'))
    rows = [member_row(11381, '知夏', 7, '天门', 20745),
            member_row(12074, '红颜丨老白', 13, '江夏', 102456),
            member_row(13040, '叙旧', 9, '长沙', 13601)]
    c2 = zlib.compress(json.dumps({'group': {'rows': rows,
                                             'triples': [[11381, 7, '天门'], [12074, 13, '江夏'],
                                                         [13040, 9, '长沙'], [14447, 12, '南阳']]}},
                                 ensure_ascii=False).encode('utf-8'))
    return make_pcap([c1, c2])

# ---- 2. pcap 解析 + 流重组 ----
def parse_pcap(data):
    assert data[:4] == b'\xd4\xc3\xb2\xa1', 'little-endian classic pcap'
    linktype = struct.unpack('<I', data[20:24])[0]
    off, out = 24, []
    while off + 16 <= len(data):
        _, _, incl, _ = struct.unpack('<IIII', data[off:off + 16])
        off += 16
        if incl <= 0 or off + incl > len(data):
            break
        pkt = data[off:off + incl]
        off += incl
        seg = take_tcp(pkt, 14 if linktype == 1 else (101 if linktype in (101, 12, 228) else 0))
        if seg:
            out.append(seg)
    return out

def take_tcp(p, ip_off):
    if len(p) <= ip_off + 20 or (p[ip_off] >> 4) != 4 or p[ip_off + 9] != 6:
        return None
    ihl = (p[ip_off] & 0x0f) * 4
    t = ip_off + ihl
    if len(p) < t + 20:
        return None
    seq = struct.unpack('!I', p[t + 4:t + 8])[0]
    po = t + ((p[t + 12] >> 4) * 4)
    return (seq, p[po:])

def assemble(segs):
    flows = {}
    for seq, pl in segs:
        flows.setdefault('f', []).append((seq, pl))
    out = []
    for k, arr in flows.items():
        arr.sort(key=lambda x: x[0])
        last, buf = None, io.BytesIO()
        for seq, pl in arr:
            if seq == last:
                continue
            last = seq
            buf.write(pl)
        out.append(buf.getvalue())
    return out

# ---- 3. zlib 解压（对齐 JS pako.Inflate + total_in）----
def inflate_all(data, texts):
    off = 0
    n = 0
    while off < len(data) - 2:
        idx = find_head(data, off)
        if idx < 0:
            break
        try:
            d = zlib.decompressobj()
            out = d.decompress(data[idx:])
            consumed = len(data[idx:]) - len(d.unused_data)
            if out:
                texts.append(out.decode('utf-8', errors='replace'))
                n += 1
            off = idx + consumed if consumed > 0 else idx + 2
        except Exception:
            off = idx + 2
    return n

def find_head(b, start):
    for i in range(start, len(b) - 1):
        if b[i] == 0x78 and b[i + 1] in (0x01, 0x5e, 0x9c, 0xda):
            return i
    return -1

# ---- 4. 战报 / 分组 / 情报 ----
def num(v, d=0):
    try:
        return int(float(v))
    except Exception:
        return d

def parse_heroes(s):
    out = []
    for row in str(s or '').split(';'):
        seg = row.split(',')
        if len(seg) < 3 or not num(seg[0]):
            continue
        mx, rm, wd = num(seg[2]), num(seg[3]), num(seg[4])
        loss = max(0, mx - rm)
        adv = 0
        for k in range(5, min(len(seg), 9)):
            v = num(seg[k])
            if 1 <= v <= 5:
                adv = v
                break
        out.append({'heroId': num(seg[0]), 'level': num(seg[1]), 'maxHp': mx,
                    'remainHp': rm, 'wounded': wd, 'dead': max(0, loss - wd),
                    'loss': loss, 'advance': adv, 'skills': []})
    return out

def parse_skills(s):
    atk, dfs = [], []
    for i, row in enumerate(str(s or '').split(';')):
        seg = row.split(',')
        if len(seg) < 2:
            continue
        raw = num(seg[0])
        side = 'attack' if 1 <= raw <= 3 else 'defend'
        slot = raw - 3 if 4 <= raw <= 6 else (raw - 6 if 7 <= raw <= 9 else (i % 3) + 1)
        lst = []
        j = 1
        while j + 1 < len(seg) and len(lst) < 3:
            sid, lv = num(seg[j]), num(seg[j + 1])
            if sid:
                lst.append({'skillId': sid, 'level': lv, 'slot': slot})
            j += 2
        (atk if side == 'attack' else dfs).append(lst)
    return atk, dfs

def adv_arr(v):
    if not v:
        return []
    if isinstance(v, list):
        return [num(x) for x in v]
    return [num(x) for x in re.split(r'[,;\s]+', str(v)) if x]

def pick_adv(arr, idx, total):
    a = adv_arr(arr)
    if len(a) == total and 0 <= a[idx] <= 5:
        return a[idx]
    if len(a) == 1 and 0 <= a[0] <= 5:
        return a[0]
    if len(a) > idx and 0 <= a[idx] <= 5:
        return a[idx]
    return 0

def walk(o, r):
    if isinstance(o, list):
        # 成员数组：>=30 项，index 12 = gid，index 13 = 城池名
        if len(o) >= 30 and isinstance(o[1], str):
            gid = num(o[12])
            city = str(o[13]).strip()
            if GID_MAP.get(gid) == city and city in WHITE:
                nm = clean_name(o[1])
                if nm:
                    r['members'].append({'roleId': num(o[0]), 'name': nm,
                                        'groupId': gid, 'group': city, 'power': num(o[2])})
                    r['groupByName'][nm] = city
                    r['groupByRoleId'][num(o[0])] = city
        for x in o:
            walk(x, r)
        return
    if not isinstance(o, dict):
        return
    if 'battle_id' in o and 'attack_name' in o:
        atk_u, def_u = parse_heroes(o.get('attack_all_hero_info')), parse_heroes(o.get('defend_all_hero_info'))
        ask, dsk = parse_skills(o.get('all_skill_info'))
        aa, da = adv_arr(o.get('attack_advance')), adv_arr(o.get('defend_advance'))
        for i, u in enumerate(atk_u):
            u['advance'] = pick_adv(aa, i, len(atk_u))
            if i < len(ask):
                u['skills'] = ask[i]
        for i, u in enumerate(def_u):
            u['advance'] = pick_adv(da, i, len(def_u))
            if i < len(dsk):
                u['skills'] = dsk[i]
        b = {'id': str(o.get('battle_id')), 'time': num(o.get('time') or o.get('battle_time')),
             'city': str(o.get('wid_name') or o.get('city_name') or '未知地点'),
             'x': num(o.get('x')), 'y': num(o.get('y')),
             'atk': clean_name(o.get('attack_name')), 'def': clean_name(o.get('defend_name')),
             'atkUnion': str(o.get('attack_union_name') or ''),
             'defUnion': str(o.get('defend_union_name') or ''),
             'result': num(o.get('result')), 'atkUnits': atk_u, 'defUnits': def_u,
             'atkLoss': sum(u['loss'] for u in atk_u), 'defLoss': sum(u['loss'] for u in def_u)}
        r['battles'].append(b)
        for nm in (b['atk'], b['def']):
            if nm:
                r['names'].add(nm)
        if b['city'] != '未知地点':
            r['cities'].add(b['city'])
    lg = o.get('log')
    if isinstance(lg, dict):
        nm = clean_name(lg.get('role_name'))
        if nm:
            r['names'].add(nm)
    for v in o.values():
        walk(v, r)

def clean_name(v):
    t = str(v or '').strip()
    t = t.split('#')[0].strip()
    if not t or len(t) > 24 or t.isdigit() or not re.search(r'[\u4e00-\u9fa5A-Za-z]', t):
        return ''
    if re.search(r'[\uE000-\uF8FF\uFFFD]|锟斤拷|鍙|绾|姹|敘|鎶|鐭|鍗|闀|妗|姝|瑗|婕|椤', t):
        return ''
    return t

def decode(texts):
    r = {'battles': [], 'members': [], 'groupByName': {}, 'groupByRoleId': {},
         'groupCount': {}, 'names': set(), 'cities': set(),
         'intel': {'serverCode': '', 'serverId': '', 'allianceId': '', 'channel': '', 'token': '', 'dns': []}}
    all_text = '\n'.join(texts)
    # 三元组 [roleId, gid, "城池"]
    for m in re.finditer(r'\[\s*(\d{3,7})\s*,\s*(\d{1,3})\s*,\s*"([^"]{1,12})"\s*\]', all_text):
        gid, city = num(m.group(2)), m.group(3)
        if GID_MAP.get(gid) == city and city in WHITE:
            r['groupByRoleId'][num(m.group(1))] = city
            r['groupCount'][city] = r['groupCount'].get(city, 0) + 1
    # 名字前缀 [id,"名字",
    name_by_id = {}
    for m in re.finditer(r'\[\s*(\d{3,7})\s*,\s*"([^"]{1,24})"\s*,', all_text):
        nm = clean_name(m.group(2))
        if nm and num(m.group(1)) not in name_by_id:
            name_by_id[num(m.group(1))] = nm
    for rid, grp in r['groupByRoleId'].items():
        if rid in name_by_id:
            r['groupByName'][name_by_id[rid]] = grp
    # 元数据（两种 server 写法都兼容）
    m = re.search(r'"server"\s*:\s*\[\s*"([^"]+)"\s*,\s*\d+\s*,\s*(\d{3,7})', all_text)
    if m:
        r['intel']['serverCode'], r['intel']['serverId'] = m.group(1), m.group(2)
    if not r['intel']['serverId']:
        m = re.search(r'"server"\s*:\s*(\d{3,7})', all_text)
        if m:
            r['intel']['serverId'] = m.group(1)
    m = re.search(r'"alliance_id"\s*:\s*(\d+)', all_text)
    if m:
        r['intel']['allianceId'] = m.group(1)
    m = re.search(r'"(\d{6}),(\d{9,11})"', all_text)
    if m:
        r['intel']['channel'] = m.group(1)
    m = re.search(r'([0-9a-f]{32})_?', all_text)
    if m:
        r['intel']['token'] = m.group(1)
    r['intel']['dns'] = list(dict.fromkeys(re.findall(
        r'proxima|netease|sdkgate|pushv3|omega\d+|ntes\d+|drpf-[a-z0-9]+|lbc-[a-z0-9-]+', all_text)))[:12]
    for t in texts:
        try:
            walk(json.loads(t), r)
        except Exception:
            pass
    for mem in r['members']:
        r['groupCount'][mem['group']] = r['groupCount'].get(mem['group'], 0) + 1
    r['names'] = sorted(r['names'])
    r['cities'] = sorted(r['cities'])
    return r

# ---- 5. 队伍名归一化匹配（「知夏丨江东」→「知夏」→ 天门）----
def base_name(n):
    return re.split(r'[丨|·丶、\s lL/]+', str(n or ''))[0].strip()

def card_for(name, r):
    key = base_name(name)
    grp = r['groupByName'].get(name) or r['groupByName'].get(key) or ''
    gid = next((k for k, v in GID_MAP.items() if v == grp), 0)
    bs = [b for b in r['battles'] if b['atk'] == name or b['atk'] == key or
          b['def'] == name or b['def'] == key]
    bs.sort(key=lambda b: b['time'], reverse=True)
    b = bs[0] if bs else None
    units, side = [], ''
    if b:
        if b['atk'] in (name, key):
            units, side = b['atkUnits'], '攻方'
        else:
            units, side = b['defUnits'], '守方'
    return {'name': name, 'group': grp, 'groupId': gid,
            'city': b['city'] if b else '', 'x': b['x'] if b else 0, 'y': b['y'] if b else 0,
            'union': (b['atkUnion'] if side == '攻方' else b['defUnion']) if b else '',
            'server': r['intel']['serverCode'] or r['intel']['serverId'] or '',
            'side': side, 'result': b['result'] if b else -1,
            'units': [{'name': HERO.get(u['heroId'], '武将' + str(u['heroId'])),
                       'level': u['level'], 'advance': u['advance'],
                       'loss': u['loss'], 'dead': u['dead'],
                       'skills': [{'name': SKILL.get(s['skillId'], '战法' + str(s['skillId'])),
                                   'level': s['level']} for s in u['skills']]} for u in units],
            'source': '本地抓包解析'}

# ---- 6. 跑通断言 ----
def main():
    data = build_sample()
    segs = parse_pcap(data)
    assert segs, 'pcap 未解析出 TCP 段'
    streams = assemble(segs)
    texts = []
    blocks = 0
    for st in streams:
        blocks += inflate_all(st, texts)
    assert texts, 'zlib 解压无输出'
    r = decode(texts)
    print('[链路] pcap 字节=%d / TCP段=%d / 流=%d / JSON块=%d' %
          (len(data), len(segs), len(streams), blocks))
    assert r['battles'], '未解析出战报'
    b = r['battles'][0]
    assert b['atk'] == '知夏丨江东', b['atk']
    assert b['city'] == '零陵' and (b['x'], b['y']) == (1315, 374), (b['city'], b['x'], b['y'])
    assert len(b['atkUnits']) == 3 and len(b['defUnits']) == 3, '三武将阵容'
    assert b['atkUnits'][0]['skills'][0]['skillId'] == 200001, '战法装配'
    assert r['intel']['serverCode'] == 'X6201' and r['intel']['serverId'] == '45176', r['intel']
    assert r['intel']['allianceId'] == '1005', r['intel']
    assert len(r['intel']['token']) == 32 and r['intel']['token'].startswith('67cf07c5'), r['intel']
    assert 'netease' in r['intel']['dns'] and 'sdkgate' in r['intel']['dns'], r['intel']['dns']
    assert r['groupByName'].get('知夏') == '天门', r['groupByName']
    assert all(g in WHITE for g in r['groupCount']), r['groupCount']
    card = card_for('知夏丨江东', r)
    assert card['group'] == '天门' and card['groupId'] == 7, card
    assert card['city'] == '零陵' and card['side'] == '攻方', card
    assert card['units'][0]['name'] == '甄洛', card['units'][0]
    assert card['units'][0]['skills'][0]['name'] == '先驱突击', card['units'][0]['skills']
    print('[分组]', r['groupCount'])
    print('[情报]', r['intel'])
    print('[队伍卡]', json.dumps(card, ensure_ascii=False, indent=2))
    print('\n✔ 全链路自测通过：pcap → 流重组 → 解压 → 战报/9组/情报 → 江东队伍卡')

if __name__ == '__main__':
    main()
