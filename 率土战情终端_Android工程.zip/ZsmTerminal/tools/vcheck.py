#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""共享断言小工具"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OK = BAD = 0

def ok(c, msg, extra=''):
    global OK, BAD
    if c:
        OK += 1; print('  OK   ' + msg)
    else:
        BAD += 1; print('  FAIL ' + msg + ((' :: ' + str(extra)) if extra else ''))

def sec(t): print('\n=== ' + t + ' ===')

def finish(name):
    print('\n============================')
    print('%s：通过 %d 项，失败 %d 项' % (name, OK, BAD))
    print('============================')
    sys.exit(1 if BAD else 0)

def lex(src):
    """Kotlin 词法粗检：字符串闭合 / 括号平衡 / raw string 边界"""
    i, n = 0, len(src)
    stack, line = [], 1
    pairs = {')': '(', ']': '[', '}': '{'}
    while i < n:
        c = src[i]
        if c == '\n': line += 1; i += 1; continue
        if c == '/' and i + 1 < n and src[i + 1] == '/':
            j = src.find('\n', i); i = n if j < 0 else j; continue
        if c == '/' and i + 1 < n and src[i + 1] == '*':
            j = src.find('*/', i + 2)
            if j < 0: return '块注释未闭合 @%d' % line
            line += src[i:j].count('\n'); i = j + 2; continue
        if src.startswith('"""', i):
            j = src.find('"""', i + 3)
            if j < 0: return 'raw 字符串未闭合 @%d' % line
            line += src[i:j].count('\n'); i = j + 3; continue
        if c == '"':
            i += 1; closed = False
            while i < n:
                if src[i] == '\\': i += 2; continue
                if src[i] == '"': closed = True; i += 1; break
                if src[i] == '\n': return '普通字符串跨行未闭合 @%d' % line
                i += 1
            if not closed: return '普通字符串未闭合 @%d' % line
            continue
        if c == "'":
            i += 1
            while i < n and src[i] != "'":
                if src[i] == '\\': i += 2; continue
                i += 1
            i += 1; continue
        if c in '([{': stack.append((c, line))
        elif c in ')]}':
            if not stack or stack[-1][0] != pairs[c]:
                return '括号不匹配 %s @%d' % (c, line)
            stack.pop()
        i += 1
    if stack: return '括号未闭合 %s @%d' % (stack[-1][0], stack[-1][1])
    return None
