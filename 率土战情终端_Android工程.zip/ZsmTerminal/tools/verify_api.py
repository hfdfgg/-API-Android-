#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kotlin 方法存在性交叉校验：ClassName.method( 必须能在该类定义里找到 fun method(。
沙盒没有 Android 编译器，这一步能提前抓出拼写错误 / 已删除 API 的残留调用。"""
import re
from pathlib import Path
from vcheck import ROOT, ok, sec, finish

SRC = ROOT / 'app/src/main/java/com/zsm/terminal'
files = {f.stem: f.read_text(encoding='utf-8') for f in sorted(SRC.glob('*.kt'))}

# 类名 → 已定义方法（含 companion object / private / suspend / inline）
defined = {}
for cls, src in files.items():
    defined[cls] = set(re.findall(r'\bfun\s+(?:[\w$]+)\s*\(', src)) | \
                   set(re.findall(r'\bfun\s+([\w$]+)\s*\(', src))
    # 上面两种写法都取方法名，统一再抽一次
    defined[cls] = set(re.findall(r'\bfun\s+([\w$]+)\s*\(', src))

# 常量/属性访问也算可用（capture ACTION_XXX）
props = {}
for cls, src in files.items():
    props[cls] = set(re.findall(r'\b(?:const\s+)?val\s+([\w$]+)', src)) | \
                 set(re.findall(r'\bvar\s+([\w$]+)', src))

# 只检查工程内定义的类名，排除 SDK / 标准库 / Lambda 局部变量
known = set(files.keys())
# 抓 Xxx. 调用：允许 companion 静态方法、实例方法
calls = {}
for f in SRC.glob('*.kt'):
    src = f.read_text(encoding='utf-8')
    for cls, member in re.findall(r'\b([A-Z][\w$]*)\.([a-z][\w$]*)\s*\(', src):
        if cls in known:
            calls.setdefault(cls, set()).add(member)
    # 常量引用 Xxx.ACTION_YYY（不带括号）
    for cls, member in re.findall(r'\b([A-Z][\w$]*)\.([A-Z][A-Z_\d]+)', src):
        if cls in known:
            calls.setdefault(cls, set()).add(member)

# 同一 .kt 文件里可能定义多个 object（如 TeamCardDialog.kt 里的 TeamCardBus），
# 因此再准备一份「全工程已定义方法」作为回退集
global_defs = set().union(*defined.values()) if defined else set()
sec('1. 工程内方法 / 常量交叉引用')
for cls in sorted(calls):
    own = defined.get(cls, set())
    ownp = props.get(cls, set())
    missing = sorted(m for m in calls[cls]
                     if m not in own and m not in ownp and m not in global_defs)
    ok(not missing, cls + ' 调用均已定义', missing)

sec('2. 关键 API 契约')
ok('build' in defined.get('BattleCenterView', set()), 'BattleCenterView.build 存在')
ok('build' in defined.get('VaultView', set()), 'VaultView.build 存在')
ok('build' in defined.get('SettingsView', set()), 'SettingsView.build 存在')
ok('show' in defined.get('TeamCardDialog', set()), 'TeamCardDialog.show 存在')
ok('show' in defined.get('Onboarding', set()), 'Onboarding.show 存在')
ok('importTexts' in defined.get('PacketImporter', set()), 'PacketImporter.importTexts 存在')
ok('importUri' in defined.get('PacketImporter', set()), 'PacketImporter.importUri 存在')
ok('put' in defined.get('BattleStore', set()), 'BattleStore.put 存在')
ok('card' in defined.get('TeamRepository', set()), 'TeamRepository.card 存在')
ok('canDraw' in defined.get('OverlayManager', set()), 'OverlayManager.canDraw 存在')
ok('showCard' in defined.get('OverlayManager', set()), 'OverlayManager.showCard 存在')
ok('attach' in global_defs and 'toggle' in global_defs, 'TeamCardBus 方法存在')
ok('appendRuntimeLog' in defined.get('SettingsView', set()), 'SettingsView.appendRuntimeLog 存在')

sec('3. 无已删除 API 残留')
allcode = '\n'.join(files.values())
for dead in ['Ui.', 'SupabaseClient(', 'pullCloud(', 'chargeAttendance(', 'openStoragePay(']:
    ok(dead not in allcode, '无 v1 残留 ' + dead)

finish('Kotlin API 交叉校验')
