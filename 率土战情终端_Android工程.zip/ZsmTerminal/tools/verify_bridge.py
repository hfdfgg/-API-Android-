#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""原生桥契约 / VIP 门禁 / 数据边界校验"""
import re
from pathlib import Path
from vcheck import ROOT, ok, sec, finish

site = (ROOT / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
bridge = (ROOT / 'app/src/main/java/com/zsm/terminal/JsBridge.kt').read_text(encoding='utf-8')
app = (ROOT / 'app/src/main/java/com/zsm/terminal/MainActivity.kt').read_text(encoding='utf-8')
settings = (ROOT / 'app/src/main/java/com/zsm/terminal/Settings.kt').read_text(encoding='utf-8')

sec('1. JS ↔ 原生契约')
for m in ['onProfile', 'openBattle', 'openVault', 'log']:
    ok(('window.ZsmNative.' + m) in site or ('ZsmNative.' + m) in site or
       ('ZsmNative && window.ZsmNative.' + m) in site or (m + '(') in site,
       '网站调用 ' + m)
    ok(('fun ' + m + '(') in bridge, 'JsBridge 暴露 ' + m)
ok('@JavascriptInterface' in bridge, '方法带 @JavascriptInterface')
ok('"ZsmNative"' in app, '注入名一致')
ok('__zsmRequestSync' in site and 'requestProfileSync' in (ROOT / 'app/src/main/java/com/zsm/terminal/AppState.kt').read_text(encoding='utf-8'),
   '原生可主动请求同步')

sec('2. 同步字段')
models = (ROOT / 'app/src/main/java/com/zsm/terminal/Models.kt').read_text(encoding='utf-8')
for k in ['id', 'pin', 'coins', 'vip', 'vipExpire', 'nickname', 'forceName', 'alliance']:
    ok(k in site and k in models, '同步字段（网站 ↔ Profile 模型） ' + k)
ok('settings.profile = p' in bridge, 'VIP/账号落到本地设置')
ok('AppState.profile(p)' in bridge, '同步后广播给原生页面')

sec('3. VIP 判定')
ok('fun isVip()' in settings, 'VIP 判定含过期时间')
ok('System.currentTimeMillis()' in settings, '按过期时间判定')
ok('VIP' in (ROOT / 'app/src/main/java/com/zsm/terminal/OverlayManager.kt').read_text(encoding='utf-8'),
   '悬浮窗门禁')

sec('4. 数据边界')
ok('仍在原 Supabase' in site or '原 Supabase' in site, '桥注释说明账号仍在云端')
ok('绝不把战报写回数据库' in bridge or '不把战报' in bridge, '桥不写战报')
ok('get_my_battles' not in bridge, '原生桥不读云端战报')
ok('SupabaseClient' not in '\n'.join(
    f.read_text(encoding='utf-8') for f in
    (ROOT / 'app/src/main/java/com/zsm/terminal').glob('*.kt')),
   '原生无云端战报读取模块')
man = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
ok(not re.search(r'<uses-permission[^>]*ACCESSIBILITY', man, re.I), '无无障碍权限声明')

finish('原生桥与数据边界校验')
