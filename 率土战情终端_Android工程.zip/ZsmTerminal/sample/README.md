# 样本抓包

`sample.pcap` 是合成的经典 pcap（PCAPdroid 同款格式，little-endian + Ethernet），里面塞了：

- 一条战报：攻方「知夏丨江东」在 **零陵 (1315,374)**，三武将 甄洛/荀彧/大乔 + 每人战法
- 三条成员数组 + 四条分组三元组（知夏→天门、红颜丨老白→江夏、叙旧→长沙、另含南阳）
- `"server":["X6201",204,45176,4]`、`alliance_id:1005`、渠道码 `101612`
- 会话令牌与 DNS 标签（drpf-g10 / proxima / netease / sdkgate / pushv3 / omega01 / ntes53）

**用法**：装好 APK → 首页「导入 .pcap / .pcapng / .gz 文件」选它 →
点悬浮球 → 队伍列表里点「知夏丨江东」→ 弹出队伍卡（7 天门 / 零陵 / X6201 / 甄洛+先驱突击）。

不需要联网、不需要账号、不需要真的开 PCAPdroid，用来验证整条链路是否通。
生成逻辑见 `tools/selfcheck.py`，CI 每次构建都会重跑。
