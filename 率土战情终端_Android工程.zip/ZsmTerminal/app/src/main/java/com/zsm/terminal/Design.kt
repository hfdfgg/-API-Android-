package com.zsm.terminal

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 上市级设计系统：与网站的暗色玻璃拟态对齐。
 * 所有原生页面共用一套色板 / 圆角 / 间距 / 字阶 / 阴影，不再是 demo 式按钮堆叠。
 */
object Design {
    const val BG = 0xFF090A0FL.toInt()
    const val SURFACE = 0xFF141821L.toInt()
    const val SURFACE2 = 0xFF1B2130L.toInt()
    const val LINE = 0xFF263043L.toInt()
    const val TEXT = 0xFFF8FAFCL.toInt()
    const val MUTED = 0xFF94A3B8L.toInt()
    const val PRIMARY = 0xFF6366F1L.toInt()
    const val CYAN = 0xFF06B6D4L.toInt()
    const val GOLD = 0xFFFBBF24L.toInt()
    const val WIN = 0xFF10B981L.toInt()
    const val DANGER = 0xFFEF4444L.toInt()

    /** 由 ZsmApp 注入，便于 bg()/gradient() 不依赖 Context 也能换算 dp */
    @Volatile var density: Float = 3f

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun bg(color: Int, radiusDp: Int, strokeDp: Int = 0, strokeColor: Int = LINE): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp * density
            if (strokeDp > 0) setStroke((strokeDp * density).toInt().coerceAtLeast(1), strokeColor)
        }

    fun gradient(c1: Int, c2: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
            cornerRadius = radiusDp * density
        }

    fun tv(c: Context, text: String, size: Float = 14f, color: Int = TEXT,
           bold: Boolean = false, align: Int = Gravity.START): TextView = TextView(c).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        gravity = align
        includeFontPadding = false
    }

    fun h1(c: Context, t: String) = tv(c, t, 24f, TEXT, true)
    fun h2(c: Context, t: String) = tv(c, t, 17f, TEXT, true)
    fun h3(c: Context, t: String) = tv(c, t, 14f, TEXT, true)
    fun body(c: Context, t: String, color: Int = TEXT) = tv(c, t, 13f, color)
    fun cap(c: Context, t: String, color: Int = MUTED) = tv(c, t, 11f, color)

    fun card(c: Context, pad: Int = 14, elevated: Boolean = false): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(if (elevated) SURFACE2 else SURFACE, 16, 1)
            setPadding(dp(c, pad), dp(c, pad), dp(c, pad), dp(c, pad))
            if (elevated) elevation = dp(c, 4).toFloat()
        }

    fun hero(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = gradient(0xFF312E81L.toInt(), 0xFF0E7490L.toInt(), 20)
        setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18))
    }

    fun row(c: Context, weight: Boolean = false): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun space(c: Context, h: Int): View = View(c).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(c, h)
        )
    }

    fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = top; bottomMargin = bottom }

    fun w(c: Context, weight: Float, marginEnd: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight).apply {
            rightMargin = dp(c, marginEnd)
        }

    fun btn(c: Context, text: String, kind: Int = 0, onClick: () -> Unit): TextView {
        val pair = when (kind) {
            1 -> 0xFF06B6D4L.toInt() to 0xFFFFFFFFL.toInt()
            2 -> 0xFF10B981L.toInt() to 0xFFFFFFFFL.toInt()
            3 -> 0xFFFBBF24L.toInt() to 0xFF111827L.toInt()
            4 -> 0xFFEF4444L.toInt() to 0xFFFFFFFFL.toInt()
            5 -> SURFACE2 to TEXT
            else -> PRIMARY to 0xFFFFFFFFL.toInt()
        }
        return tv(c, text, 14f, pair.second, true, Gravity.CENTER).apply {
            background = bg(pair.first, 12)
            setPadding(dp(c, 14), dp(c, 13), dp(c, 14), dp(c, 13))
            isClickable = true
            elevation = dp(c, 2).toFloat()
            setOnClickListener { onClick() }
        }
    }

    fun chip(c: Context, text: String, color: Int = CYAN): TextView =
        tv(c, text, 11f, color, true, Gravity.CENTER).apply {
            background = bg(SURFACE2, 20, 1, color)
            setPadding(dp(c, 9), dp(c, 4), dp(c, 9), dp(c, 4))
        }

    fun input(c: Context, hint: String, singleLine: Boolean = true): EditText =
        EditText(c).apply {
            this.hint = hint
            setHintTextColor(MUTED)
            setTextColor(TEXT)
            textSize = 15f
            isSingleLine = singleLine
            background = bg(SURFACE2, 12, 1)
            setPadding(dp(c, 13), dp(c, 12), dp(c, 13), dp(c, 12))
        }

    fun icon(c: Context, res: Int, tint: Int = MUTED, size: Int = 20): ImageView =
        ImageView(c).apply {
            setImageResource(res)
            setColorFilter(tint)
            layoutParams = LinearLayout.LayoutParams(dp(c, size), dp(c, size))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

    fun divider(c: Context): View = View(c).apply {
        background = bg(LINE, 0)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(c, 1)
        )
    }

    fun stat(c: Context, label: String, value: String, color: Int = TEXT): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(SURFACE2, 12)
            setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10))
            addView(tv(c, value, 19f, color, true, Gravity.CENTER))
            addView(tv(c, label, 10f, MUTED, false, Gravity.CENTER))
        }

    /** 分区标题：小竖条 + 标题 + 右侧说明 */
    fun section(c: Context, title: String, sub: String = ""): LinearLayout = row(c).apply {
        addView(View(c).apply {
            background = bg(PRIMARY, 6)
            layoutParams = LinearLayout.LayoutParams(dp(c, 3), dp(c, 16))
        })
        addView(tv(c, "  " + title, 15f, TEXT, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (sub.isNotEmpty()) addView(cap(c, sub))
    }
}
