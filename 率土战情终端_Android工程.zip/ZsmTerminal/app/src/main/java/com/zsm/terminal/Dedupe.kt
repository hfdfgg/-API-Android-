package com.zsm.terminal

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import java.security.MessageDigest

/**
 * 去重规则：只取战报「业务字段」做规范化，剔除上传时戳 / 日志 / 客户端版本等噪声。
 * 一模一样的战报 → 同一个 fp → 直接丢弃；同 battle_id 但内容不同 → 记为更新。
 */
object Dedupe {

    private val KEYS = listOf(
        "battle_id", "id", "attack_name", "defend_name", "atk", "def",
        "wid_name", "city_name", "city", "x", "y", "time", "battle_time", "result",
        "attack_all_hero_info", "defend_all_hero_info", "atk_heroes", "def_heroes",
        "all_skill_info", "skills", "attack_advance", "defend_advance",
        "attack_union_name", "defend_union_name", "attack_role_id", "defend_role_id",
        "attack_hp", "defend_hp", "attacker_gongxun", "defender_gongxun"
    )

    /** 固定顺序、固定分隔符，值统一转字符串；数组按序展开 */
    fun canonical(o: JsonObject): String {
        val sb = StringBuilder()
        KEYS.forEach { k ->
            val v: JsonElement? = o.get(k)
            if (v == null || v.isJsonNull) return@forEach
            sb.append(k).append('=')
            when {
                v.isJsonPrimitive -> sb.append(norm(v.asString))
                v.isJsonArray -> sb.append(v.asJsonArray.joinToString(",") { norm(it.toString()) })
                else -> sb.append(norm(v.toString()))
            }
            sb.append('|')
        }
        return sb.toString()
    }

    private fun norm(s: String): String = s.trim()
        .replace(Regex("\\s+"), "")
        .replace("\u0000", "")

    fun sha256(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }
    }

    fun fingerprint(o: JsonObject): String = sha256(canonical(o))

    fun battleKey(o: JsonObject): String {
        for (k in listOf("battle_id", "id", "uid")) {
            val v = o.get(k)
            if (v != null && v.isJsonPrimitive && v.asString.isNotEmpty()) return v.asString
        }
        return ""
    }
}
