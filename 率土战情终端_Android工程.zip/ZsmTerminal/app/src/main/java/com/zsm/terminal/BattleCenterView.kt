package com.zsm.terminal

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** 原生「战场」页：导入同盟战报包 → 本地去重 → 搜势力名 → 队伍卡 */
object BattleCenterView {

    fun build(ctx: Context, repo: TeamRepository, settings: Settings,
              onImport: () -> Unit, onVip: () -> Unit,
              onCard: (String) -> Unit): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Design.dp(ctx, 14), Design.dp(ctx, 16),
                Design.dp(ctx, 14), Design.dp(ctx, 24))
        }

        // ---- Hero ----
        val hero = Design.hero(ctx)
        val hr = Design.row(ctx)
        hr.addView(Design.icon(ctx, R.drawable.ic_battle, Design.GOLD, 28),
            LinearLayout.LayoutParams(Design.dp(ctx, 28), Design.dp(ctx, 28)))
        val hbox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        hbox.addView(Design.h1(ctx, "  战场情报"))
        hbox.addView(Design.cap(ctx, "  本地同盟战报包 · 与网站解析链路独立"))
        hr.addView(hbox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        hr.addView(if (settings.isVip()) Design.chip(ctx, "VIP 已开通", Design.GOLD)
                   else Design.chip(ctx, "普通用户", Design.MUTED))
        hero.addView(hr)
        hero.addView(Design.space(ctx, 12))
        val stats = Design.row(ctx)
        val c = storeCounts(repo)
        listOf("战报" to c[0].toString(), "玩家" to c[1].toString(),
               "分组" to c[2].toString(), "城池" to c[3].toString()).forEach { (k, v) ->
            stats.addView(Design.stat(ctx, k, v, Design.CYAN), Design.w(ctx, 1f, 6))
        }
        hero.addView(stats)
        root.addView(hero, Design.lp(bottom = 14))

        // ---- 导入 ----
        val imp = Design.card(ctx)
        imp.addView(Design.section(ctx, "① 打之前先传包", "本地存储"))
        imp.addView(Design.space(ctx, 10))
        imp.addView(Design.btn(ctx, "导入同盟战报包（pcap / pcapng / txt / json / zip）", 1, onImport))
        imp.addView(Design.space(ctx, 8))
        imp.addView(Design.cap(ctx,
            "支持 PCAPdroid 转储包、抓包报告 txt、战报 json 与合集 zip；" +
            "导入即在本地解析并去重，一模一样的战报只留一条，绝不上传数据库。"))
        root.addView(imp, Design.lp(bottom = 14))

        // ---- 搜索 ----
        val search = Design.card(ctx)
        search.addView(Design.section(ctx, "② 搜势力名字 → 队伍情报", "VIP"))
        search.addView(Design.space(ctx, 10))
        if (!settings.isVip()) {
            search.addView(Design.icon(ctx, R.drawable.ic_vip, Design.GOLD, 34))
            search.addView(Design.space(ctx, 6))
            search.addView(Design.body(ctx, "悬浮窗搜索 / 点人弹队伍卡 / 收藏备注 / 队伍对比 为 VIP 专属。"))
            search.addView(Design.cap(ctx, "导入战报包、查看统计与账包管理对全部用户开放。"))
            search.addView(Design.space(ctx, 10))
            search.addView(Design.btn(ctx, "前往开通 VIP", 3, onVip))
        } else {
            val input = Design.input(ctx, "输入游戏名字 / 势力名，如：知夏丨江东")
            search.addView(input)
            search.addView(Design.space(ctx, 8))
            val chips = Design.row(ctx)
            listOf("最近交战" to "", "我的收藏" to "__fav__", "搜索历史" to "__his__").forEach { (label, key) ->
                val b = Design.chip(ctx, label, Design.CYAN)
                b.setOnClickListener { input.setText(key); }
                chips.addView(b, Design.w(ctx, 1f, 6))
            }
            search.addView(chips)
            search.addView(Design.space(ctx, 10))
            val listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            search.addView(listBox)

            fun render(q: String) {
                listBox.removeAllViews()
                val hits = when (q) {
                    "__fav__" -> repo.favorites()
                    "__his__" -> repo.history()
                    else -> repo.search(q)
                }
                if (hits.isEmpty()) {
                    listBox.addView(Design.cap(ctx, "暂无匹配。先导入同盟战报包，或换个名字试试。"))
                    return
                }
                hits.take(20).forEach { h ->
                    val row = Design.row(ctx).apply {
                        background = Design.bg(Design.SURFACE2, 10)
                        setPadding(Design.dp(ctx, 11), Design.dp(ctx, 10),
                            Design.dp(ctx, 11), Design.dp(ctx, 10))
                        isClickable = true
                        setOnClickListener { onCard(h.name) }
                    }
                    row.addView(Design.icon(ctx, R.drawable.ic_users, Design.CYAN, 18),
                        LinearLayout.LayoutParams(Design.dp(ctx, 18), Design.dp(ctx, 18)))
                    val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                    box.addView(Design.body(ctx, "  " + h.name))
                    box.addView(Design.cap(ctx, "  " +
                        (h.group.ifEmpty { "未分组" }) +
                        (if (h.count > 0) " · ${h.count} 场" else "")))
                    row.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                    row.addView(if (h.group.isNotEmpty()) Design.chip(ctx, h.group, Design.GOLD)
                                else Design.chip(ctx, "—", Design.MUTED))
                    listBox.addView(row, Design.lp(top = 6))
                }
            }
            input.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { render(s?.toString() ?: "") }
            })
            render("")
        }
        root.addView(search, Design.lp(bottom = 14))

        // ---- 队伍对比（VIP）----
        if (settings.isVip()) {
            val cmp = Design.card(ctx)
            cmp.addView(Design.section(ctx, "③ 队伍对比", "本地"))
            cmp.addView(Design.space(ctx, 10))
            val a = Design.input(ctx, "甲方游戏名")
            val b = Design.input(ctx, "乙方游戏名")
            cmp.addView(a); cmp.addView(Design.space(ctx, 6)); cmp.addView(b)
            cmp.addView(Design.space(ctx, 8))
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            cmp.addView(box)
            cmp.addView(Design.btn(ctx, "并排对比", 5) {
                box.removeAllViews()
                val ca = repo.card(a.text.toString().trim())
                val cb = repo.card(b.text.toString().trim())
                val r = Design.row(ctx)
                listOf(ca, cb).forEach { card ->
                    val cell = Design.card(ctx, 10)
                    cell.addView(Design.h3(ctx, card.name))
                    cell.addView(Design.cap(ctx, card.group.ifEmpty { "未分组" } + " · " + card.battles + " 场"))
                    cell.addView(Design.space(ctx, 6))
                    card.units.take(3).forEach { u ->
                        cell.addView(Design.cap(ctx,
                            Names.hero(u.heroId) + " Lv" + u.level +
                            " · " + (u.skills.firstOrNull()?.let { Names.skill(it.skillId) } ?: "无战法")))
                    }
                    r.addView(cell, Design.w(ctx, 1f, 5))
                }
                box.addView(r)
            })
            root.addView(cmp, Design.lp(bottom = 14))
        }

        // ---- 说明 ----
        val note = Design.card(ctx)
        note.addView(Design.section(ctx, "数据边界", "重要"))
        note.addView(Design.space(ctx, 8))
        note.addView(Design.cap(ctx,
            "• 网站原有功能（登录 / VIP / 音乐 / 战报解析 / 考勤 / 导出）在「中枢」页完整保留，账号与 VIP 仍在原数据库。\n" +
            "• 本页「战场」是独立原生模块：战报来自你导入的同盟战报包，只存本机加密账包，不写回数据库。\n" +
            "• 悬浮窗不读取游戏界面、不模拟点击、不使用无障碍服务，不存在封号风险。"))
        root.addView(note)
        return root
    }

    private fun storeCounts(repo: TeamRepository): IntArray {
        val t = repo.statsText()
        fun grab(k: String): Int = Regex(k + "\\s(\\d+)").find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        return intArrayOf(grab("战报"), grab("玩家"), grab("分组"), grab("城池"))
    }
}
