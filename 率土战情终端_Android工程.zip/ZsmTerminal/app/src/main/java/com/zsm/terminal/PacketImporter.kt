package com.zsm.terminal

import android.content.Context
import android.net.Uri
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.Base64
import java.util.zip.GZIPInputStream
import java.util.zip.Inflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * 「同盟战报包」导入器：打之前把包丢进来，就有战报数据了。
 * 支持 pcap / pcapng / .gz / 报告 txt / 纯 json / zip 合集。
 * 大包走真流式（64KB 缓冲，274MB 不 OOM），全部本地解析 + 去重，不上传任何服务器。
 */
class PacketImporter(
    private val ctx: Context,
    private val store: BattleStore,
    private val vault: LocalVault
) {
    companion object {
        private val TRIPLE = Regex("\\[\\s*(\\d{3,7})\\s*,\\s*(\\d{1,3})\\s*,\\s*\"([^\"]{1,12})\"\\s*\\]")
        private val STUB = Regex("\\[\\s*(\\d{3,7})\\s*,\\s*\"([^\"]{1,24})\"\\s*,")
        private val HEX = Regex("(?<![0-9A-Fa-f])[0-9A-Fa-f]{32,}(?![0-9A-Fa-f])")
        private val B64 = Regex("[A-Za-z0-9+/]{24,}={0,2}")
        private val SERVER_ARR = Regex("\"server\"\\s*:\\s*\\[\\s*\"([^\"]+)\"\\s*,\\s*\\d+\\s*,\\s*(\\d{3,7})")
        private val ALLIANCE = Regex("\"alliance_id\"\\s*:\\s*(\\d+)")
        private val CHANNEL = Regex("\"(\\d{6}),(\\d{9,11})\"")
        private val BIG = setOf("pcap", "pcapng", "gz")
    }

    /** 文件导入入口：大包流式，小包读全量；解析与加密落盘各开一次流，内存恒定 */
    fun importUri(uri: Uri, name: String): ImportReport {
        val head = ByteArray(8)
        try {
            ctx.contentResolver.openInputStream(uri)?.use { it.read(head, 0, 8) }
                ?: return ImportReport(name, "?", message = "无法读取文件")
        } catch (e: Exception) {
            return ImportReport(name, "?", message = "读取失败：" + e.message)
        }
        val kind = detect(head, name)
        val r = if (kind in BIG) {
            val texts = fromPcapUri(uri, kind)
            consume(texts, emptyList(), name, kind)
        } else {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return ImportReport(name, kind, message = "无法读取文件")
            parseBytes(bytes, name, kind, false)
        }
        // 原始包加密落本地账包（流式）
        val id = sha((name + System.currentTimeMillis()).toByteArray()).take(16)
        val (size, hash) = vault.saveOriginalFromUri(id, uri)
        store.addPacket(PacketInfo(id, name, size, System.currentTimeMillis(),
            kind, r.added, r.duplicate, r.updated, hash))
        return r.copy(bytes = size, message = r.message + " · 已加密存本地")
    }

    /** 实时 TCP 流用：已解出的文本直接去重入本地账包，并把文本包加密留档 */
    fun importTexts(texts: List<String>, name: String): ImportReport {
        val r = consume(texts, emptyList(), name, "stream")
        val bytes = texts.joinToString("\n").toByteArray(Charsets.UTF_8)
        val id = sha(bytes).take(16)
        val (size, hash) = vault.saveOriginal(id, bytes)
        store.addPacket(PacketInfo(id, name, size, System.currentTimeMillis(),
            "stream", r.added, r.duplicate, r.updated, hash))
        return r.copy(bytes = size, message = r.message + " · 已加密存本地")
    }

    /** 供 zip 子项 / 样本 / 测试用 */
    fun importBytes(bytes: ByteArray, name: String): ImportReport =
        parseBytes(bytes, name, detect(bytes.copyOf(minOf(8, bytes.size)), name), true)

    private fun parseBytes(bytes: ByteArray, name: String, kind: String, persist: Boolean): ImportReport {
        val texts = ArrayList<String>()
        var subs = listOf<ImportReport>()
        when (kind) {
            "zip" -> {
                ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
                    while (true) {
                        val e: ZipEntry = z.nextEntry ?: break
                        if (e.isDirectory) { z.closeEntry(); continue }
                        val sub = z.readBytes()
                        val n = e.name.substringAfterLast('/')
                        if (n.endsWith("manifest.json") || n.endsWith(".tsv") || n.startsWith("vault/")) {
                            z.closeEntry(); continue
                        }
                        subs = subs + parseBytes(sub, n, detect(sub.copyOf(minOf(8, sub.size)), n), false)
                        z.closeEntry()
                    }
                }
            }
            "txt" -> texts.addAll(fromTextReport(String(bytes, Charsets.UTF_8)))
            "json" -> {
                val t = String(bytes, Charsets.UTF_8)
                texts.add(t)
                if (t.trimStart().startsWith("[")) {
                    try {
                        JsonParser.parseString(t).asJsonArray.forEach { texts.add(it.toString()) }
                    } catch (e: Exception) { }
                }
            }
            else -> texts.addAll(fromPcap(bytes))
        }
        val r = consume(texts, subs, name, kind)
        if (persist) {
            val id = sha(bytes).take(16)
            val (size, hash) = vault.saveOriginal(id, bytes)
            store.addPacket(PacketInfo(id, name, size, System.currentTimeMillis(),
                kind, r.added, r.duplicate, r.updated, hash))
            return r.copy(bytes = size, message = r.message + " · 已加密存本地")
        }
        return r.copy(bytes = bytes.size.toLong())
    }

    /** 把抽出来的文本写进本地仓库（去重、分组、情报） */
    private fun consume(texts: List<String>, subs: List<ImportReport>,
                        name: String, kind: String): ImportReport {
        var added = 0; var dup = 0; var updated = 0; var groups = 0; var jsonBlocks = 0
        val players = HashSet<String>()
        texts.forEach { text ->
            jsonBlocks++
            collect(text, object : Sink {
                override fun battle(o: JsonObject) {
                    when (store.put(o, name)) { 0 -> added++; 1 -> dup++; 2 -> updated++ }
                }
                override fun group(nm: String, roleId: Long, gid: Int, grp: String) {
                    if (store.groupOf(nm) != grp) { store.putGroup(nm, roleId, gid, grp); groups++ }
                }
                override fun player(nm: String) { if (nm.isNotEmpty()) players.add(nm) }
                override fun intel(k: String, v: String) { store.putIntel(k, v) }
            })
        }
        subs.forEach {
            added += it.added; dup += it.duplicate; updated += it.updated
            groups += it.groups; jsonBlocks += it.jsonBlocks
        }
        val msg = "导入完成：新增 $added · 重复丢弃 $dup · 更新 $updated · 分组 $groups"
        return ImportReport(name, kind, 0L, added, dup, updated, groups,
            players.size, jsonBlocks, msg)
    }

    private interface Sink {
        fun battle(o: JsonObject)
        fun group(nm: String, roleId: Long, gid: Int, grp: String)
        fun player(nm: String)
        fun intel(k: String, v: String)
    }

    private fun collect(text: String, sink: Sink) {
        SERVER_ARR.find(text)?.let { sink.intel("serverCode", it.groupValues[1]); sink.intel("serverId", it.groupValues[2]) }
        ALLIANCE.find(text)?.let { sink.intel("allianceId", it.groupValues[1]) }
        CHANNEL.find(text)?.let { sink.intel("channel", it.groupValues[1]) }

        val nameById = HashMap<Long, String>()
        STUB.findAll(text).forEach { m ->
            val nm = Names.cleanName(m.groupValues[2])
            val rid = m.groupValues[1].toLongOrNull() ?: return@forEach
            if (nm.isNotEmpty()) nameById.putIfAbsent(rid, nm)
        }
        val byRole = HashMap<Long, String>()
        TRIPLE.findAll(text).forEach { m ->
            val gid = m.groupValues[2].toIntOrNull() ?: return@forEach
            val grp = m.groupValues[3]
            val rid = m.groupValues[1].toLongOrNull() ?: return@forEach
            if (Names.GID_MAP[gid] == grp && grp in Names.WHITE) {
                byRole[rid] = grp
                nameById[rid]?.let { sink.group(it, rid, gid, grp) }
            }
        }
        try { walk(JsonParser.parseString(text), sink, 0, byRole) } catch (e: Exception) { }
    }

    private fun walk(el: JsonElement, sink: Sink, depth: Int, byRole: Map<Long, String>) {
        if (depth > 40) return
        if (el.isJsonArray) {
            val a: JsonArray = el.asJsonArray
            if (a.size() >= 30 && a.get(1).isJsonPrimitive) {
                val gid = try { a.get(12).asString.trim().toInt() } catch (e: Exception) { 0 }
                val grp = if (a.get(13).isJsonPrimitive) a.get(13).asString.trim() else ""
                if (Names.GID_MAP[gid] == grp && grp in Names.WHITE) {
                    val nm = Names.cleanName(a.get(1).asString)
                    val rid = try { a.get(0).asString.toLong() } catch (e: Exception) { 0L }
                    if (nm.isNotEmpty()) sink.group(nm, rid, gid, grp)
                }
            }
            for (i in 0 until a.size()) {
                try { walk(a.get(i), sink, depth + 1, byRole) } catch (e: Exception) { }
            }
            return
        }
        if (!el.isJsonObject) return
        val o = el.asJsonObject
        if ((o.has("battle_id") || o.has("id")) && (o.has("attack_name") || o.has("atk"))) {
            sink.battle(o)
            str(o, "attack_name", "atk", "atk_name")?.let { sink.player(Names.cleanName(it)) }
            str(o, "defend_name", "def", "def_name")?.let { sink.player(Names.cleanName(it)) }
        }
        if (o.has("log") && o.get("log").isJsonObject) {
            str(o.getAsJsonObject("log"), "role_name")?.let { sink.player(Names.cleanName(it)) }
        }
        for ((_, v) in o.entrySet()) {
            try { walk(v, sink, depth + 1, byRole) } catch (e: Exception) { }
        }
    }

    private fun str(o: JsonObject, vararg keys: String): String? {
        keys.forEach { k ->
            val v = o.get(k) ?: return@forEach
            if (v.isJsonPrimitive) return v.asString
        }
        return null
    }

    // ---------------- 格式识别 ----------------
    private fun isPcapng(b: ByteArray) = b.size >= 4 &&
        b[0] == 0x0A.toByte() && b[1] == 0x0D.toByte() && b[2] == 0x0D.toByte() && b[3] == 0x0A.toByte()

    private fun isPcap(b: ByteArray): Boolean {
        if (b.size < 4) return false
        val m = ((b[0].toInt() and 255) shl 24) or ((b[1].toInt() and 255) shl 16) or
            ((b[2].toInt() and 255) shl 8) or (b[3].toInt() and 255)
        return m == 0xa1b2c3d4L.toInt() || m == 0xd4c3b2a1L.toInt() ||
            m == 0xa1b23c4dL.toInt() || m == 0x4d3cb2a1L.toInt()
    }

    private fun detect(head: ByteArray, name: String): String {
        val low = name.lowercase()
        if (low.endsWith(".zip")) return "zip"
        if (isPcapng(head) || low.endsWith(".pcapng")) return "pcapng"
        if (head.size > 1 && head[0] == 0x1F.toByte() && head[1] == 0x8B.toByte()) return "gz"
        if (isPcap(head) || low.endsWith(".pcap")) return "pcap"
        if (low.endsWith(".txt") || low.endsWith(".log")) return "txt"
        if (low.endsWith(".json") || low.endsWith(".jsonl") || low.endsWith(".jsonl.txt")) return "json"
        if (head.isNotEmpty() && (head[0] == '{'.toByte() || head[0] == '['.toByte())) return "json"
        if (head.size > 3 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()) return "zip"
        return "txt"
    }

    // ---------------- pcap → 文本 ----------------
    /** 真流式：只保留 64KB 缓冲 + 每条流的增量解压缓冲 */
    private fun fromPcapUri(uri: Uri, kind: String): List<String> {
        val texts = ArrayList<String>()
        val pipeline = ZlibScan.Pipeline { t -> texts.add(t) }
        lateinit var feeder: PcapParser.Feeder
        feeder = PcapParser.Feeder { pkt ->
            val seg = PcapParser.takeTcp(pkt, PcapParser.ipOffset(feeder.linktype()))
            if (seg != null) pipeline.add(seg)
        }
        try {
            ctx.contentResolver.openInputStream(uri)?.use { raw ->
                val s: InputStream = if (kind == "gz") GZIPInputStream(raw) else raw
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = s.read(buf)
                    if (n < 0) break
                    feeder.feed(buf, 0, n)
                }
            }
        } catch (e: Exception) { }
        feeder.flush()
        pipeline.finish()
        return texts
    }

    private fun fromPcap(bytes: ByteArray): List<String> {
        val raw = if (bytes.size > 2 && bytes[0] == 0x1F.toByte() && bytes[1] == 0x8B.toByte()) {
            try { GZIPInputStream(ByteArrayInputStream(bytes)).use { it.readBytes() } }
            catch (e: Exception) { bytes }
        } else bytes
        val texts = ArrayList<String>()
        val pipeline = ZlibScan.Pipeline { t -> texts.add(t) }
        lateinit var feeder: PcapParser.Feeder
        feeder = PcapParser.Feeder { pkt ->
            val seg = PcapParser.takeTcp(pkt, PcapParser.ipOffset(feeder.linktype()))
            if (seg != null) pipeline.add(seg)
        }
        feeder.feed(raw, 0, raw.size)
        feeder.flush()
        pipeline.finish()
        val whole = String(raw, Charsets.UTF_8)
        if (whole.contains("\"battle_id\"") || whole.contains("\"attack_name\"")) texts.add(whole)
        return texts
    }

    // ---------------- 报告 txt ----------------
    private fun fromTextReport(text: String): List<String> {
        val out = ArrayList<String>()
        val seen = HashSet<String>()
        fun addBytes(b: ByteArray) {
            inflateTexts(b).forEach { if (seen.add(it)) out.add(it) }
        }
        HEX.findAll(text).forEach { m ->
            val h = m.value
            if (h.length % 2 == 0) {
                try {
                    val b = ByteArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
                    addBytes(b)
                } catch (e: Exception) { }
            }
        }
        B64.findAll(text).forEach { m ->
            val v = m.value
            if (v.length % 4 == 0) {
                try { addBytes(Base64.getDecoder().decode(v)) } catch (e: Exception) { }
            }
        }
        val t = text.trim()
        if ((t.startsWith("{") && t.endsWith("}")) || (t.startsWith("[") && t.endsWith("]"))) {
            if (seen.add(t)) out.add(t)
        }
        if (out.isEmpty() && (text.contains("battle_id") || text.contains("attack_name"))) out.add(text)
        return out
    }

    private fun inflateTexts(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        var off = 0; var guard = 0
        while (off < b.size - 2 && guard++ < 200000) {
            val idx = ZlibScan.findHead(b, off, b.size)
            if (idx < 0) break
            val inf = Inflater()
            var consumed = 0; var data: ByteArray? = null
            try {
                inf.setInput(b, idx, b.size - idx)
                val bos = ByteArrayOutputStream()
                val tmp = ByteArray(65536)
                while (!inf.finished()) {
                    val n = inf.inflate(tmp); if (n == 0) break
                    bos.write(tmp, 0, n)
                    if (bos.size() > 32 * 1024 * 1024) break
                }
                consumed = inf.bytesRead.toInt(); data = bos.toByteArray()
            } catch (e: Exception) { } finally { inf.end() }
            val d = data
            if (d != null && d.isNotEmpty()) out.add(String(d, Charsets.UTF_8))
            off = if (consumed > 0) idx + consumed else idx + 2
        }
        return out
    }

    private fun sha(b: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(b).joinToString("") { "%02x".format(it) }
}
