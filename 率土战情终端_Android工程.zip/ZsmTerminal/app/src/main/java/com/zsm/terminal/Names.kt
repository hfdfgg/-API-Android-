package com.zsm.terminal

/** 武将 / 战法字典 + 队伍名归一化（「知夏丨江东」→「知夏」） */
object Names {
    val GID_MAP: Map<Int, String> = linkedMapOf(
        6 to "武陵", 7 to "天门", 8 to "桂阳", 9 to "长沙", 10 to "南",
        11 to "襄阳", 12 to "南阳", 13 to "江夏", 50 to "铺路组"
    )
    val WHITE: Set<String> = GID_MAP.values.toSet()
    val GROUP_ORDER: List<String> = GID_MAP.values.toList()

    private val HERO: Map<Long, String> = mapOf(
        100015L to "甄洛", 100024L to "荀彧", 100029L to "大乔", 100042L to "张春华",
        100268L to "花鬘", 100372L to "妲己", 100424L to "小乔＆大乔", 100479L to "孙坚",
        100498L to "曹纯", 100507L to "曹彰", 100520L to "典韦",
        100018L to "吕蒙", 100021L to "周瑜", 100027L to "诸葛亮", 100034L to "赵云",
        100040L to "关羽", 100046L to "张飞", 100051L to "曹操", 100060L to "刘备",
        100102L to "陆逊", 100130L to "郭嘉", 100143L to "贾诩", 100166L to "马超",
        100205L to "黄月英", 100233L to "孙权", 100301L to "张辽", 100355L to "郝昭",
        100401L to "群貂蝉", 100441L to "木鹿大王", 100466L to "严颜", 100488L to "王异"
    )

    private val SKILL: Map<Long, String> = mapOf(
        200001L to "先驱突击", 200002L to "浑水摸鱼", 200004L to "反计之策",
        200009L to "战必断金", 200012L to "避其锋芒", 200014L to "神兵天降",
        200017L to "大赏三军", 200024L to "始计", 200026L to "妖术",
        200028L to "重整旗鼓", 200029L to "众谋不懈", 200033L to "垒实迎击",
        200003L to "连环", 200006L to "落雷", 200007L to "迷阵",
        200010L to "青囊秘要", 200011L to "温酒斩将", 200015L to "一骑当千",
        200018L to "十面埋伏", 200021L to "桃园结义", 200022L to "形兵之极",
        200025L to "攻其不备", 200027L to "鹤翼", 200030L to "掎角之势",
        200031L to "疾风迅雷", 200032L to "锋矢", 200034L to "回马",
        200035L to "健卒不殆", 200036L to "合纵连横", 200037L to "垒实迎击"
    )

    fun hero(id: Long): String = HERO[id] ?: "武将$id"
    fun skill(id: Long): String = SKILL[id] ?: "战法$id"
    fun gidOf(group: String): Int = GID_MAP.entries.firstOrNull { it.value == group }?.key ?: 0

    private val SEP = Regex("[丨|·丶、\\s lL/]+")

    /** 地图上的「知夏丨江东」要能落到名单里的「知夏」 */
    fun baseName(n: String): String {
        val t = n.trim().split('#')[0].trim()
        if (t.isEmpty()) return t
        return SEP.split(t).firstOrNull { it.isNotEmpty() } ?: t
    }

    private val GARBLED = Regex("[-�]|锟斤拷|烫烫烫|屯屯屯|鍙|绾|姹|敘|鎶|鐭|鍗|闀|妗|姝|瑗|婕|椤|愶|銆|锛|涔|涓|甇|獢|镼|踵|瘙|æ|å|Ã|Ð|Ñ")
    private val VALID = Regex("[一-龥A-Za-z]")

    fun cleanName(v: Any?): String {
        var t = (v?.toString() ?: "").trim()
        t = t.split('#')[0].trim()
        if (t.isEmpty() || t.length > 24 || t.all { it.isDigit() }) return ""
        if (!VALID.containsMatchIn(t)) return ""
        if (GARBLED.containsMatchIn(t)) return ""
        return t
    }
}
