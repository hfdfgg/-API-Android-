package com.zsm.terminal

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Environment
import android.view.Gravity
import android.view.Window
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

/** 点队伍名弹出的情报卡：分组 / 城池 / 服务器 / 阵容 / 战法 / 战损 / 收藏备注 */
object TeamCardDialog {

    fun show(ctx: Context, card: TeamCard, onChanged: () -> Unit) {
        val d = Dialog(ctx)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val outer = Design.card(ctx, 0, true)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Design.dp(ctx, 18), Design.dp(ctx, 16),
                Design.dp(ctx, 18), Design.dp(ctx, 16))
        }

        // 头部
        val head = Design.row(ctx)
        head.addView(Design.h2(ctx, card.name),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(if (card.favorite) Design.chip(ctx, "★ 已收藏", Design.GOLD)
                     else Design.chip(ctx, "未收藏", Design.MUTED))
        head.addView(Design.chip(ctx, "关闭", Design.DANGER).also {
            it.setOnClickListener { d.dismiss() }
        })
        root.addView(head)
        root.addView(Design.cap(ctx, "来自本地同盟战报包 · " + card.source))
        root.addView(Design.space(ctx, 10))

        // 统计条
        val stats = Design.row(ctx)
        listOf("场次" to card.battles.toString(), "胜场" to card.wins.toString(),
               "分组" to (card.group.ifEmpty { "—" })).forEach { (k, v) ->
            stats.addView(Design.stat(ctx, k, v, Design.CYAN), Design.w(ctx, 1f, 6))
        }
        root.addView(stats)
        root.addView(Design.space(ctx, 10))

        fun info(k: String, v: String) {
            val r = Design.row(ctx)
            r.addView(Design.cap(ctx, k),
                LinearLayout.LayoutParams(Design.dp(ctx, 74), LinearLayout.LayoutParams.WRAP_CONTENT))
            r.addView(Design.body(ctx, v, Design.TEXT))
            root.addView(r, Design.lp(top = 4))
        }
        info("分组名字", if (card.group.isEmpty()) "—" else "${card.groupId} ${card.group}")
        info("城池名字", if (card.city.isEmpty()) "—" else "${card.city} (${card.x}, ${card.y})")
        info("服务器", card.server.ifEmpty { "—" })
        info("同盟", card.union.ifEmpty { "—" })
        info("定位", if (card.side.isEmpty()) "—" else card.side + " · " +
            when (card.result) { 1 -> "攻方大捷"; 0 -> "守方胜利"; else -> "平局/未知" })
        if (card.cities.isNotEmpty()) info("出没城池", card.cities.joinToString("、"))

        root.addView(Design.divider(ctx), Design.lp(top = 10, bottom = 6))

        val scroll = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        if (card.units.isEmpty()) {
            scroll.addView(Design.cap(ctx, "暂无该队伍的阵容记录：先导入包含该玩家的同盟战报包。"))
        }
        card.units.forEachIndexed { i, u ->
            val line = Design.h3(ctx,
                "${i + 1}  ${Names.hero(u.heroId)}  Lv${u.level}" +
                (if (u.advance > 0) "  " + "★".repeat(u.advance) else "") +
                "   战损 ${u.loss}" + (if (u.dead > 0) " / 阵亡 ${u.dead}" else ""))
            line.setTextColor(Design.CYAN)
            scroll.addView(line, Design.lp(top = 8))
            val sk = if (u.skills.isEmpty()) "暂无战法记录"
                     else u.skills.joinToString(" · ") { "${Names.skill(it.skillId)} Lv${it.level}" }
            scroll.addView(Design.cap(ctx, "    " + sk))
        }
        val sv = ScrollView(ctx).apply { addView(scroll) }
        root.addView(sv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Design.dp(ctx, 190)))

        // 备注
        root.addView(Design.cap(ctx, "备注（本地保存）"), Design.lp(top = 10))
        val note = Design.input(ctx, "给这支队伍写个备注").apply { setText(card.note) }
        root.addView(note)
        root.addView(Design.space(ctx, 10))

        val actions = Design.row(ctx)
        actions.addView(Design.btn(ctx, if (card.favorite) "取消收藏" else "★ 收藏", 3) {
            // 由调用方传入仓库，这里通过 AppState 事件让页面自行切换
            TeamCardBus.toggle(card.name)
            d.dismiss(); onChanged()
        }, Design.w(ctx, 1f, 6))
        actions.addView(Design.btn(ctx, "保存备注", 5) {
            TeamCardBus.note(card.name, note.text.toString())
            d.dismiss(); onChanged()
        }, Design.w(ctx, 1f, 6))
        actions.addView(Design.btn(ctx, "导出图片", 2) {
            exportPng(ctx, outer)
        }, Design.w(ctx, 1f, 0))
        root.addView(actions)

        outer.addView(root)
        val wrap = ScrollView(ctx).apply { addView(outer) }
        d.setContentView(wrap)
        d.window?.setLayout(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )
        d.window?.setGravity(Gravity.CENTER)
        d.show()
    }

    private fun exportPng(ctx: Context, view: android.view.View) {
        try {
            val w = view.width.takeIf { it > 0 } ?: 900
            val h = view.height.takeIf { it > 0 } ?: 1200
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bmp))
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: ctx.filesDir
            val f = File(dir, "队伍卡_" + System.currentTimeMillis() + ".png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(ctx, "队伍卡图片已保存：" + f.absolutePath, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "导出失败：" + e.message, Toast.LENGTH_SHORT).show()
        }
    }
}

/** 队伍卡 → 页面之间的轻量事件（避免把仓库引用塞进每一行 UI） */
object TeamCardBus {
    @Volatile private var repoRef: TeamRepository? = null
    fun attach(r: TeamRepository) { repoRef = r }
    fun toggle(name: String) { repoRef?.toggleFavorite(name) }
    fun note(name: String, note: String) { repoRef?.setNote(name, note) }
}
