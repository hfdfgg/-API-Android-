package com.zsm.terminal

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    fun dp(ctx: Context, v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics
    ).toInt()

    fun roundBg(color: Int, radiusDp: Float, stroke: Int = 0, strokeColor: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp
            if (stroke > 0) setStroke(stroke, strokeColor)
        }

    fun tv(ctx: Context, text: String, size: Float = 14f, color: Int = Color.parseColor("#1E293B"),
           bold: Boolean = false): TextView = TextView(ctx).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 2), Ui.dp(ctx, 2), Ui.dp(ctx, 2))
    }

    fun row(ctx: Context, horizontal: Boolean = true): LinearLayout = LinearLayout(ctx).apply {
        orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
    }

    fun button(ctx: Context, text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        tv(ctx, text, 14f, fg, true).apply {
            background = roundBg(bg, Ui.dp(ctx, 12).toFloat())
            gravity = Gravity.CENTER
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12))
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun label(ctx: Context, text: String): TextView =
        tv(ctx, text, 12f, Color.parseColor("#64748B"))

    fun divider(ctx: Context): TextView = TextView(ctx).apply {
        setBackgroundColor(Color.parseColor("#E2E8F0"))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 1))
    }
}
