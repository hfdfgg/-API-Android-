package com.zsm.terminal

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Window
import android.widget.LinearLayout

object Onboarding {
    fun show(ctx: Context, onDone: () -> Unit) {
        val d = Dialog(ctx)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val card = Design.hero(ctx)
        card.addView(Design.h1(ctx, "欢迎使用率土战情终端"))
        card.addView(Design.space(ctx, 8))
        card.addView(Design.cap(ctx, "v2.0 · 上市版"))
        card.addView(Design.space(ctx, 14))
        listOf(
            "中枢" to "网站全部功能已离线集成：登录、VIP、音乐、签到、邮件、同盟、战报、考勤、导出。",
            "战场" to "打之前导入一个「同盟战报包」，本地解析并自动去重；搜势力名即可查看队伍阵容。",
            "悬浮窗" to "VIP 专属：点悬浮球 → 搜索 / 剪贴板取词 → 弹出对方队伍信息卡。",
            "安全" to "不使用无障碍、不读取游戏界面、不模拟点击；战报只存本机加密账包，不上传数据库。"
        ).forEach { (t, s) ->
            val row = Design.row(ctx)
            row.addView(Design.icon(ctx, R.drawable.ic_shield, Design.GOLD, 18),
                LinearLayout.LayoutParams(Design.dp(ctx, 18), Design.dp(ctx, 18)))
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            box.addView(Design.h3(ctx, "  " + t))
            box.addView(Design.cap(ctx, "  " + s))
            row.addView(box)
            card.addView(row, Design.lp(top = 10))
        }
        card.addView(Design.space(ctx, 16))
        card.addView(Design.btn(ctx, "开始使用", 3) { d.dismiss(); onDone() })
        val wrap = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Design.dp(ctx, 12), Design.dp(ctx, 12),
                Design.dp(ctx, 12), Design.dp(ctx, 12))
            addView(card)
        }
        d.setContentView(wrap)
        d.setCancelable(false)
        d.show()
    }
}
