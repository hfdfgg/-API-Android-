package com.zsm.terminal

import android.content.Context
import android.view.View
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.lang.ref.WeakReference

/** 「设置」页：账号 / 悬浮球 / 音乐 / 合规 / 运行日志 */
object SettingsView {

    private var logRef: WeakReference<TextView>? = null
    private val buffer = StringBuilder()

    fun appendRuntimeLog(msg: String) {
        buffer.insert(0, "• " + msg + "\n")
        if (buffer.length > 5000) buffer.setLength(5000)
        logRef?.get()?.post { it.text = buffer.toString() }
    }

    fun build(ctx: Context, settings: Settings, vault: LocalVault,
              onOverlay: (Boolean) -> Unit, onSync: () -> Unit,
              onMusic: (Boolean) -> Unit): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Design.dp(ctx, 14), Design.dp(ctx, 16),
                Design.dp(ctx, 14), Design.dp(ctx, 24))
        }

        // 账号
        val acc = Design.card(ctx)
        acc.addView(Design.section(ctx, "账号与会员", "网站云端"))
        acc.addView(Design.space(ctx, 10))
        val p = settings.profile
        acc.addView(Design.h2(ctx, p.nickname.ifEmpty { p.forceName.ifEmpty { "未登录" } }))
        acc.addView(Design.cap(ctx,
            "势力：" + (p.forceName.ifEmpty { "—" }) + " · 同盟：" + (p.alliance.ifEmpty { "—" }) +
            " · 起灵币 " + p.coins))
        acc.addView(Design.space(ctx, 8))
        val vr = Design.row(ctx)
        vr.addView(if (settings.isVip()) Design.chip(ctx, "VIP 已开通 · 悬浮情报可用", Design.GOLD)
                   else Design.chip(ctx, "普通用户 · 悬浮情报锁定", Design.MUTED))
        acc.addView(vr)
        acc.addView(Design.space(ctx, 10))
        acc.addView(Design.btn(ctx, "重新同步网站登录态 / VIP", 5, onSync))
        acc.addView(Design.space(ctx, 8))
        acc.addView(Design.cap(ctx, "账号、VIP、公告、邮件、兑换码等仍在原数据库；这里只镜像状态给原生模块使用。"))
        root.addView(acc, Design.lp(bottom = 14))

        // 悬浮球
        val ov = Design.card(ctx)
        ov.addView(Design.section(ctx, "悬浮队伍情报", "VIP"))
        ov.addView(Design.space(ctx, 10))
        val sw = Switch(ctx).apply {
            text = "开启悬浮球（头像来自你提供的图）"
            setTextColor(Design.TEXT)
            isChecked = AppState.overlayOn
            setOnCheckedChangeListener { _: CompoundButton, on: Boolean -> onOverlay(on) }
        }
        ov.addView(sw)
        ov.addView(Design.space(ctx, 8))
        ov.addView(Design.cap(ctx, "悬浮球大小"))
        ov.addView(seek(ctx, 40, 88, settings.ballSize) { settings.ballSize = it })
        ov.addView(Design.cap(ctx, "悬浮球不透明度"))
        ov.addView(seek(ctx, 40, 100, settings.ballAlpha) { settings.ballAlpha = it })
        val toggles = Design.row(ctx)
        toggles.addView(switchSmall(ctx, "剪贴板取词", settings.clipboardPick) {
            settings.clipboardPick = it
        }, Design.w(ctx, 1f, 6))
        toggles.addView(switchSmall(ctx, "轻震动反馈", settings.haptic) {
            settings.haptic = it
        }, Design.w(ctx, 1f, 0))
        ov.addView(toggles, Design.lp(top = 8))
        ov.addView(Design.space(ctx, 8))
        ov.addView(Design.cap(ctx,
            "点悬浮球 → 搜索框（或自动带入剪贴板里复制的游戏名）→ 点结果弹出对方队伍卡。" +
            "不使用无障碍服务，不读取游戏界面。"))
        root.addView(ov, Design.lp(bottom = 14))

        // 音乐
        val mu = Design.card(ctx)
        mu.addView(Design.section(ctx, "背景音乐", "网站自带"))
        mu.addView(Design.space(ctx, 10))
        val mr = Design.row(ctx)
        mr.addView(Design.btn(ctx, "播放", 1) { onMusic(true) }, Design.w(ctx, 1f, 6))
        mr.addView(Design.btn(ctx, "暂停", 5) { onMusic(false) }, Design.w(ctx, 1f, 0))
        mu.addView(mr)
        mu.addView(Design.space(ctx, 8))
        mu.addView(Design.cap(ctx, "网站全功能（含 BGM / 头像框 / 签到 / 邮件）在「中枢」页原样运行，前台服务保活。"))
        root.addView(mu, Design.lp(bottom = 14))

        // 合规与关于
        val about = Design.card(ctx)
        about.addView(Design.section(ctx, "合规与关于", "v2.0"))
        about.addView(Design.space(ctx, 8))
        about.addView(Design.h3(ctx, "率土战情终端 2.0.0"))
        about.addView(Design.cap(ctx, "设备凭据：" + (if (vault.isDeviceSecure()) "已设置" else "未设置") +
            " · 账包 AES-256-GCM · 本地崩溃日志已开启"))
        about.addView(Design.space(ctx, 8))
        val shield = Design.row(ctx)
        shield.addView(Design.icon(ctx, R.drawable.ic_shield, Design.WIN, 18),
            LinearLayout.LayoutParams(Design.dp(ctx, 18), Design.dp(ctx, 18)))
        shield.addView(Design.cap(ctx, "  无无障碍 / 无录屏 / 无注入 / 无模拟点击 · 不会因读游戏界面被封号",
            Design.WIN))
        about.addView(shield)
        about.addView(Design.space(ctx, 8))
        about.addView(Design.cap(ctx,
            "战场模块与网站解析模块相互独立：网站的战报上传、考勤、分析仍在云端；" +
            "本模块战报只来自你导入的同盟战报包，只存本机。"))
        root.addView(about, Design.lp(bottom = 14))

        // 运行日志
        val log = Design.card(ctx)
        log.addView(Design.section(ctx, "运行日志", "本地"))
        log.addView(Design.space(ctx, 8))
        val tv = Design.cap(ctx, if (buffer.isEmpty()) "等待操作…" else buffer.toString())
        logRef = WeakReference(tv)
        log.addView(tv)
        root.addView(log)
        return root
    }

    private fun seek(ctx: Context, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): View =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            val label = Design.cap(ctx, "$value")
            val sb = SeekBar(ctx).apply {
                this.max = max - min
                progress = (value - min).coerceIn(0, max - min)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        val v = p + min; label.text = "$v"; onChange(v)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            addView(label)
            addView(sb)
        }

    private fun switchSmall(ctx: Context, label: String, value: Boolean, onChange: (Boolean) -> Unit): View =
        Switch(ctx).apply {
            text = label
            setTextColor(Design.MUTED)
            textSize = 12f
            isChecked = value
            setOnCheckedChangeListener { _: CompoundButton, on: Boolean -> onChange(on) }
        }
}
