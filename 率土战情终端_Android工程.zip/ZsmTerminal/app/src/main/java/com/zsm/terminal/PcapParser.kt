package com.zsm.terminal

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.PushbackInputStream
import java.util.zip.GZIPInputStream
import kotlin.math.max

/**
 * PCAPdroid「TCP 导出器 / pcap-over-ip」发的就是 pcap 文件字节流：
 * classic pcap 24B global header + 若干 (16B record header + packet)，
 * 或 pcapng 的 SHB / IDB / EPB。本解析器是流式的：半包、粘包、274MB 大包都能吃，
 * 不会把整个文件读进内存。
 */
object PcapParser {

    data class Segment(val key: String, val seq: Long, val payload: ByteArray)

    fun ipOffset(linktype: Int): Int = when (linktype) {
        1 -> 14                          // Ethernet
        101, 12, 228, 0 -> 0            // RAW IP
        113 -> 16                       // Linux SLL
        276 -> 20                       // Linux SLL2
        else -> 14
    }

    /** 从链路层包里取 TCP 段（与网站 src-pcap.takeTcp 同构） */
    fun takeTcp(p: ByteArray, ipOff: Int): Segment? {
        if (p.size <= ipOff + 20) return null
        val v0 = p[ipOff].toInt() and 0xFF
        if ((v0 shr 4) != 4) return null                    // 只处理 IPv4
        if ((p[ipOff + 9].toInt() and 0xFF) != 6) return null // 只处理 TCP
        val ihl = (v0 and 0x0F) * 4
        val t = ipOff + ihl
        if (p.size < t + 20) return null
        fun u16(o: Int) = ((p[o].toInt() and 0xFF) shl 8) or (p[o + 1].toInt() and 0xFF)
        fun u32(o: Int): Long =
            ((p[o].toLong() and 0xFF) shl 24) or ((p[o + 1].toLong() and 0xFF) shl 16) or
                ((p[o + 2].toLong() and 0xFF) shl 8) or (p[o + 3].toLong() and 0xFF)
        val sp = u16(t); val dp = u16(t + 2)
        val seq = u32(t + 4)
        val dataOff = ((p[t + 12].toInt() and 0xFF) shr 4) * 4
        val po = t + dataOff
        if (po >= p.size || dataOff < 20) return null
        val src = "${p[ipOff + 12].toInt() and 0xFF}.${p[ipOff + 13].toInt() and 0xFF}." +
                "${p[ipOff + 14].toInt() and 0xFF}.${p[ipOff + 15].toInt() and 0xFF}"
        val dst = "${p[ipOff + 16].toInt() and 0xFF}.${p[ipOff + 17].toInt() and 0xFF}." +
                "${p[ipOff + 18].toInt() and 0xFF}.${p[ipOff + 19].toInt() and 0xFF}"
        return Segment("$src:$sp>$dst:$dp", seq, p.copyOfRange(po, p.size))
    }

    private fun le32(b: ByteArray, o: Int): Long =
        ((b[o + 3].toLong() and 0xFF) shl 24) or ((b[o + 2].toLong() and 0xFF) shl 16) or
            ((b[o + 1].toLong() and 0xFF) shl 8) or (b[o].toLong() and 0xFF)

    private fun be32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun u16(b: ByteArray, o: Int, little: Boolean): Int =
        if (little) ((b[o + 1].toInt() and 0xFF) shl 8) or (b[o].toInt() and 0xFF)
        else ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    /**
     * 流式喂入：feed() 可反复调用，每攒够一个完整包就回调 onPacket。
     * 内部自己维护缓冲区与 compact，不会随包数线性膨胀。
     */
    class Feeder(private val onPacket: (ByteArray) -> Unit) {
        private var store = ByteArray(64 * 1024)
        private var size = 0
        private var mode = 0            // 0=文件头 1=classic记录头 2=classic记录体 3=pcapng块头 4=pcapng块体
        private var need = 24
        private var little = true
        private var ngLittle = true
        private var linktype = 1
        private var ngType = 0L
        private var ngLen = 0L
        private var isNg = false
        @Volatile var packetCount = 0

        private fun ensure(cap: Int) {
            if (store.size < cap) {
                var n = store.size
                while (n < cap) n = max(cap, n * 2)
                store = store.copyOf(n)
            }
        }

        private fun consume(n: Int) {
            if (n >= size) { size = 0; return }
            System.arraycopy(store, n, store, 0, size - n)
            size -= n
        }

        fun feed(data: ByteArray, off: Int, len: Int) {
            if (len <= 0) return
            ensure(size + len)
            System.arraycopy(data, off, store, size, len)
            size += len
            loop()
        }

        /** 连接断开 / 文件结束时，把残包尽量处理掉 */
        fun flush() { loop(); if (mode == 4 && size >= 12) handleNgBlock(); }

        private fun loop() {
            var guard = 0
            while (guard++ < 200000) {
                if (size < need) return
                when (mode) {
                    0 -> {
                        val b = store
                        val isShb = size >= 4 && (b[0].toInt() and 0xFF) == 0x0A &&
                                (b[1].toInt() and 0xFF) == 0x0D &&
                                (b[2].toInt() and 0xFF) == 0x0D && (b[3].toInt() and 0xFF) == 0x0A
                        if (isShb) {
                            isNg = true; mode = 3; need = 8
                        } else {
                            val m0 = (b[0].toInt() and 0xFF)
                            val m1 = (b[1].toInt() and 0xFF)
                            little = !(m0 == 0xA1 && m1 == 0xB2)   // 大端 magic a1b2c3d4 / a1b23c4d
                            linktype = (if (little) le32(b, 20) else be32(b, 20)).toInt()
                            mode = 1; need = 16
                        }
                        consume(24)
                    }
                    1 -> {
                        val il = (if (little) le32(store, 8) else be32(store, 8)).toInt()
                        consume(16)
                        if (il <= 0 || il > 8 * 1024 * 1024) { mode = 1; need = 16; return }
                        need = il; mode = 2
                    }
                    2 -> {
                        val pkt = store.copyOfRange(0, need)
                        onPacket(pkt)
                        packetCount++
                        consume(need)
                        mode = 1; need = 16
                    }
                    3 -> {
                        // pcapng 块头：type(4) + total length(4)
                        val b = store
                        val isShb = (b[0].toInt() and 0xFF) == 0x0A && (b[1].toInt() and 0xFF) == 0x0D &&
                                (b[2].toInt() and 0xFF) == 0x0D && (b[3].toInt() and 0xFF) == 0x0A
                        var len = if (ngLittle) le32(b, 4) else be32(b, 4)
                        if (isShb) {
                            val bom = b.copyOfRange(8, 12)
                            ngLittle = !((bom[0].toInt() and 0xFF) == 0x4D &&
                                    (bom[1].toInt() and 0xFF) == 0x3C)
                            if (!ngLittle) len = be32(b, 4)
                        }
                        ngType = if (ngLittle) le32(b, 0) else be32(b, 0)
                        ngLen = len
                        if (ngLen < 12 || ngLen > 16 * 1024 * 1024) { consume(8); need = 8; return }
                        need = ngLen.toInt(); mode = 4
                        // 头部 8 字节先留着，块体一起在 mode=4 处理
                    }
                    4 -> {
                        handleNgBlock()
                        consume(need)
                        mode = 3; need = 8
                    }
                }
            }
        }

        private fun handleNgBlock() {
            val b = store
            val n = need
            if (n < 12 || size < n) return
            when (ngType) {
                1L -> if (n >= 10) linktype = u16(b, 8, ngLittle) // IDB
                6L -> {                                            // EPB
                    if (n >= 32) {
                        val capLen =
                            (if (ngLittle) le32(b, 20) else be32(b, 20)).toInt()
                        val st = 28
                        if (capLen > 0 && st + capLen <= n) {
                            val pkt = b.copyOfRange(st, st + capLen)
                            onPacket(pkt)
                            packetCount++
                        }
                    }
                }
            }
        }

        fun linktype(): Int = linktype
    }

    /** 文件导入：分块读，gzip 整体自动解，绝不整文件进内存 */
    fun parseFile(ins: InputStream, feeder: Feeder) {
        val pb = PushbackInputStream(ins, 2)
        val head = ByteArray(2)
        val n = pb.read(head)
        if (n == 2) pb.unread(head, 0, 2)
        val stream: InputStream =
            if (n == 2 && (head[0].toInt() and 0xFF) == 0x1F && (head[1].toInt() and 0xFF) == 0x8B)
                GZIPInputStream(pb) else pb
        val buf = ByteArray(64 * 1024)
        stream.use { s ->
            while (true) {
                val r = s.read(buf)
                if (r < 0) break
                feeder.feed(buf, 0, r)
            }
        }
        feeder.flush()
    }
}
