package com.zsm.terminal

import java.util.concurrent.CopyOnWriteArrayList

object AppState {
    interface Listener {
        fun onUpdate(msg: String)
        fun onLog(msg: String)
    }

    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile var serviceRunning = false
    @Volatile var overlayOn = false
    @Volatile var lastMessage = "尚未解析"
    @Volatile var lastResult: DecodeResult = DecodeResult()

    fun register(l: Listener) { if (!listeners.contains(l)) listeners.add(l) }
    fun unregister(l: Listener) { listeners.remove(l) }
    fun emitUpdate(msg: String) {
        lastMessage = msg
        listeners.forEach { try { it.onUpdate(msg) } catch (e: Exception) { } }
    }
    fun emitLog(msg: String) {
        listeners.forEach { try { it.onLog(msg) } catch (e: Exception) { } }
    }
}
