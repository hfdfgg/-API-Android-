package com.zsm.terminal

import android.webkit.WebView
import java.lang.ref.WeakReference
import java.util.concurrent.CopyOnWriteArrayList

object AppState {
    interface Listener {
        fun onStatus(msg: String)
        fun onLog(msg: String)
        fun onProfile(p: Profile)
        fun onImported(r: ImportReport)
    }
    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile var serviceRunning = false
    @Volatile var overlayOn = false
    @Volatile var lastStatus = "尚未导入同盟战报包"
    @Volatile var lastProfile = Profile()
    @Volatile var statsText = "战报 0 条 · 玩家 0 人 · 账包 0 个"
    private var webRef: WeakReference<WebView>? = null

    fun register(l: Listener) { if (!listeners.contains(l)) listeners.add(l) }
    fun unregister(l: Listener) { listeners.remove(l) }

    fun status(msg: String) {
        lastStatus = msg
        listeners.forEach { try { it.onStatus(msg) } catch (e: Exception) { } }
    }
    fun log(msg: String) {
        listeners.forEach { try { it.onLog(msg) } catch (e: Exception) { } }
    }
    fun profile(p: Profile) {
        lastProfile = p
        listeners.forEach { try { it.onProfile(p) } catch (e: Exception) { } }
    }
    fun imported(r: ImportReport) {
        listeners.forEach { try { it.onImported(r) } catch (e: Exception) { } }
    }

    fun bindWebView(w: WebView) { webRef = WeakReference(w) }
    /** 原生 → 网站：让网站把 currentUser / VIP 再同步一次 */
    fun requestProfileSync() {
        webRef?.get()?.post {
            try { evaluateJavascript("window.__zsmRequestSync && window.__zsmRequestSync()", null) }
            catch (e: Exception) { }
        }
    }
    /** 原生 → 网站：通知栏控制背景音乐（网站自带 SITE_MUSIC） */
    fun music(play: Boolean) {
        webRef?.get()?.post {
            try {
                evaluateJavascript(
                    "(function(){try{var a=SITE_MUSIC.audio;if(!a)return;if(" + play +
                        ")a.play();else a.pause();}catch(e){}})()", null
                )
            } catch (e: Exception) { }
        }
    }
}
