package com.zsm.terminal

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 「账包」页：本地加密账包清单、去重统计、备份与清空 */
object VaultView {

    fun build(ctx: Context, store: BattleStore, vault: LocalVault,
              onImport: () -> Unit, onBackupOut: () -> Unit,
              onBackupIn: () -> Unit, onClear: () -> Unit): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Design.dp(ctx, 14), Design.dp(ctx, 16),
                Design.dp(ctx, 14), Design.dp(ctx, 24))
        }

        val hero = Design.hero(ctx)
        val r = Design.row(ctx)
        r.addView(Design.icon(ctx, R.drawable.ic_vault, Design.GOLD, 26),
            LinearLayout.LayoutParams(Design.dp(ctx, 26), Design.dp(ctx, 26)))
        r.addView(Design.h1(ctx, "  本地账包"))
        hero.addView(r)
        hero.addView(Design.cap(ctx, "原始包 AES-256-GCM 加密 · 解析结果存本机 SQLite · 不上传"))
        hero.addView(Design.space(ctx, 12))
        val stats = Design.row(ctx)
        val c = store.counts()
        listOf("战报" to c[0].toString(), "账包" to c[2].toString(),
               "分组" to c[4].toString(), "占用" to fmtSize(vault.totalBytes())).forEach { (k, v) ->
            stats.addView(Design.stat(ctx, k, v, Design.GOLD), Design.w(ctx, 1f, 6))
        }
        hero.addView(stats)
        root.addView(hero, Design.lp(bottom = 14))

        // 操作
        val ops = Design.card(ctx)
        ops.addView(Design.section(ctx, "账包操作"))
        ops.addView(Design.space(ctx, 10))
        ops.addView(Design.btn(ctx, "导入同盟战报包", 1, onImport))
        ops.addView(Design.space(ctx, 8))
        val row1 = Design.row(ctx)
        row1.addView(Design.btn(ctx, "导出备份 zip", 2, onBackupOut), Design.w(ctx, 1f, 6))
        row1.addView(Design.btn(ctx, "恢复备份", 5, onBackupIn), Design.w(ctx, 1f, 0))
        ops.addView(row1)
        ops.addView(Design.space(ctx, 8))
        ops.addView(Design.btn(ctx, "清空全部本地账包", 4, onClear))
        ops.addView(Design.space(ctx, 8))
        ops.addView(Design.cap(ctx,
            "备份含战报 jsonl、分组、收藏与加密原始包；导出前若设备有锁屏凭据会要求验证。" +
            "账号 / VIP / 邮件等仍在网站云端，不受此处清空影响。"))
        root.addView(ops, Design.lp(bottom = 14))

        // 清单
        val list = Design.card(ctx)
        list.addView(Design.section(ctx, "已导入的账包", store.packets().size.toString() + " 个"))
        list.addView(Design.space(ctx, 8))
        val ps = store.packets()
        if (ps.isEmpty()) {
            list.addView(Design.cap(ctx, "还没有账包。点上方「导入同盟战报包」开始。"))
        }
        ps.forEach { p ->
            val row = Design.card(ctx, 10)
            val top = Design.row(ctx)
            val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            box.addView(Design.h3(ctx, p.name))
            box.addView(Design.cap(ctx,
                p.kind.uppercase() + " · " + fmtSize(p.size) + " · " +
                SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(p.addedAt))))
            top.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val del = Design.chip(ctx, "删除", Design.DANGER)
            del.setOnClickListener {
                vault.deleteOriginal(p.id); store.deletePacket(p.id)
                AppState.imported(ImportReport(p.name, message = "已删除账包：" + p.name))
            }
            top.addView(del)
            row.addView(top)
            val nums = Design.row(ctx)
            listOf("新增 ${p.battles}" to Design.WIN,
                   "重复丢弃 ${p.duplicate}" to Design.MUTED,
                   "更新 ${p.updated}" to Design.CYAN).forEach { (t, col) ->
                nums.addView(Design.cap(ctx, t, col), Design.w(ctx, 1f, 4))
            }
            row.addView(nums, Design.lp(top = 8))
            list.addView(row, Design.lp(top = 8))
        }
        root.addView(list, Design.lp(bottom = 14))

        val note = Design.card(ctx)
        note.addView(Design.section(ctx, "去重规则"))
        note.addView(Design.space(ctx, 8))
        note.addView(Design.cap(ctx,
            "按战报业务字段（battle_id / 双方 / 城池 / 坐标 / 时间 / 结果 / 武将串 / 战法串 / 红度 …）" +
            "生成 SHA-256 指纹：\n" +
            "• 指纹相同 = 一模一样 → 直接丢弃\n" +
            "• battle_id 相同但内容不同 → 记为更新，保留最新\n" +
            "• 上传时戳、日志、客户端版本等噪声字段不参与指纹"))
        root.addView(note)
        return root
    }

    private fun fmtSize(b: Long): String = when {
        b >= 1024 * 1024 -> "%.1f MB".format(b / 1024.0 / 1024.0)
        b >= 1024 -> "%.0f KB".format(b / 1024.0)
        else -> "$b B"
    }
}
