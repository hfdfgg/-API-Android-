package com.zsm.terminal

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import com.google.gson.Gson

/** 网站 WebView ↔ 原生：只镜像登录态/VIP，绝不把战报写回数据库 */
class JsBridge(
    private val settings: Settings,
    private val onOpenBattle: () -> Unit,
    private val onOpenVault: () -> Unit,
    private val onLog: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val gson = Gson()

    @JavascriptInterface
    fun onProfile(json: String) {
        main.post {
            try {
                val p = gson.fromJson(json, Profile::class.java) ?: return@post
                settings.profile = p
                AppState.profile(p)
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun openBattle() { main.post { onOpenBattle() } }

    @JavascriptInterface
    fun openVault() { main.post { onOpenVault() } }

    @JavascriptInterface
    fun log(msg: String) { main.post { onLog(msg) } }
}
