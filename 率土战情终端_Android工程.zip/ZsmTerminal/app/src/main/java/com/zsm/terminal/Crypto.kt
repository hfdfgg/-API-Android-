package com.zsm.terminal

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/** 账包原始字节用 AndroidKeyStore 的 AES-256-GCM 密钥加密，密钥不出硬件区。
 *  大文件走分块：每块 [4B长度][12B IV][密文]，末尾写 0 长度块，内存恒定 1MB。 */
object Crypto {
    private const val ALIAS = "zsm_vault_v2"
    private const val TRANS = "AES/GCM/NoPadding"
    private const val CHUNK = 1024 * 1024

    private fun key(): javax.crypto.SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val spec = KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            kg.init(spec); kg.generateKey()
        }
        return (ks.getEntry(ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    fun encrypt(plain: ByteArray): ByteArray {
        val c = Cipher.getInstance(TRANS); c.init(Cipher.ENCRYPT_MODE, key())
        return c.iv + c.doFinal(plain)
    }

    fun decrypt(blob: ByteArray): ByteArray {
        require(blob.size > 12) { "账包损坏" }
        val c = Cipher.getInstance(TRANS)
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
        return c.doFinal(blob.copyOfRange(12, blob.size))
    }

    /** @return Pair(原始字节数, sha256) */
    fun encryptStream(ins: InputStream, out: OutputStream): Pair<Long, String> {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(CHUNK)
        var total = 0L
        while (true) {
            var read = 0
            while (read < CHUNK) {
                val n = ins.read(buf, read, CHUNK - read)
                if (n < 0) break
                read += n
            }
            if (read == 0) break
            val plain = buf.copyOf(read)
            md.update(plain)
            val c = Cipher.getInstance(TRANS); c.init(Cipher.ENCRYPT_MODE, key())
            val iv = c.iv
            val ct = c.doFinal(plain)
            val len = 12 + ct.size
            out.write(byteArrayOf(
                ((len ushr 24) and 0xFF).toByte(), ((len ushr 16) and 0xFF).toByte(),
                ((len ushr 8) and 0xFF).toByte(), (len and 0xFF).toByte()
            ))
            out.write(iv); out.write(ct)
            total += read
            if (read < CHUNK) break
        }
        out.write(byteArrayOf(0, 0, 0, 0))       // 结束块
        return total to md.digest().joinToString("") { "%02x".format(it) }
    }

    fun decryptStream(ins: InputStream, out: OutputStream) {
        while (true) {
            val h = ByteArray(4)
            var got = 0
            while (got < 4) { val n = ins.read(h, got, 4 - got); if (n < 0) return; got += n }
            val len = ((h[0].toInt() and 0xFF) shl 24) or ((h[1].toInt() and 0xFF) shl 16) or
                ((h[2].toInt() and 0xFF) shl 8) or (h[3].toInt() and 0xFF)
            if (len <= 0) return
            val blob = ByteArray(len)
            var r = 0
            while (r < len) { val n = ins.read(blob, r, len - r); if (n < 0) return; r += n }
            val c = Cipher.getInstance(TRANS)
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
            out.write(c.doFinal(blob.copyOfRange(12, blob.size)))
        }
    }
}
