package com.zsm.terminal

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 同盟战报库读取：沿用网站现有的 Supabase 项目。
 * 优先 RPC get_my_battles(p_id, p_pin, p_limit)，失败退回 REST 表查询。
 * 返回的扁平行直接喂给 BattleDecoder.battleFrom()，和本地抓包用同一套字段适配。
 */
class SupabaseClient(private val url: String, private val key: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    private fun headers(b: Request.Builder) = b
        .header("apikey", key)
        .header("Authorization", "Bearer $key")
        .header("Content-Type", "application/json")
        .header("Prefer", "return=representation")

    private fun get(path: String): String? {
        val req = headers(Request.Builder().url(url.trimEnd('/') + path)).get().build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            return r.body?.string()
        }
    }

    private fun post(path: String, body: String): String? {
        val req = headers(Request.Builder().url(url.trimEnd('/') + path))
            .post(body.toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            return r.body?.string()
        }
    }

    fun fetchBattles(id: String, pin: String, table: String, limit: Int = 1000): List<Battle> {
        val out = ArrayList<Battle>()
        // 1) 网站同款 RPC
        if (id.isNotEmpty() && pin.isNotEmpty()) {
            val args = JSONObject().put("p_id", id).put("p_pin", pin).put("p_limit", limit).toString()
            val txt = post("/rest/v1/rpc/get_my_battles", args)
            if (txt != null) collect(txt, out, "云端同盟战报")
        }
        // 2) 同盟战报独立表（用户「全部上传到数据库」的场景）
        if (out.isEmpty() && table.isNotEmpty()) {
            val txt = get("/rest/v1/$table?select=*&limit=$limit")
            if (txt != null) collect(txt, out, "云端战报表")
        }
        return out
    }

    private fun collect(text: String, out: MutableList<Battle>, source: String) {
        try {
            val el = JsonParser.parseString(text)
            val arr: JsonArray? = when {
                el.isJsonArray -> el.asJsonArray
                el.isJsonObject && el.asJsonObject.has("data") && el.asJsonObject.get("data").isJsonArray ->
                    el.asJsonObject.getAsJsonArray("data")
                el.isJsonObject && el.asJsonObject.has("battles") && el.asJsonObject.get("battles").isJsonArray ->
                    el.asJsonObject.getAsJsonArray("battles")
                else -> null
            }
            arr ?: return
            arr.forEach { e ->
                if (!e.isJsonObject) return@forEach
                val o: JsonObject = e.asJsonObject
                val b = BattleDecoder.battleFrom(o) ?: return@forEach
                // payload 列里存原始战报 JSON 的情况
                if (b.atkUnits.isEmpty() && o.has("payload")) {
                    try {
                        val inner = JsonParser.parseString(o.get("payload").asString)
                        if (inner.isJsonObject) BattleDecoder.battleFrom(inner.asJsonObject)?.let { out.add(it.copy(source = source)); return@forEach }
                    } catch (ignored: Exception) { }
                }
                out.add(b.copy(source = source))
            }
        } catch (e: Exception) {
            // 解析失败由上层记日志
        }
    }
}
