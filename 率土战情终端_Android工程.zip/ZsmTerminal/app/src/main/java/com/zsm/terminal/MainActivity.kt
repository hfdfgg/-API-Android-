package com.zsm.terminal

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import java.lang.ref.WeakReference

/**
 * 主容器：
 *  - 「中枢」= 离线打包的完整网站（登录 / 音乐 / VIP / 签到 / 邮件 / 同盟 / 战报 / 考勤 / 导出 / 53 个 RPC）
 *  - 「战场 / 账包 / 设置」= 原生模块，战报数据全部来自本地账包，与网站解析链路独立
 */
class MainActivity : Activity(), AppState.Listener {

    companion object {
        const val ACTION_OPEN_BATTLE = "com.zsm.terminal.OPEN_BATTLE"
        const val ACTION_MUSIC = "com.zsm.terminal.MUSIC"
        const val ACTION_GO_VIP = "com.zsm.terminal.GO_VIP"
        private const val SITE_URL = "https://appassets.androidplatform.net/index.html"
        private const val REQ_IMPORT = 3001
        private const val REQ_BACKUP_IN = 3002
        private const val REQ_BACKUP_OUT = 3003
        private const val REQ_DEVICE = 3004
        private const val REQ_NOTIF = 3005
    }

    private lateinit var settings: Settings
    private lateinit var store: BattleStore
    private lateinit var vault: LocalVault
    private lateinit var repo: TeamRepository
    private lateinit var importer: PacketImporter
    private lateinit var web: WebView
    private lateinit var nativeHost: FrameLayout
    private lateinit var navBar: LinearLayout
    private val navItems = ArrayList<LinearLayout>()
    private var tab = 0
    private var pendingExport = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Design.density = resources.displayMetrics.density
        settings = Settings(this)
        store = BattleStore(this)
        vault = LocalVault(this, store)
        repo = TeamRepository(store)
        importer = PacketImporter(this, store, vault)
        TeamCardBus.attach(repo)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Design.BG)
        }
        val content = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(content)

        web = WebView(this).apply {
            setBackgroundColor(Design.BG)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        content.addView(web)
        nativeHost = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            visibility = View.GONE
        }
        content.addView(nativeHost)

        navBar = buildNav()
        root.addView(navBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Design.dp(this, 62)
        ))
        setContentView(root)

        setupWeb()
        AppState.bindWebView(web)
        AppState.register(this)
        AppState.status(repo.statsText())
        AppState.statsText = repo.statsText()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        // 常驻前台服务：悬浮球 / 实时接收 / 通知快捷入口 / 后台音乐保活
        send(CaptureService.ACTION_START)
        onNewIntent(intent)
        if (!settings.onboardDone) showOnboarding()
    }

    // ---------------------------------------------------------------- WebView
    private fun setupWeb() {
        val loader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                allowFileAccess = false
                allowContentAccess = false
                setGeolocationEnabled(false)
                userAgentString = userAgentString + " ZsmTerminal/2.0"
            }
            webChromeClient = object : WebChromeClient() { }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                    loader.shouldInterceptRequest(request.url)

                override fun onPageFinished(view: WebView, url: String) {
                    AppState.requestProfileSync()
                }

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val u = request.url
                    if (u.host == "appassets.androidplatform.net") return false
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) { }
                    return true
                }
            }
            addJavascriptInterface(
                JsBridge(settings,
                    onOpenBattle = { switchTab(1) },
                    onOpenVault = { switchTab(2) },
                    onLog = { AppState.log(it) }),
                "ZsmNative"
            )
        }
        web.loadUrl(SITE_URL)
    }

    // ---------------------------------------------------------------- 底部导航
    private fun buildNav(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Design.SURFACE)
            setPadding(Design.dp(this@MainActivity, 6), 0, Design.dp(this@MainActivity, 6), 0)
            elevation = Design.dp(this@MainActivity, 8).toFloat()
        }
        val items = listOf(
            Triple("中枢", R.drawable.ic_center, 0),
            Triple("战场", R.drawable.ic_battle, 1),
            Triple("账包", R.drawable.ic_vault, 2),
            Triple("设置", R.drawable.ic_settings, 3)
        )
        items.forEach { (label, icon, idx) ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(Design.dp(this@MainActivity, 4), Design.dp(this@MainActivity, 8),
                    Design.dp(this@MainActivity, 4), Design.dp(this@MainActivity, 6))
                isClickable = true
                setOnClickListener { switchTab(idx) }
            }
            val line = View(this).apply {
                background = Design.bg(Design.PRIMARY, 2)
                layoutParams = LinearLayout.LayoutParams(Design.dp(this@MainActivity, 26),
                    Design.dp(this@MainActivity, 3))
            }
            cell.addView(line)
            val iv = Design.icon(this, icon, Design.MUTED, 22)
            iv.setPadding(0, Design.dp(this@MainActivity, 5), 0, Design.dp(this@MainActivity, 3))
            cell.addView(iv)
            val tv = Design.cap(this, label)
            cell.addView(tv)
            bar.addView(cell, LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            navItems.add(cell)
        }
        paintNav()
        return bar
    }

    private fun paintNav() {
        navItems.forEachIndexed { i, cell ->
            val on = i == tab
            val iv = cell.getChildAt(1)
            val tv = cell.getChildAt(2)
            if (iv is android.widget.ImageView) iv.setColorFilter(if (on) Design.CYAN else Design.MUTED)
            if (tv is android.widget.TextView) tv.setTextColor(if (on) Design.CYAN else Design.MUTED)
            cell.getChildAt(0).alpha = if (on) 1f else 0f
            cell.background = if (on) Design.bg(Design.SURFACE2, 12) else null
        }
    }

    fun switchTab(idx: Int) {
        tab = idx
        paintNav()
        if (idx == 0) {
            web.visibility = View.VISIBLE
            nativeHost.visibility = View.GONE
            AppState.requestProfileSync()
            return
        }
        web.visibility = View.GONE
        nativeHost.visibility = View.VISIBLE
        nativeHost.removeAllViews()
        val v = when (idx) {
            1 -> BattleCenterView.build(this, repo, settings,
                onImport = { openImport() },
                onVip = { goVip() },
                onCard = { n -> TeamCardDialog.show(this, repo.card(n), ::refreshCurrent) })
            2 -> VaultView.build(this, store, vault,
                onImport = { openImport() },
                onBackupOut = { requestDeviceThenExport() },
                onBackupIn = { openBackupIn() },
                onClear = { confirmClear() })
            else -> SettingsView.build(this, settings, vault,
                onOverlay = { on -> if (on) ensureOverlay() else send(CaptureService.ACTION_HIDE_OVERLAY) },
                onSync = { AppState.requestProfileSync(); toast("已向网站请求同步 VIP / 登录态") },
                onMusic = { play -> AppState.music(play) })
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(Design.BG)
            isFillViewport = true
            addView(v, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        nativeHost.addView(sv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
    }

    private fun refreshCurrent() { if (tab != 0) switchTab(tab) }

    fun goVip() {
        switchTab(0)
        web.post {
            web.evaluateJavascript(
                "(function(){try{if(typeof switchTab==='function')switchTab('vip');" +
                    "else if(typeof goVip==='function')goVip();}catch(e){}})()", null
            )
        }
        toast("VIP 专属：开通后解锁悬浮队伍情报")
    }

    fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- 悬浮窗
    private fun ensureOverlay() {
        if (!OverlayManager.canDraw(this)) {
            toast("请先授权悬浮窗")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
            return
        }
        if (!settings.isVip()) {
            toast("悬浮队伍情报是 VIP 功能")
            goVip(); return
        }
        send(CaptureService.ACTION_SHOW_OVERLAY)
    }

    // ---------------------------------------------------------------- 导入 / 备份
    fun openImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream", "application/zip", "application/json",
                "text/plain", "application/gzip", "*/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_IMPORT)
    }

    private fun openBackupIn() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_BACKUP_IN)
    }

    private fun requestDeviceThenExport() {
        if (!vault.isDeviceSecure()) { doExportBackup(); return }
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val it = km.createConfirmDeviceCredentialIntent("验证身份", "导出本地账包备份需要设备凭据")
        if (it == null) { doExportBackup(); return }
        pendingExport = true
        @Suppress("DEPRECATION")
        startActivityForResult(it, REQ_DEVICE)
    }

    private fun doExportBackup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "率土战情_本地账包备份.zip")
        }
        startActivityForResult(i, REQ_BACKUP_OUT)
    }

    private fun confirmClear() {
        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("清空本地账包")
            .setMessage("将删除全部本地战报、分组、收藏与加密原始包。网站云端账号/VIP 不受影响。")
            .setPositiveButton("确认清空") { _, _ ->
                vault.clearAll()
                AppState.status("已清空：" + repo.statsText())
                AppState.imported(ImportReport(message = "已清空本地账包"))
                refreshCurrent()
            }
            .setNegativeButton("取消", null).show()
    }

    // ---------------------------------------------------------------- 结果
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        when (req) {
            REQ_DEVICE -> { if (pendingExport) { pendingExport = false; doExportBackup() }; return }
            REQ_IMPORT -> {
                val uri = data?.data ?: return
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (e: Exception) { }
                importInBackground(uri)
            }
            REQ_BACKUP_IN -> {
                val uri = data?.data ?: return
                Thread {
                    val r = vault.importBackup(uri)
                    runOnUiThread { onImported(r) }
                }.apply { isDaemon = true; start() }
            }
            REQ_BACKUP_OUT -> {
                val uri = data?.data ?: return
                Thread {
                    try {
                        contentResolver.openOutputStream(uri)?.use { os ->
                            // FileOutputStream 才可用 ZipOutputStream 重载；用临时文件再拷
                            val tmp = java.io.File(cacheDir, "backup_tmp.zip")
                            java.io.FileOutputStream(tmp).use { fos -> vault.exportBackup(fos) }
                            tmp.inputStream().use { it.copyTo(os) }
                            tmp.delete()
                        }
                        runOnUiThread { toast("备份已导出到本地"); AppState.log("账包备份导出完成") }
                    } catch (e: Exception) {
                        runOnUiThread { toast("导出失败：" + e.message) }
                    }
                }.apply { isDaemon = true; start() }
            }
        }
    }

    private fun importInBackground(uri: Uri) {
        val name = try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else "同盟战报包"
            } ?: "同盟战报包"
        } catch (e: Exception) { "同盟战报包" }
        toast("正在解析「$name」…")
        AppState.log("开始导入：$name")
        Thread {
            val r = try { importer.importUri(uri, name) }
                catch (e: Exception) { ImportReport(name, message = "导入失败：" + e.message) }
            runOnUiThread { onImported(r) }
        }.apply { isDaemon = true; start() }
    }

    // ---------------------------------------------------------------- Intent
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        when (intent?.action) {
            ACTION_OPEN_BATTLE -> switchTab(1)
            ACTION_MUSIC -> { switchTab(0); AppState.music(true) }
            ACTION_GO_VIP -> goVip()
            Intent.ACTION_SEND -> {
                val u = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (u != null) importInBackground(u)
            }
        }
    }

    // ---------------------------------------------------------------- AppState
    override fun onStatus(msg: String) { runOnUiThread { AppState.statsText = msg } }
    override fun onLog(msg: String) { runOnUiThread { SettingsView.appendRuntimeLog(msg) } }
    override fun onProfile(p: Profile) {
        AppState.log("账号同步：" + (p.nickname.ifEmpty { p.id }) +
            if (p.vip) " · VIP" else " · 普通")
    }
    override fun onImported(r: ImportReport) {
        AppState.status(r.message + " · " + repo.statsText())
        AppState.log(r.message)
        toast(r.message)
        refreshCurrent()
    }

    override fun onDestroy() {
        AppState.unregister(this)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (tab == 0 && web.canGoBack()) { web.goBack(); return }
        if (tab != 0) { switchTab(0); return }
        super.onBackPressed()
    }

    private fun send(action: String) {
        val i = Intent(this, CaptureService::class.java).apply { this.action = action }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun showOnboarding() {
        Onboarding.show(this) {
            settings.onboardDone = true
            if (!OverlayManager.canDraw(this)) {
                toast("提示：在「设置」里开启悬浮窗即可使用 VIP 队伍情报")
            }
        }
    }
}
