package com.zsm.terminal

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), AppState.Listener {

    private lateinit var settings: Settings
    private lateinit var status: TextView
    private lateinit var logBox: TextView
    private val logs = StringBuilder()
    private var etPort: EditText? = null
    private var etId: EditText? = null
    private var etPin: EditText? = null
    private var etTable: EditText? = null
    private var etUrl: EditText? = null
    private var etKey: EditText? = null
    private var etAlliance: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        title = "率土战情终端"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F4F6FB"))
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 14),
                Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 24))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        root.addView(Ui.tv(this, "率土战情终端", 22f, Color.parseColor("#111827"), true))
        root.addView(Ui.tv(this, "PCAPdroid → 本机解析 → 悬浮队伍情报", 12f,
            Color.parseColor("#64748B")))

        status = Ui.tv(this, "尚未解析", 13f, Color.parseColor("#0C4A6E"), true).apply {
            background = Ui.roundBg(Color.parseColor("#E0F2FE"), Ui.dp(this@MainActivity, 12).toFloat())
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 10),
                Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 10))
        }
        root.addView(status, space(10))

        // ---- 权限 ----
        root.addView(section("① 权限"))
        root.addView(Ui.button(this, "授权悬浮窗（弹队伍卡必须）", Color.parseColor("#6366F1"), Color.WHITE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else toast("当前系统无需授权")
        }, space(6))
        root.addView(Ui.tv(this, "通知权限用于前台服务常驻；不授权不影响解析。", 11f,
            Color.parseColor("#64748B")))

        // ---- 数据入口 ----
        root.addView(section("② 抓包数据入口"))
        val r1 = Ui.row(this)
        r1.addView(Ui.button(this, "启动接收服务", Color.parseColor("#06B6D4"), Color.WHITE) {
            send(CaptureService.ACTION_START); toast("已启动 TCP 监听，去 PCAPdroid 选「TCP 导出器」")
        }, w(1f, 6))
        r1.addView(Ui.button(this, "停止", Color.parseColor("#94A3B8"), Color.WHITE) {
            send(CaptureService.ACTION_STOP)
        }, w(0.6f, 0))
        root.addView(r1, space(6))
        root.addView(Ui.button(this, "导入 .pcap / .pcapng / .gz 文件", Color.parseColor("#10B981"), Color.WHITE) {
            openFile()
        }, space(6))
        root.addView(Ui.tv(this, "PCAPdroid → 设置 → 流量转储：可选「TCP 导出器」实时流，或「PCAP 文件」落盘后在这里导入。",
            11f, Color.parseColor("#64748B")))

        // ---- 悬浮层 ----
        root.addView(section("③ 队伍情报浮层"))
        val r2 = Ui.row(this)
        r2.addView(Ui.button(this, "显示悬浮球", Color.parseColor("#6366F1"), Color.WHITE) {
            send(CaptureService.ACTION_SHOW_OVERLAY)
        }, w(1f, 6))
        r2.addView(Ui.button(this, "关闭", Color.parseColor("#94A3B8"), Color.WHITE) {
            send(CaptureService.ACTION_HIDE_OVERLAY)
        }, w(0.6f, 0))
        root.addView(r2, space(6))
        root.addView(Ui.tv(this, "在游戏里点悬浮球 → 队伍列表 → 点「知夏丨江东」即弹出武将 / 战法 / 分组 / 城池。",
            11f, Color.parseColor("#64748B")))

        // ---- 同盟战报库 ----
        root.addView(section("④ 同盟战报库（云端）"))
        root.addView(Ui.button(this, "同步同盟战报", Color.parseColor("#FBBF24"), Color.parseColor("#111827")) {
            saveSettings(); send(CaptureService.ACTION_SYNC)
        }, space(6))
        root.addView(Ui.tv(this, "复用网站现有 Supabase：优先 RPC get_my_battles(id, pin)，失败退回战报表。填网站账号 id 与 pin。",
            11f, Color.parseColor("#64748B")))

        // ---- 设置 ----
        root.addView(section("⑤ 设置"))
        etPort = field(root, "TCP 监听端口", settings.port.toString(), InputType.TYPE_CLASS_NUMBER)
        etId = field(root, "网站账号 id", settings.userId)
        etPin = field(root, "pin / token", settings.pin)
        etTable = field(root, "战报表名（备用）", settings.table)
        etUrl = field(root, "Supabase URL", settings.sbUrl)
        etKey = field(root, "Supabase publishable key", settings.sbKey)
        etAlliance = field(root, "同盟名字（显示用）", settings.allianceName)
        root.addView(Ui.button(this, "保存设置", Color.parseColor("#111827"), Color.WHITE) {
            saveSettings(); toast("已保存")
        }, space(6))
        root.addView(Ui.button(this, "清空本地解析结果", Color.parseColor("#EF4444"), Color.WHITE) {
            send(CaptureService.ACTION_CLEAR)
        }, space(6))

        // ---- 日志 ----
        root.addView(section("运行日志"))
        logBox = Ui.tv(this, "等待操作…", 11f, Color.parseColor("#334155")).apply {
            background = Ui.roundBg(Color.parseColor("#FFFFFF"), Ui.dp(this@MainActivity, 10).toFloat())
            setPadding(Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 10),
                Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 10))
        }
        root.addView(logBox)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun field(root: LinearLayout, label: String, value: String, input: Int = InputType.TYPE_CLASS_TEXT): EditText {
        root.addView(Ui.label(this, label), space(6))
        val et = EditText(this).apply {
            setText(value)
            textSize = 13f
            inputType = input
            background = Ui.roundBg(Color.WHITE, Ui.dp(this@MainActivity, 10).toFloat(), 1,
                Color.parseColor("#CBD5E1"))
            setPadding(Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 9),
                Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 9))
        }
        root.addView(et, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return et
    }

    private fun section(t: String): TextView = Ui.tv(this, t, 15f, Color.parseColor("#111827"), true).apply {
        background = Ui.roundBg(Color.WHITE, Ui.dp(this@MainActivity, 12).toFloat())
        setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 10),
            Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 10))
    }

    private fun space(v: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = Ui.dp(this@MainActivity, v) }

    private fun w(weight: Float, margin: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight).apply {
            rightMargin = Ui.dp(this@MainActivity, margin)
        }

    private fun saveSettings() {
        etPort?.text?.toString()?.trim()?.toIntOrNull()?.let { if (it in 1..65535) settings.port = it }
        etId?.let { settings.userId = it.text.toString().trim() }
        etPin?.let { settings.pin = it.text.toString().trim() }
        etTable?.let { settings.table = it.text.toString().trim() }
        etUrl?.let { settings.sbUrl = it.text.toString().trim() }
        etKey?.let { settings.sbKey = it.text.toString().trim() }
        etAlliance?.let { settings.allianceName = it.text.toString().trim() }
    }

    private fun send(action: String, uri: Uri? = null) {
        saveSettings()
        val i = Intent(this, CaptureService::class.java).apply {
            this.action = action
            if (uri != null) {
                data = uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun openFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, 2001)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
            send(CaptureService.ACTION_FILE, uri)
            toast("已开始解析抓包文件")
        }
    }

    override fun onResume() {
        super.onResume()
        AppState.register(this)
        onUpdate(AppState.lastMessage)
        val ok = OverlayManager(this).canDraw()
        appendLog(if (ok) "悬浮窗权限：已授权" else "悬浮窗权限：未授权")
    }

    override fun onPause() { AppState.unregister(this); super.onPause() }

    override fun onUpdate(msg: String) {
        runOnUiThread {
            status.text = msg + "\n" + if (AppState.serviceRunning) "服务：运行中" else "服务：未启动"
        }
    }

    override fun onLog(msg: String) { runOnUiThread { appendLog(msg) } }

    private fun appendLog(msg: String) {
        logs.insert(0, "• $msg\n")
        if (logs.length > 4000) logs.setLength(4000)
        logBox.text = logs.toString()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
