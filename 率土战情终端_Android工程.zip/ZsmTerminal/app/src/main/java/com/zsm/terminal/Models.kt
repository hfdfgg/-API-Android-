package com.zsm.terminal

data class SkillInfo(val skillId: Long = 0L, val level: Int = 0, val slot: Int = 0)

data class HeroUnit(
    val slot: Int = 0,
    val heroId: Long = 0L,
    val level: Int = 0,
    val maxHp: Int = 0,
    val remainHp: Int = 0,
    val wounded: Int = 0,
    val dead: Int = 0,
    val loss: Int = 0,
    var advance: Int = 0,
    val skills: MutableList<SkillInfo> = mutableListOf()
)

/** def 是 Kotlin 关键字，守方统一命名为 defName */
data class Battle(
    val id: String = "",
    val time: Long = 0L,
    val city: String = "",
    val x: Int = 0,
    val y: Int = 0,
    val atk: String = "",
    val defName: String = "",
    val atkUnion: String = "",
    val defUnion: String = "",
    val result: Int = 0,
    val atkUnits: MutableList<HeroUnit> = mutableListOf(),
    val defUnits: MutableList<HeroUnit> = mutableListOf(),
    val atkLoss: Int = 0,
    val defLoss: Int = 0,
    val source: String = "本地抓包"
)

data class Member(
    val roleId: Long = 0L,
    val name: String = "",
    val groupId: Int = 0,
    val group: String = "",
    val power: Int = 0
)

data class Intel(
    var serverCode: String = "",
    var serverId: String = "",
    var allianceId: String = "",
    var allianceName: String = "",
    var channel: String = "",
    var token: String = "",
    var gameServer: String = "",
    val dns: MutableList<String> = mutableListOf()
)

data class DecodeResult(
    val battles: MutableList<Battle> = mutableListOf(),
    val members: MutableList<Member> = mutableListOf(),
    val groupByName: MutableMap<String, String> = mutableMapOf(),
    val groupByRoleId: MutableMap<Long, String> = mutableMapOf(),
    val groupCount: MutableMap<String, Int> = mutableMapOf(),
    val names: MutableSet<String> = mutableSetOf(),
    val cities: MutableSet<String> = mutableSetOf(),
    val intel: Intel = Intel(),
    var packets: Int = 0,
    var jsonBlocks: Int = 0
)

data class TeamCard(
    val name: String,
    val group: String,
    val groupId: Int,
    val city: String,
    val x: Int,
    val y: Int,
    val union: String,
    val server: String,
    val side: String,
    val result: Int,
    val units: List<HeroUnit>,
    val battle: Battle?,
    val source: String
)
