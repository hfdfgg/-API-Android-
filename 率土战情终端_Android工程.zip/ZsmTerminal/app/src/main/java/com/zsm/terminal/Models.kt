package com.zsm.terminal

/** 旧解析内核仍用这些模型，v2 全部保留 */
data class SkillInfo(val skillId: Long = 0L, val level: Int = 0, val slot: Int = 0)

data class HeroUnit(
    val slot: Int = 0, val heroId: Long = 0L, val level: Int = 0,
    val maxHp: Int = 0, val remainHp: Int = 0, val wounded: Int = 0,
    val dead: Int = 0, val loss: Int = 0, var advance: Int = 0,
    val skills: MutableList<SkillInfo> = mutableListOf()
)

data class Battle(
    val id: String = "", val time: Long = 0L, val city: String = "",
    val x: Int = 0, val y: Int = 0, val atk: String = "", val defName: String = "",
    val atkUnion: String = "", val defUnion: String = "", val result: Int = 0,
    val atkUnits: MutableList<HeroUnit> = mutableListOf(),
    val defUnits: MutableList<HeroUnit> = mutableListOf(),
    val atkLoss: Int = 0, val defLoss: Int = 0, val source: String = "本地账包"
)

data class Member(val roleId: Long = 0L, val name: String = "",
                  val groupId: Int = 0, val group: String = "", val power: Int = 0)

data class Intel(
    var serverCode: String = "", var serverId: String = "", var allianceId: String = "",
    var allianceName: String = "", var channel: String = "", var token: String = "",
    var gameServer: String = "", val dns: MutableList<String> = mutableListOf()
)

data class DecodeResult(
    val battles: MutableList<Battle> = mutableListOf(),
    val members: MutableList<Member> = mutableListOf(),
    val groupByName: MutableMap<String, String> = mutableMapOf(),
    val groupByRoleId: MutableMap<Long, String> = mutableMapOf(),
    val groupCount: MutableMap<String, Int> = mutableMapOf(),
    val names: MutableSet<String> = mutableSetOf(),
    val cities: MutableSet<String> = mutableSetOf(),
    val intel: Intel = Intel(), var packets: Int = 0, var jsonBlocks: Int = 0
)

/** 队伍卡：悬浮窗 / 战场中心共用 */
data class TeamCard(
    val name: String, val group: String, val groupId: Int,
    val city: String, val x: Int, val y: Int, val union: String,
    val server: String, val side: String, val result: Int,
    val units: List<HeroUnit>, val battle: Battle?,
    val battles: Int, val wins: Int, val cities: List<String>,
    val note: String, val favorite: Boolean, val source: String
)

/** 导入一个「同盟战报包」的结果 */
data class ImportReport(
    val packetName: String = "", val kind: String = "", val bytes: Long = 0L,
    val added: Int = 0, val duplicate: Int = 0, val updated: Int = 0,
    val groups: Int = 0, val players: Int = 0, val jsonBlocks: Int = 0,
    val message: String = ""
)

data class PacketInfo(
    val id: String, val name: String, val size: Long, val addedAt: Long,
    val kind: String, val battles: Int, val duplicate: Int, val updated: Int, val sha: String
)

data class Profile(
    val id: String = "", val pin: String = "", val coins: Int = 0,
    val vip: Boolean = false, val vipExpire: String = "",
    val nickname: String = "", val forceName: String = "", val alliance: String = ""
)

data class PlayerHit(val name: String, val count: Int, val group: String, val lastTime: Long)
