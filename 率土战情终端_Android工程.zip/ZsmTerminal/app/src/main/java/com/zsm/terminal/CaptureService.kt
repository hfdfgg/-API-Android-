package com.zsm.terminal

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.ByteArrayOutputStream
import java.net.ServerSocket
import java.net.Socket

/**
 * 前台常驻服务：
 *  - PCAPdroid「TCP 导出器」实时流 → 本地解析 → 去重入本机账包
 *  - 文件导入 / 悬浮窗开关 / 通知快捷入口 / 后台音乐保活
 * 全部数据落本地，不写回任何数据库。
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.zsm.terminal.START"
        const val ACTION_STOP = "com.zsm.terminal.STOP"
        const val ACTION_SHOW_OVERLAY = "com.zsm.terminal.SHOW_OVERLAY"
        const val ACTION_HIDE_OVERLAY = "com.zsm.terminal.HIDE_OVERLAY"
        const val ACTION_IMPORT = "com.zsm.terminal.IMPORT"
        const val ACTION_SYNC = "com.zsm.terminal.SYNC"
        const val ACTION_MUSIC = "com.zsm.terminal.MUSIC"
        const val ACTION_CLEAR = "com.zsm.terminal.CLEAR"
        private const val NOTI_ID = 1
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var settings: Settings
    private lateinit var store: BattleStore
    private lateinit var vault: LocalVault
    private lateinit var repo: TeamRepository
    private lateinit var importer: PacketImporter
    private lateinit var overlay: OverlayManager
    private var server: ServerSocket? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        Design.density = resources.displayMetrics.density
        settings = Settings(this)
        store = BattleStore(this)
        vault = LocalVault(this, store)
        repo = TeamRepository(store)
        importer = PacketImporter(this, store, vault)
        overlay = OverlayManager(this, repo, settings)
        startForeground(NOTI_ID, noti("战情终端已就绪 · " + repo.statsText()))
        AppState.serviceRunning = true
    }

    private fun noti(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).apply { action = MainActivity.ACTION_OPEN_BATTLE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val music = PendingIntent.getService(this, 1,
            Intent(this, CaptureService::class.java).apply { action = ACTION_MUSIC },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, ZsmApp.CHANNEL_ID)
        else Notification.Builder(this)
        return b.setSmallIcon(R.drawable.ic_shield)
            .setContentTitle("率土战情终端")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_play, "音乐", music)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startServer()
            ACTION_STOP -> { stopAll(); stopSelf() }
            ACTION_SHOW_OVERLAY -> overlay.show()
            ACTION_HIDE_OVERLAY -> overlay.hide()
            ACTION_IMPORT -> intent.data?.let { importUri(it) }
            ACTION_SYNC -> AppState.requestProfileSync()
            ACTION_MUSIC -> { AppState.music(settings.musicWanted); settings.musicWanted = !settings.musicWanted }
            ACTION_CLEAR -> {
                vault.clearAll()
                AppState.status("已清空本地账包 · " + repo.statsText())
                AppState.imported(ImportReport(message = "已清空本地账包"))
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startServer() {
        if (running) return
        running = true
        val port = settings.port
        Thread {
            try {
                val ss = ServerSocket(port).apply { reuseAddress = true }
                server = ss
                AppState.log("TCP 监听 0.0.0.0:$port（PCAPdroid 填 手机IP:$port）")
                while (running) {
                    val c = ss.accept()
                    Thread { handleClient(c) }.apply { isDaemon = true; start() }
                }
            } catch (e: Exception) {
                if (running) AppState.log("监听异常：" + e.message)
            }
        }.apply { isDaemon = true; start() }
        AppState.status("服务运行中 · 端口 $port · " + repo.statsText())
    }

    /** 实时流：边收边解析，断开后一次性去重入本地账包 */
    private fun handleClient(socket: Socket) {
        val texts = ArrayList<String>()
        val pipeline = ZlibScan.Pipeline { t -> texts.add(t) }
        lateinit var feeder: PcapParser.Feeder
        feeder = PcapParser.Feeder { pkt ->
            val seg = PcapParser.takeTcp(pkt, PcapParser.ipOffset(feeder.linktype()))
            if (seg != null) pipeline.add(seg)
        }
        try {
            socket.use { c ->
                val buf = ByteArray(64 * 1024)
                val ins = c.getInputStream()
                while (running) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    feeder.feed(buf, 0, n)
                }
            }
        } catch (e: Exception) {
            AppState.log("连接断开：" + e.message)
        }
        feeder.flush()
        pipeline.finish()
        if (texts.isNotEmpty()) {
            val name = "实时流_" + java.text.SimpleDateFormat("HHmmss", java.util.Locale.CHINA)
                .format(java.util.Date())
            val r = importer.importTexts(texts, name)
            main.post {
                AppState.status(r.message + " · " + repo.statsText())
                AppState.log(r.message + "（共 " + feeder.packetCount + " 包）")
                AppState.imported(r)
                overlay.refresh()
            }
        }
    }

    private fun importUri(uri: Uri) {
        Thread {
            val r = try { importer.importUri(uri, "外部导入") }
                catch (e: Exception) { ImportReport(message = "导入失败：" + e.message) }
            main.post { AppState.imported(r) }
        }.apply { isDaemon = true; start() }
    }

    private fun stopAll() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        server = null
        overlay.hide()
        AppState.serviceRunning = false
        AppState.status("服务已停止")
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }
}
