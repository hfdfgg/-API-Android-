package com.zsm.terminal

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections

/**
 * 前台服务：
 *  - TCP 监听（PCAPdroid「TCP 导出器 / pcap-over-ip」实时流）
 *  - 文件导入（PCAPdroid「PCAP 文件」转储，流式读，274MB 也不 OOM）
 *  - 解析结果 → TeamRepository → 悬浮层队伍列表 + 主界面状态
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.zsm.terminal.START"
        const val ACTION_STOP = "com.zsm.terminal.STOP"
        const val ACTION_FILE = "com.zsm.terminal.FILE"
        const val ACTION_SHOW_OVERLAY = "com.zsm.terminal.SHOW_OVERLAY"
        const val ACTION_HIDE_OVERLAY = "com.zsm.terminal.HIDE_OVERLAY"
        const val ACTION_SYNC = "com.zsm.terminal.SYNC"
        const val ACTION_CLEAR = "com.zsm.terminal.CLEAR"
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var settings: Settings
    private lateinit var repo: TeamRepository
    private lateinit var overlay: OverlayManager
    private var server: ServerSocket? = null
    private var serverThread: Thread? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        settings = Settings(this)
        repo = TeamRepository(this, settings)
        overlay = OverlayManager(this)
        overlay.attach(repo)
        startForeground(1, buildNotification("正在接收 PCAPdroid 抓包数据"))
        AppState.serviceRunning = true
    }

    private fun buildNotification(text: String): Notification {
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, ZsmApp.CHANNEL_ID)
        else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("率土战情终端")
            .setContentText(text)
            .setOngoing(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startServer()
            ACTION_STOP -> { stopAll(); stopSelf() }
            ACTION_FILE -> intent.data?.let { parseFile(it) }
            ACTION_SHOW_OVERLAY -> {
                if (overlay.canDraw()) { overlay.show(); AppState.overlayOn = true; log("悬浮球已开启") }
                else log("未授权悬浮窗权限")
            }
            ACTION_HIDE_OVERLAY -> { overlay.hide(); AppState.overlayOn = false; log("悬浮球已关闭") }
            ACTION_SYNC -> syncCloud()
            ACTION_CLEAR -> { repo.clear(); overlay.refreshPanel(); AppState.emitUpdate("已清空本地解析结果") }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun log(msg: String) {
        AppState.emitLog(msg)
    }

    // ---------------- 会话：每个 TCP 连接 / 每个文件独立 ----------------
    private inner class Session {
        val pending: MutableList<String> = Collections.synchronizedList(mutableListOf())
        @Volatile var scheduled = false
        lateinit var pipeline: ZlibScan.Pipeline
        lateinit var feeder: PcapParser.Feeder

        init {
            pipeline = ZlibScan.Pipeline { t -> onJson(this, t) }
            feeder = PcapParser.Feeder { pkt -> onPacket(this, pkt) }
        }
    }

    private fun onPacket(s: Session, pkt: ByteArray) {
        val seg = PcapParser.takeTcp(pkt, PcapParser.ipOffset(s.feeder.linktype())) ?: return
        s.pipeline.add(seg)
    }

    private fun onJson(s: Session, text: String) {
        s.pending.add(text)
        if (s.pending.size >= 6) {
            handler.post { flush(s, false) }
        } else if (!s.scheduled) {
            s.scheduled = true
            handler.postDelayed({ s.scheduled = false; flush(s, false) }, 700)
        }
    }

    private fun flush(s: Session, final: Boolean) {
        val texts = synchronized(s.pending) {
            val c = s.pending.toList(); s.pending.clear(); c
        }
        if (texts.isEmpty() && !final) return
        val packets = s.pipeline.packets
        Thread {
            val r = DecodeResult()
            texts.forEach { r.jsonBlocks++; BattleDecoder.decodeText(it, r) }
            r.packets = packets
            handler.post {
                repo.merge(r)
                AppState.lastResult = repo.result
                val msg = "${repo.stats()} · 本批 ${r.battles.size} 战报 / ${r.groupByName.size} 分组"
                AppState.emitUpdate(msg)
                overlay.refreshPanel()
            }
        }.apply { isDaemon = true; start() }
    }

    // ---------------- TCP 实时流 ----------------
    private fun startServer() {
        if (running) { log("接收服务已在运行"); return }
        running = true
        val port = settings.port
        serverThread = Thread {
            try {
                val ss = ServerSocket(port).apply { reuseAddress = true }
                server = ss
                log("TCP 监听 0.0.0.0:$port ｜ PCAPdroid 填 手机IP:$port")
                while (running) {
                    val c = ss.accept()
                    Thread { handleClient(c) }.apply { isDaemon = true; start() }
                }
            } catch (e: Exception) {
                if (running) log("监听异常：${e.message}")
            }
        }.apply { isDaemon = true; start() }
        AppState.emitUpdate("接收服务运行中 · 端口 $port")
    }

    private fun handleClient(socket: Socket) {
        val s = Session()
        try {
            socket.use { c ->
                c.soTimeout = 0
                val ins = c.getInputStream()
                log("PCAPdroid 已连接：${c.inetAddress.hostAddress}")
                val buf = ByteArray(64 * 1024)
                while (running) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    s.feeder.feed(buf, 0, n)
                }
                s.feeder.flush()
                s.pipeline.finish()
            }
        } catch (e: Exception) {
            log("连接断开：${e.message}")
        } finally {
            handler.post { flush(s, true); log("本连接解析完成，共 ${s.feeder.packetCount} 包") }
        }
    }

    // ---------------- 文件导入 ----------------
    private fun parseFile(uri: Uri) {
        Thread {
            val s = Session()
            try {
                log("开始导入抓包文件…")
                contentResolver.openInputStream(uri)?.use { ins ->
                    PcapParser.parseFile(ins, s.feeder)
                }
                s.pipeline.finish()
                handler.post {
                    flush(s, true)
                    log("文件解析完成，共 ${s.feeder.packetCount} 包")
                }
            } catch (e: Exception) {
                log("文件解析失败：${e.message}")
            }
        }.apply { isDaemon = true; start() }
    }

    // ---------------- 云端同盟战报 ----------------
    private fun syncCloud() {
        Thread {
            log("正在同步同盟战报库…")
            val n = try { repo.pullCloud() } catch (e: Exception) { 0 }
            handler.post {
                log(if (n > 0) "已同步 $n 条云端战报" else "云端未取到数据（检查账号 id / pin 或表名）")
                AppState.lastResult = repo.result
                AppState.emitUpdate(repo.stats())
                overlay.refreshPanel()
            }
        }.apply { isDaemon = true; start() }
    }

    private fun stopAll() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        server = null
        AppState.serviceRunning = false
        AppState.emitUpdate("接收服务已停止")
    }

    override fun onDestroy() {
        stopAll()
        overlay.hide()
        AppState.overlayOn = false
        super.onDestroy()
    }
}
