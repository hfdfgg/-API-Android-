package com.zsm.terminal

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 战场功能的读模型：全部来自本地账包，和网站那套解析/上传完全独立 */
class TeamRepository(private val store: BattleStore) {

    fun search(q: String): List<PlayerHit> {
        val trimmed = q.trim()
        if (trimmed.isEmpty()) return store.recentPlayers(30)
        val direct = store.search(trimmed, 40).toMutableList()
        // 模糊：按前缀名再捞一次（「知夏」→「知夏丨江东」）
        val base = Names.baseName(trimmed)
        if (base.isNotEmpty() && base != trimmed) {
            store.search(base, 40).forEach { h ->
                if (direct.none { it.name == h.name }) direct.add(h)
            }
        }
        return direct.sortedWith(compareByDescending<PlayerHit> { it.count }.thenBy { it.name }).take(40)
    }

    fun favorites(): List<PlayerHit> = store.favorites().map {
        PlayerHit(it, 0, store.groupOf(it), 0L)
    }

    fun history(): List<PlayerHit> = store.history().map {
        PlayerHit(it, 0, store.groupOf(it), 0L)
    }

    fun card(name: String): TeamCard {
        store.recordHistory(name)
        val bs = store.battlesOf(name)
        val base = Names.baseName(name)
        val group = store.groupOf(name)
        val gid = Names.gidOf(group)
        val b = bs.firstOrNull()
        val side = if (b == null) "" else
            if (b.atk == name || b.atk == base || Names.baseName(b.atk) == base) "攻方" else "守方"
        val units = when { b == null -> emptyList(); side == "攻方" -> b.atkUnits; else -> b.defUnits }
        val wins = bs.count {
            val win = it.result == 1
            val isAtk = it.atk == name || it.atk == base || Names.baseName(it.atk) == base
            (isAtk && win) || (!isAtk && !win && it.result == 0)
        }
        val cities = bs.map { it.city }.filter { it.isNotEmpty() && it != "未知地点" }.distinct().take(6)
        return TeamCard(
            name = name, group = group, groupId = gid,
            city = b?.city ?: "", x = b?.x ?: 0, y = b?.y ?: 0,
            union = if (side == "攻方") b?.atkUnion ?: "" else b?.defUnion ?: "",
            server = store.intel("serverCode").ifEmpty { store.intel("serverId") },
            side = side, result = b?.result ?: -1, units = units, battle = b,
            battles = bs.size, wins = wins, cities = cities,
            note = store.note(name), favorite = store.favorite(name),
            source = b?.source ?: "本地同盟战报包"
        )
    }

    fun toggleFavorite(name: String) = store.toggleFavorite(name)
    fun setNote(name: String, note: String) = store.setNote(name, note)

    fun statsText(): String {
        val c = store.counts()
        return "战报 ${c[0]} 条 · 玩家 ${c[3]} 人 · 分组 ${c[4]} 人 · " +
            "城池 ${c[5]} 个 · 账包 ${c[2]} 个"
    }

    fun fmtTime(t: Long): String = if (t <= 0) "—" else
        SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(if (t > 1e11) t else t * 1000L))
}
