package com.zsm.terminal

import android.content.Context
import com.google.gson.Gson
import java.io.File

/** 本地解析结果 + 云端同盟战报合并，按玩家名索引出「队伍卡」 */
class TeamRepository(private val ctx: Context, private val settings: Settings) {

    private val gson = Gson()
    private val cache = File(ctx.filesDir, "decode_result.json")
    private val cloudCache = File(ctx.filesDir, "cloud_battles.json")

    @Volatile var result: DecodeResult = DecodeResult()
        private set
    private val cloudBattles: MutableList<Battle> = mutableListOf()
    private val lock = Any()

    init { restore() }

    fun merge(r: DecodeResult) {
        synchronized(lock) {
            val cur = result
            r.battles.forEach { b ->
                if (cur.battles.none { it.id == b.id }) cur.battles.add(b)
            }
            val known = cur.members.map { it.roleId }.toHashSet()
            r.members.forEach { if (known.add(it.roleId)) cur.members.add(it) }
            cur.groupByName.putAll(r.groupByName)
            cur.groupByRoleId.putAll(r.groupByRoleId)
            r.groupCount.forEach { (g, c) -> cur.groupCount[g] = c }
            cur.names.addAll(r.names)
            cur.cities.addAll(r.cities)
            val i = cur.intel
            if (i.serverCode.isEmpty()) i.serverCode = r.intel.serverCode
            if (i.serverId.isEmpty()) i.serverId = r.intel.serverId
            if (i.allianceId.isEmpty()) i.allianceId = r.intel.allianceId
            if (i.allianceName.isEmpty()) i.allianceName = r.intel.allianceName
            if (i.channel.isEmpty()) i.channel = r.intel.channel
            if (i.token.isEmpty()) i.token = r.intel.token
            if (i.gameServer.isEmpty()) i.gameServer = r.intel.gameServer
            r.intel.dns.forEach { if (it !in i.dns) i.dns.add(it) }
            cur.packets += r.packets
            cur.jsonBlocks += r.jsonBlocks
        }
        save()
    }

    fun pullCloud(): Int {
        val list = try {
            SupabaseClient(settings.sbUrl, settings.sbKey)
                .fetchBattles(settings.userId, settings.pin, settings.table)
        } catch (e: Exception) { emptyList() }
        synchronized(lock) {
            cloudBattles.clear()
            cloudBattles.addAll(list)
            val cur = result
            list.forEach { b -> if (cur.battles.none { it.id == b.id }) cur.battles.add(b) }
            list.forEach { b ->
                if (b.atk.isNotEmpty()) cur.names.add(b.atk)
                if (b.defName.isNotEmpty()) cur.names.add(b.defName)
                if (b.city.isNotEmpty() && b.city != "未知地点") cur.cities.add(b.city)
            }
        }
        save()
        return list.size
    }

    /** 悬浮层队伍列表：战报里的人 + 抓包名单的人，按分组排 */
    fun teamNames(): List<String> {
        synchronized(lock) {
            val all = LinkedHashSet<String>()
            result.battles.sortedByDescending { it.time }.forEach {
                if (it.atk.isNotEmpty()) all.add(it.atk)
                if (it.defName.isNotEmpty()) all.add(it.defName)
            }
            result.names.forEach { if (it.isNotEmpty()) all.add(it) }
            result.groupByName.keys.forEach { if (it.isNotEmpty()) all.add(it) }
            return all.sortedWith(compareBy(
                { groupOf(it).let { g -> if (g.isEmpty()) "zz" else Names.GID_MAP.entries.firstOrNull { e -> e.value == g }?.key?.toString()?.padStart(3, '0') ?: "zz" } },
                { it }
            )).take(300)
        }
    }

    fun groupOf(name: String): String {
        synchronized(lock) {
            result.groupByName[name]?.let { return it }
            val base = Names.baseName(name)
            result.groupByName[base]?.let { return it }
            return ""
        }
    }

    fun card(name: String): TeamCard {
        synchronized(lock) {
            val base = Names.baseName(name)
            val group = groupOf(name)
            val gid = Names.gidOf(group)
            val bs = result.battles.filter {
                it.atk == name || it.atk == base || it.defName == name || it.defName == base ||
                    Names.baseName(it.atk) == base || Names.baseName(it.defName) == base
            }.sortedByDescending { it.time }
            val b = bs.firstOrNull()
            val side = if (b == null) "" else if (b.atk == name || b.atk == base || Names.baseName(b.atk) == base) "攻方" else "守方"
            val units = when {
                b == null -> emptyList()
                side == "攻方" -> b.atkUnits
                else -> b.defUnits
            }
            val intel = result.intel
            return TeamCard(
                name = name, group = group, groupId = gid,
                city = b?.city ?: "", x = b?.x ?: 0, y = b?.y ?: 0,
                union = if (side == "攻方") b?.atkUnion ?: "" else b?.defUnion ?: "",
                server = intel.serverCode.ifEmpty { intel.serverId.ifEmpty { intel.channel } },
                side = side, result = b?.result ?: -1,
                units = units, battle = b,
                source = b?.source ?: "本地抓包解析"
            )
        }
    }

    fun stats(): String = synchronized(lock) {
        "战报 ${result.battles.size} 条 · 名单 ${result.names.size} 人 · " +
            "分组 ${result.groupByName.size} 人 · 包 ${result.packets} · JSON ${result.jsonBlocks}"
    }

    fun clear() {
        synchronized(lock) { result = DecodeResult(); cloudBattles.clear() }
        save()
    }

    private fun save() {
        try {
            synchronized(lock) {
                cache.writeText(gson.toJson(result))
                cloudCache.writeText(gson.toJson(cloudBattles))
            }
        } catch (e: Exception) { }
    }

    private fun restore() {
        try {
            if (cache.exists()) gson.fromJson(cache.readText(), DecodeResult::class.java)?.let { result = it }
            if (cloudCache.exists()) {
                val arr = gson.fromJson(cloudCache.readText(), Array<Battle>::class.java)
                if (arr != null) cloudBattles.addAll(arr)
            }
        } catch (e: Exception) { result = DecodeResult() }
    }
}
