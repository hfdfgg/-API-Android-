package com.zsm.terminal

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ZsmApp : Application() {
    companion object { const val CHANNEL_ID = "zsm_core" }

    override fun onCreate() {
        super.onCreate()
        Design.density = resources.displayMetrics.density
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "本地账包解析、悬浮队伍情报与背景音乐常驻"
                setSound(null, null)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        installCrashHandler()
    }

    /** 本地崩溃日志，只写 filesDir，不上传任何服务器 */
    private fun installCrashHandler() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val dir = File(filesDir, "logs").apply { mkdirs() }
                val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(Date())
                File(dir, "crash_$ts.txt").writeText(
                    "thread=${t.name}\n" + e.stackTraceToString()
                )
            } catch (ignored: Exception) { }
            prev?.uncaughtException(t, e)
        }
    }
}
