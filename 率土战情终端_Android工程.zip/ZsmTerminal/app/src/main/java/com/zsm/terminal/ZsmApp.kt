package com.zsm.terminal

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class ZsmApp : Application() {
    companion object { const val CHANNEL_ID = "zsm_capture" }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "接收 PCAPdroid 抓包并解析战报" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
}
