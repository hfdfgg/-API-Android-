package com.zsm.terminal

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.provider.Settings as AndroidSettings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/**
 * 悬浮队伍情报（VIP）：
 *  头像悬浮球 → 搜索面板（输入势力名 / 剪贴板取词 / 最近 / 收藏）→ 点一行弹出对方队伍卡。
 * 不使用 AccessibilityService、不 MediaProjection 录屏、不注入游戏、不模拟点击。
 */
class OverlayManager(
    private val ctx: Context,
    private val repo: TeamRepository,
    private val settings: Settings
) {
    companion object {
        fun canDraw(c: Context): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            AndroidSettings.canDrawOverlays(c)
    }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var ball: View? = null
    private var panel: View? = null
    private var card: View? = null
    private var ballParam: WindowManager.LayoutParams? = null

    init { TeamCardBus.attach(repo) }

    private fun lp(w: Int, h: Int, focusable: Boolean = false): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w, h,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    fun show() {
        if (!canDraw(ctx)) { toast("未授权悬浮窗"); return }
        if (!settings.isVip()) { toast("悬浮队伍情报为 VIP 专属"); goVip(); return }
        if (ball == null) addBall()
        AppState.overlayOn = true
        AppState.log("悬浮球已开启")
    }

    fun hide() {
        listOf(card, panel, ball).forEach { v -> if (v != null) safeRemove(v) }
        card = null; panel = null; ball = null
        AppState.overlayOn = false
        AppState.log("悬浮球已关闭")
    }

    fun refresh() { if (panel != null) { closePanel(); openPanel() } }

    private fun safeRemove(v: View) { try { wm.removeView(v) } catch (e: Exception) { } }

    private fun avatar(): BitmapDrawable? = try {
        ctx.assets.open("avatar.png").use { BitmapDrawable(ctx.resources, BitmapFactory.decodeStream(it)) }
    } catch (e: Exception) { null }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBall() {
        val size = settings.ballSize.coerceIn(40, 88)
        val px = Design.dp(ctx, size)
        val root = FrameLayout(ctx).apply {
            background = Design.bg(Design.SURFACE, size / 2, 2, Design.PRIMARY)
            elevation = Design.dp(ctx, 6).toFloat()
            alpha = settings.ballAlpha.coerceIn(40, 100) / 100f
        }
        avatar()?.let { root.background = it } ?: run {
            val t = Design.tv(ctx, "率", 18f, Color.WHITE, true, Gravity.CENTER)
            root.addView(t, FrameLayout.LayoutParams(px, px))
        }
        val p = lp(px, px).apply {
            x = if (settings.ballX >= 0) settings.ballX else Design.dp(ctx, 14)
            y = if (settings.ballY >= 0) settings.ballY else Design.dp(ctx, 280)
        }
        ballParam = p
        var dx0 = 0f; var dy0 = 0f; var sx = 0; var sy = 0; var moved = false
        root.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx0 = ev.rawX; dy0 = ev.rawY; sx = p.x; sy = p.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - dx0).toInt(); val dy = (ev.rawY - dy0).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > Design.dp(ctx, 8)) moved = true
                    p.x = sx + dx; p.y = sy + dy
                    try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    settings.ballX = p.x; settings.ballY = p.y
                    true
                }
                else -> false
            }
        }
        try { wm.addView(root, p) } catch (e: Exception) { return }
        ball = root
    }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun closePanel() { panel?.let { safeRemove(it) }; panel = null }

    // ---------------------------------------------------------------- 搜索面板
    private fun openPanel() {
        if (!settings.isVip()) { toast("VIP 专属"); goVip(); return }
        val box = Design.card(ctx, 0, true)
        val inner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Design.dp(ctx, 14), Design.dp(ctx, 13),
                Design.dp(ctx, 14), Design.dp(ctx, 13))
        }
        val head = Design.row(ctx)
        head.addView(Design.icon(ctx, R.drawable.ic_search, Design.CYAN, 20),
            LinearLayout.LayoutParams(Design.dp(ctx, 20), Design.dp(ctx, 20)))
        head.addView(Design.h3(ctx, "  查队伍"),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = Design.chip(ctx, "✕", Design.DANGER)
        close.setOnClickListener { closePanel() }
        head.addView(close)
        inner.addView(head)
        inner.addView(Design.cap(ctx, "输入势力名字 / 游戏名，点结果看对方是什么队伍"))
        inner.addView(Design.space(ctx, 10))

        val input = Design.input(ctx, "如：知夏丨江东 / 红颜丨老白")
        inner.addView(input)

        // 剪贴板取词：零权限，不读游戏界面
        if (settings.clipboardPick) {
            val clip = try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim() ?: ""
            } catch (e: Exception) { "" }
            if (clip.length in 2..20 && Regex("[一-龥A-Za-z]").containsMatchIn(clip) &&
                !clip.startsWith("http") && !clip.contains("\n")) {
                val c = Design.chip(ctx, "📋 检测到：$clip → 点此搜索", Design.GOLD)
                c.setOnClickListener { input.setText(clip) }
                inner.addView(c, Design.lp(top = 8))
            }
        }

        val quick = Design.row(ctx)
        listOf("最近" to "", "收藏" to "__fav__").forEach { (label, key) ->
            val c = Design.chip(ctx, label, Design.CYAN)
            c.setOnClickListener { input.setText(key) }
            quick.addView(c, Design.w(ctx, 1f, 6))
        }
        inner.addView(quick, Design.lp(top = 8))
        inner.addView(Design.divider(ctx), Design.lp(top = 10, bottom = 4))

        val listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(ctx).apply { addView(listBox) }
        inner.addView(sv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Design.dp(ctx, 260)))

        fun render(q: String) {
            listBox.removeAllViews()
            val hits = when (q) {
                "__fav__" -> repo.favorites()
                else -> repo.search(q)
            }.take(20)
            if (hits.isEmpty()) {
                listBox.addView(Design.cap(ctx, "暂无匹配。先在 App 里导入同盟战报包。"))
                return
            }
            hits.forEach { h ->
                val row = Design.row(ctx).apply {
                    background = Design.bg(Design.SURFACE2, 10)
                    setPadding(Design.dp(ctx, 10), Design.dp(ctx, 9),
                        Design.dp(ctx, 10), Design.dp(ctx, 9))
                    isClickable = true
                    setOnClickListener { showCard(h.name) }
                }
                val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                col.addView(Design.body(ctx, h.name))
                col.addView(Design.cap(ctx,
                    (h.group.ifEmpty { "未分组" }) + (if (h.count > 0) " · ${h.count} 场" else "")))
                row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(if (h.group.isNotEmpty()) Design.chip(ctx, h.group, Design.GOLD)
                            else Design.chip(ctx, "—", Design.MUTED))
                listBox.addView(row, Design.lp(top = 6))
            }
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { render(s?.toString() ?: "") }
        })
        render("")

        box.addView(inner)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = Design.dp(ctx, 8)
            y = (ballParam?.y ?: Design.dp(ctx, 280)) + Design.dp(ctx, 62)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try { wm.addView(box, p) } catch (e: Exception) { return }
        panel = box
    }

    // ---------------------------------------------------------------- 队伍卡浮层
    fun showCard(name: String) {
        if (!settings.isVip()) { toast("VIP 专属"); goVip(); return }
        closeCard()
        val c = repo.card(name)
        val box = Design.card(ctx, 0, true)
        val inner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Design.dp(ctx, 15), Design.dp(ctx, 13),
                Design.dp(ctx, 15), Design.dp(ctx, 13))
        }
        val head = Design.row(ctx)
        head.addView(Design.h2(ctx, c.name),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(if (c.favorite) Design.chip(ctx, "★", Design.GOLD)
                     else Design.chip(ctx, "☆", Design.MUTED))
        val x = Design.chip(ctx, "✕", Design.DANGER)
        x.setOnClickListener { closeCard() }
        head.addView(x)
        inner.addView(head)
        inner.addView(Design.cap(ctx, "本地同盟战报包 · " + c.source))
        inner.addView(Design.space(ctx, 8))

        fun info(k: String, v: String) {
            val r = Design.row(ctx)
            r.addView(Design.cap(ctx, k),
                LinearLayout.LayoutParams(Design.dp(ctx, 68), LinearLayout.LayoutParams.WRAP_CONTENT))
            r.addView(Design.body(ctx, v))
            inner.addView(r, Design.lp(top = 3))
        }
        info("分组名字", if (c.group.isEmpty()) "—" else "${c.groupId} ${c.group}")
        info("城池名字", if (c.city.isEmpty()) "—" else "${c.city} (${c.x}, ${c.y})")
        info("服务器", c.server.ifEmpty { "—" })
        info("同盟", c.union.ifEmpty { "—" })
        info("定位", if (c.side.isEmpty()) "—" else c.side + " · " +
            when (c.result) { 1 -> "攻方大捷"; 0 -> "守方胜利"; else -> "平局/未知" })
        info("战绩", "${c.battles} 场 / 胜 ${c.wins}")
        if (c.cities.isNotEmpty()) info("出没城池", c.cities.joinToString("、"))

        inner.addView(Design.divider(ctx), Design.lp(top = 8, bottom = 4))
        val units = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        if (c.units.isEmpty()) units.addView(Design.cap(ctx, "暂无阵容：导入含该玩家的同盟战报包即可看到。"))
        c.units.forEachIndexed { i, u ->
            val t = Design.h3(ctx, "${i + 1}  ${Names.hero(u.heroId)} Lv${u.level}" +
                (if (u.advance > 0) " " + "★".repeat(u.advance) else "") +
                "  战损 ${u.loss}")
            t.setTextColor(Design.CYAN)
            units.addView(t, Design.lp(top = 6))
            units.addView(Design.cap(ctx, "    " +
                (u.skills.joinToString(" · ") { "${Names.skill(it.skillId)} Lv${it.level}" }
                    .ifEmpty { "暂无战法记录" })))
        }
        val sv = ScrollView(ctx).apply { addView(units) }
        inner.addView(sv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Design.dp(ctx, 170)))

        inner.addView(Design.cap(ctx, "备注"), Design.lp(top = 8))
        val note = Design.input(ctx, "本地备注").apply { setText(c.note) }
        inner.addView(note)
        inner.addView(Design.space(ctx, 8))
        val acts = Design.row(ctx)
        val fav = Design.btn(ctx, if (c.favorite) "取消收藏" else "★ 收藏", 3) {
            TeamCardBus.toggle(c.name); closeCard(); toast(if (c.favorite) "已取消收藏" else "已收藏")
        }
        acts.addView(fav, Design.w(ctx, 1f, 6))
        val save = Design.btn(ctx, "保存备注", 5) {
            TeamCardBus.note(c.name, note.text.toString()); closeCard(); toast("备注已存本地")
        }
        acts.addView(save, Design.w(ctx, 1f, 0))
        inner.addView(acts)

        box.addView(inner)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = Design.dp(ctx, 8); y = Design.dp(ctx, 120)
        }
        try { wm.addView(box, p) } catch (e: Exception) { return }
        card = box
        if (settings.haptic) try {
            (ctx.getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator)
                .vibrate(15)
        } catch (e: Exception) { }
    }

    private fun closeCard() { card?.let { safeRemove(it) }; card = null }

    private fun goVip() {
        try {
            val i = Intent(ctx, MainActivity::class.java).apply {
                action = MainActivity.ACTION_GO_VIP
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            ctx.startActivity(i)
        } catch (e: Exception) { }
    }

    private fun toast(t: String) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()
        }
    }
}
