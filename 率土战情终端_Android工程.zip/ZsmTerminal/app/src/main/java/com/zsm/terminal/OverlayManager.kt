package com.zsm.terminal

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * 悬浮球 → 队伍列表 → 队伍卡。
 * 普通 App 拿不到游戏内的点击坐标（那要无障碍权限），所以用悬浮球 + 列表：
 * 点「知夏丨江东」这一行，就弹出该队伍的武将 / 战法 / 分组 / 城池信息。
 */
class OverlayManager(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var ball: View? = null
    private var panel: View? = null
    private var cardView: View? = null
    private var repo: TeamRepository? = null

    fun canDraw(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || AndroidSettings.canDrawOverlays(ctx)

    private fun lp(width: Int, height: Int, focusable: Boolean = false): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    fun attach(repository: TeamRepository) { repo = repository }

    fun show() {
        if (!canDraw()) return
        if (ball == null) addBall()
        refreshPanel()
    }

    fun hide() {
        listOf(cardView, panel, ball).forEach { v ->
            if (v != null) { try { wm.removeView(v) } catch (e: Exception) { } }
        }
        cardView = null; panel = null; ball = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBall() {
        val root = FrameLayout(ctx).apply {
            background = Ui.roundBg(Color.parseColor("#EE6366F1"), Ui.dp(ctx, 26).toFloat())
            elevation = Ui.dp(ctx, 6).toFloat()
        }
        val t = Ui.tv(ctx, "率", 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        val sz = Ui.dp(ctx, 52)
        root.addView(t, FrameLayout.LayoutParams(sz, sz))
        val p = lp(sz, sz).apply { x = Ui.dp(ctx, 12); y = Ui.dp(ctx, 260) }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        root.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = p.x; startY = p.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - downX).toInt(); val dy = (ev.rawY - downY).toInt()
                    if (Math.abs(dx) + Math.abs(dy) > Ui.dp(ctx, 8)) moved = true
                    p.x = startX + dx; p.y = startY + dy
                    try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
        try { wm.addView(root, p) } catch (e: Exception) { return }
        ball = root
    }

    private fun togglePanel() {
        if (panel != null) { hidePanel(); return }
        buildPanel()
    }

    private fun hidePanel() {
        listOf(cardView, panel).forEach { v -> if (v != null) try { wm.removeView(v) } catch (e: Exception) { } }
        cardView = null; panel = null
    }

    private fun buildPanel() {
        val names = repo?.teamNames().orEmpty()
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.roundBg(Color.parseColor("#F0111827"), Ui.dp(ctx, 16).toFloat())
            setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 12), Ui.dp(ctx, 14), Ui.dp(ctx, 12))
        }
        val head = Ui.row(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.tv(ctx, "队伍情报 · ${names.size}", 15f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = Ui.button(ctx, "✕", Color.parseColor("#33FFFFFF"), Color.WHITE) { hidePanel() }
        close.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 4), Ui.dp(ctx, 10), Ui.dp(ctx, 4))
        head.addView(close)
        box.addView(head)
        box.addView(Ui.tv(ctx, "点队伍名弹出武将 / 战法 / 分组 / 城池", 11f,
            Color.parseColor("#94A3B8")))

        val scroll = ScrollView(ctx)
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        if (names.isEmpty()) {
            list.addView(Ui.tv(ctx, "暂无队伍：先启动接收服务并导入 / 抓包", 13f,
                Color.parseColor("#CBD5E1")))
        }
        names.forEach { nm ->
            val g = repo?.groupOf(nm).orEmpty()
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                background = Ui.roundBg(Color.parseColor("#14FFFFFF"), Ui.dp(ctx, 8).toFloat())
                setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 9), Ui.dp(ctx, 10), Ui.dp(ctx, 9))
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                setOnClickListener { showCard(nm) }
            }
            row.addView(Ui.tv(ctx, nm, 13f, Color.WHITE, true),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Ui.tv(ctx, g.ifEmpty { "—" }, 11f, Color.parseColor("#FBBF24")))
            val lp2 = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = Ui.dp(ctx, 6) }
            list.addView(row, lp2)
        }
        scroll.addView(list)
        box.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 300)))
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = Ui.dp(ctx, 8); y = Ui.dp(ctx, 320)
        }
        try { wm.addView(box, p) } catch (e: Exception) { return }
        panel = box
    }

    fun refreshPanel() {
        if (panel != null) { hidePanel(); buildPanel() }
    }

    /** 点队伍名 → 队伍卡（就是截图里「知夏丨江东」点开要看到的东西） */
    fun showCard(name: String) {
        if (!canDraw()) return
        hideCard()
        val c = repo?.card(name) ?: return
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.roundBg(Color.parseColor("#F0111827"), Ui.dp(ctx, 16).toFloat())
            setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 14), Ui.dp(ctx, 16), Ui.dp(ctx, 14))
        }
        val head = Ui.row(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.tv(ctx, c.name, 17f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = Ui.button(ctx, "✕", Color.parseColor("#33FFFFFF"), Color.WHITE) { hideCard() }
        close.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 4), Ui.dp(ctx, 10), Ui.dp(ctx, 4))
        head.addView(close)
        box.addView(head)

        fun info(k: String, v: String) {
            val r = Ui.row(ctx)
            r.addView(Ui.tv(ctx, k, 11f, Color.parseColor("#94A3B8")),
                LinearLayout.LayoutParams(Ui.dp(ctx, 72), LinearLayout.LayoutParams.WRAP_CONTENT))
            r.addView(Ui.tv(ctx, v, 12f, Color.parseColor("#E2E8F0"), true))
            box.addView(r, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = Ui.dp(ctx, 3) })
        }
        info("分组名字", if (c.group.isEmpty()) "—" else "${c.groupId} ${c.group}")
        info("城池名字", if (c.city.isEmpty()) "—" else "${c.city} (${c.x}, ${c.y})")
        info("服务器", c.server.ifEmpty { "—" })
        info("同盟", c.union.ifEmpty { "—" })
        info("定位", if (c.side.isEmpty()) "—" else "${c.side} · " +
            when (c.result) { 1 -> "攻方大捷"; 0 -> "守方胜利"; else -> "平局/未知" })
        info("数据来源", c.source)

        box.addView(Ui.divider(ctx), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 1)
        ).apply { topMargin = Ui.dp(ctx, 10); bottomMargin = Ui.dp(ctx, 6) })

        if (c.units.isEmpty()) {
            box.addView(Ui.tv(ctx, "暂无该队伍的战报阵容（同步同盟战报库后可查看）", 12f,
                Color.parseColor("#FBBF24")))
        }
        c.units.forEachIndexed { idx, u ->
            val title = Ui.tv(ctx,
                "${idx + 1}  ${Names.hero(u.heroId)}  Lv${u.level}" +
                    (if (u.advance > 0) "  " + "★".repeat(u.advance) else "") +
                    "   战损 ${u.loss}" + (if (u.dead > 0) " / 阵亡 ${u.dead}" else ""),
                13f, Color.parseColor("#06B6D4"), true)
            box.addView(title, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = Ui.dp(ctx, 8) })
            if (u.skills.isEmpty()) {
                box.addView(Ui.tv(ctx, "    暂无战法记录", 11f, Color.parseColor("#64748B")))
            } else {
                val sk = u.skills.joinToString(" · ") { "${Names.skill(it.skillId)} Lv${it.level}" }
                box.addView(Ui.tv(ctx, "    $sk", 11f, Color.parseColor("#CBD5E1")))
            }
        }
        val scroll = ScrollView(ctx).apply {
            background = Ui.roundBg(Color.parseColor("#F0111827"), Ui.dp(ctx, 16).toFloat())
        }
        // box 已含全部内容，直接作为滚动内容（重新挂到 ScrollView）
        val wrap = FrameLayout(ctx).apply { addView(box) }
        scroll.addView(wrap)
        val p = lp(WindowManager.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 420)).apply {
            x = Ui.dp(ctx, 8); y = Ui.dp(ctx, 160)
        }
        try { wm.addView(scroll, p) } catch (e: Exception) { return }
        cardView = scroll
    }

    private fun hideCard() {
        cardView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        cardView = null
    }
}
