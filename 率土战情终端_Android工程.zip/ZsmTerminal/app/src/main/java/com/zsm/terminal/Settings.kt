package com.zsm.terminal

import android.content.Context
import com.google.gson.Gson

class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zsm_terminal_v2", Context.MODE_PRIVATE)
    private val gson = Gson()

    var port: Int
        get() = sp.getInt("port", 15432)
        set(v) = sp.edit().putInt("port", v).apply()

    /* 账号 / VIP：由网站 WebView 通过 JsBridge 镜像过来；账号本身仍在 Supabase 库 */
    var profile: Profile
        get() = try {
            gson.fromJson(sp.getString("profile", "") ?: "", Profile::class.java) ?: Profile()
        } catch (e: Exception) { Profile() }
        set(v) = sp.edit().putString("profile", gson.toJson(v)).apply()

    fun isVip(): Boolean {
        val p = profile
        if (!p.vip) return false
        if (p.vipExpire.isEmpty()) return true
        return try {
            val t = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.CHINA)
                .parse(p.vipExpire)?.time ?: 0L
            t > System.currentTimeMillis()
        } catch (e: Exception) { true }
    }

    /* 悬浮球 */
    var overlayEnabled: Boolean
        get() = sp.getBoolean("overlay_enabled", false)
        set(v) = sp.edit().putBoolean("overlay_enabled", v).apply()
    var ballSize: Int
        get() = sp.getInt("ball_size", 56)
        set(v) = sp.edit().putInt("ball_size", v).apply()
    var ballAlpha: Int
        get() = sp.getInt("ball_alpha", 96)
        set(v) = sp.edit().putInt("ball_alpha", v).apply()
    var ballX: Int
        get() = sp.getInt("ball_x", -1)
        set(v) = sp.edit().putInt("ball_x", v).apply()
    var ballY: Int
        get() = sp.getInt("ball_y", -1)
        set(v) = sp.edit().putInt("ball_y", v).apply()

    /* 体验 */
    var haptic: Boolean
        get() = sp.getBoolean("haptic", true)
        set(v) = sp.edit().putBoolean("haptic", v).apply()
    var clipboardPick: Boolean
        get() = sp.getBoolean("clipboard_pick", true)
        set(v) = sp.edit().putBoolean("clipboard_pick", v).apply()
    var musicWanted: Boolean
        get() = sp.getBoolean("music_wanted", true)
        set(v) = sp.edit().putBoolean("music_wanted", v).apply()

    var sbUrl: String
        get() = sp.getString("sb_url", BuildConfig.DEFAULT_SB_URL) ?: BuildConfig.DEFAULT_SB_URL
        set(v) = sp.edit().putString("sb_url", v).apply()
    var sbKey: String
        get() = sp.getString("sb_key", BuildConfig.DEFAULT_SB_KEY) ?: BuildConfig.DEFAULT_SB_KEY
        set(v) = sp.edit().putString("sb_key", v).apply()

    /* 首次引导 / 版本 */
    var onboardDone: Boolean
        get() = sp.getBoolean("onboard_done", false)
        set(v) = sp.edit().putBoolean("onboard_done", v).apply()
}
