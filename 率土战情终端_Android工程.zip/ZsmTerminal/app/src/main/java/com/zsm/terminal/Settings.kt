package com.zsm.terminal

import android.content.Context

class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zsm_terminal", Context.MODE_PRIVATE)

    var port: Int
        get() = sp.getInt("port", 15432)
        set(v) = sp.edit().putInt("port", v).apply()

    var sbUrl: String
        get() = sp.getString("sb_url", BuildConfig.DEFAULT_SB_URL) ?: BuildConfig.DEFAULT_SB_URL
        set(v) = sp.edit().putString("sb_url", v).apply()

    var sbKey: String
        get() = sp.getString("sb_key", BuildConfig.DEFAULT_SB_KEY) ?: BuildConfig.DEFAULT_SB_KEY
        set(v) = sp.edit().putString("sb_key", v).apply()

    /** 网站账号：登录后的用户 id 与 pin（网站里叫 token），用于读同盟战报库 */
    var userId: String
        get() = sp.getString("user_id", "") ?: ""
        set(v) = sp.edit().putString("user_id", v).apply()

    var pin: String
        get() = sp.getString("pin", "") ?: ""
        set(v) = sp.edit().putString("pin", v).apply()

    /** 云端备用：直接查战报表（RPC 不可用 / 同盟战报独立表时用） */
    var table: String
        get() = sp.getString("table", "zsm_battles") ?: "zsm_battles"
        set(v) = sp.edit().putString("table", v).apply()

    var allianceName: String
        get() = sp.getString("alliance_name", "") ?: ""
        set(v) = sp.edit().putString("alliance_name", v).apply()
}
