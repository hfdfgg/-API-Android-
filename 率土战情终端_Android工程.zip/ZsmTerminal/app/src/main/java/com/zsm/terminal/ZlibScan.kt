package com.zsm.terminal

import java.io.ByteArrayOutputStream
import java.util.zip.Inflater
import kotlin.math.max

/**
 * 游戏服把 JSON 用 zlib(0x78 9c/01/da/5e) 压在 TCP payload 里。
 * 与网站 src-battle 的 pako.Inflate + strm.total_in 完全同构：
 * 找 0x78 头 → Inflater 解压 → bytesRead 就是消费长度 → 从尾部继续找下一个块。
 */
object ZlibScan {
    fun findHead(b: ByteArray, start: Int, end: Int): Int {
        var i = max(0, start)
        while (i < end - 1) {
            if ((b[i].toInt() and 0xFF) == 0x78) {
                val x = b[i + 1].toInt() and 0xFF
                if (x == 0x01 || x == 0x5E || x == 0x9C || x == 0xDA) return i
            }
            i++
        }
        return -1
    }

    private const val MAX_FLOW = 8 * 1024 * 1024

    /** 单条 TCP 流的增量缓冲：边收边扫，已消费前缀自动裁掉 */
    class FlowBuffer {
        private var store = ByteArray(16 * 1024)
        private var size = 0
        private var scanPos = 0

        private fun ensure(cap: Int) {
            if (store.size < cap) {
                var n = store.size
                while (n < cap) n = max(cap, n * 2)
                store = store.copyOf(n)
            }
        }

        fun append(seg: ByteArray) {
            if (seg.isEmpty()) return
            if (size + seg.size > MAX_FLOW) {
                // 超长流（一般是 TLS/大文件）直接丢弃已扫描部分，防止 OOM
                compact(scanPos)
                if (size + seg.size > MAX_FLOW) { size = 0; scanPos = 0 }
            }
            ensure(size + seg.size)
            System.arraycopy(seg, 0, store, size, seg.size)
            size += seg.size
        }

        private fun compact(from: Int) {
            if (from <= 0) return
            if (from >= size) { size = 0; scanPos = 0; return }
            System.arraycopy(store, from, store, 0, size - from)
            size -= from
            scanPos = 0
        }

        /**
         * @param force 文件读完 / 连接断开时为 true：允许接收被截断的解压结果
         *              （脚本导出的报告 TXT 就是被 t[:5000] 截断的）
         */
        fun scan(force: Boolean, onText: (String) -> Unit): Int {
            var found = 0
            var guard = 0
            while (guard++ < 200000) {
                val idx = findHead(store, scanPos, size)
                if (idx < 0) break
                val inf = Inflater()                 // nowrap=false → zlib 头
                var consumed = 0
                var out: ByteArray? = null
                var finished = false
                try {
                    inf.setInput(store, idx, size - idx)
                    val bos = ByteArrayOutputStream()
                    val tmp = ByteArray(65536)
                    while (!inf.finished()) {
                        val n = inf.inflate(tmp)
                        if (n == 0) break
                        bos.write(tmp, 0, n)
                        if (bos.size() > 32 * 1024 * 1024) break
                    }
                    finished = inf.finished()
                    consumed = inf.bytesRead.toInt()
                    out = bos.toByteArray()
                } catch (e: Exception) {
                    // 压缩块还没收全，等下一批数据
                } finally {
                    inf.end()
                }
                val data = out
                val complete = finished || (force && data != null && data.isNotEmpty() && consumed > 0)
                if (!complete) break                 // 保留现场，下次从同一 idx 重扫
                if (data != null && data.isNotEmpty()) {
                    onText(String(data, Charsets.UTF_8))
                    found++
                }
                val next = if (consumed > 0) idx + consumed else idx + 2
                scanPos = next
                compact(next)
            }
            return found
        }
    }

    /** 按四元组重组 + 增量解压 */
    class Pipeline(private val onText: (String) -> Unit) {
        private val flows = LinkedHashMap<String, FlowBuffer>()
        private val seen = HashMap<String, HashSet<Long>>()
        @Volatile var packets = 0

        fun add(seg: PcapParser.Segment) {
            packets++
            val dup = seen.getOrPut(seg.key) { HashSet() }
            if (!dup.add(seg.seq)) return             // 重传去重
            val fb = flows.getOrPut(seg.key) { FlowBuffer() }
            fb.append(seg.payload)
            fb.scan(false, onText)
        }

        fun finish(): Int {
            var n = 0
            flows.values.forEach { n += it.scan(true, onText) }
            return n
        }
    }
}
