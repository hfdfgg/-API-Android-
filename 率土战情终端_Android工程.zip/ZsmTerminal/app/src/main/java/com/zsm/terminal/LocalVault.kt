package com.zsm.terminal

import android.app.KeyguardManager
import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.JsonObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * 本地账包：原始导入包加密落 filesDir/vault，解析结果在 SQLite。
 * 备份导出为 zip（战报 jsonl + 分组 + 收藏 + 加密原始包），可选设备凭据解锁。
 * 全程不联网、不上传。
 */
class LocalVault(private val ctx: Context, private val store: BattleStore) {
    private val dir = File(ctx.filesDir, "vault").apply { mkdirs() }
    private val gson = Gson()

    fun isDeviceSecure(): Boolean {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return km?.isDeviceSecure == true
    }

    fun file(id: String) = File(dir, "$id.bin")

    fun saveOriginal(id: String, bytes: ByteArray): Pair<Long, String> =
        FileOutputStream(file(id)).use { out ->
            Crypto.encryptStream(ByteArrayInputStream(bytes), out)
        }

    /** 流式：274MB 大包也不会整文件进内存 */
    fun saveOriginalFromUri(id: String, uri: Uri): Pair<Long, String> {
        val ins = ctx.contentResolver.openInputStream(uri)
            ?: return 0L to ""
        FileOutputStream(file(id)).use { out ->
            return ins.use { Crypto.encryptStream(it, out) }
        }
    }

    fun readOriginal(id: String): ByteArray {
        val f = file(id); if (!f.exists()) return ByteArray(0)
        val out = ByteArrayOutputStream()
        FileInputStream(f).use { Crypto.decryptStream(it, out) }
        return out.toByteArray()
    }

    fun deleteOriginal(id: String) { file(id).delete() }

    fun totalBytes(): Long = dir.listFiles()?.sumOf { it.length() } ?: 0L

    // ---------------- 备份 ----------------
    fun exportBackup(out: FileOutputStream, includeRaw: Boolean = true): Int {
        var n = 0
        ZipOutputStream(out).use { z ->
            fun entry(name: String, content: String) {
                z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            val manifest = JsonObject().apply {
                addProperty("app", "率土战情终端")
                addProperty("version", 2)
                addProperty("exportedAt", System.currentTimeMillis())
                addProperty("battles", store.dumpRawBattles().size)
                addProperty("groups", store.groupCount())
                addProperty("includeRaw", includeRaw)
            }
            entry("manifest.json", gson.toJson(manifest))
            entry("battles.jsonl", store.dumpRawBattles().joinToString("\n"))
            entry("groups.tsv", store.dumpGroups().joinToString("\n"))
            entry("favorites.tsv", store.dumpFavorites().joinToString("\n"))
            entry("packets.json", gson.toJson(store.packets()))
            if (includeRaw) {
                dir.listFiles()?.forEach { f ->
                    z.putNextEntry(ZipEntry("vault/" + f.name))
                    FileInputStream(f).use { it.copyTo(z) }
                    z.closeEntry(); n++
                }
            }
        }
        return n
    }

    fun importBackup(uri: Uri): ImportReport {
        val ins = ctx.contentResolver.openInputStream(uri) ?: return ImportReport(message = "无法读取备份")
        var added = 0; var dup = 0; var groups = 0; var raw = 0
        ZipInputStream(ins).use { z ->
            while (true) {
                val e: ZipEntry = z.nextEntry ?: break
                val content = z.readBytes()
                when {
                    e.name == "battles.jsonl" -> {
                        String(content, Charsets.UTF_8).lines().filter { it.isNotBlank() }.forEach {
                            when (store.restoreBattle(it, "备份恢复")) { 0 -> added++; else -> dup++ }
                        }
                    }
                    e.name == "groups.tsv" -> {
                        String(content, Charsets.UTF_8).lines().filter { it.isNotBlank() }.forEach {
                            store.restoreGroup(it); groups++
                        }
                    }
                    e.name == "favorites.tsv" -> {
                        String(content, Charsets.UTF_8).lines().filter { it.isNotBlank() }.forEach {
                            val a = it.split("\t")
                            if (a.isNotEmpty() && a[0].isNotEmpty()) {
                                store.setNote(a[0], a.getOrElse(1) { "" })
                            }
                        }
                    }
                    e.name.startsWith("vault/") -> {
                        val f = file(e.name.substringAfterLast('/'))
                        FileOutputStream(f).use { it.write(content) }
                        raw++
                    }
                }
                z.closeEntry()
            }
        }
        return ImportReport("备份恢复", "backup", 0, added, dup, 0, groups,
            message = "备份恢复：新增 $added · 重复 $dup · 分组 $groups · 原始账包 $raw")
    }

    fun clearAll() {
        store.clearAll()
        dir.listFiles()?.forEach { it.delete() }
    }
}
