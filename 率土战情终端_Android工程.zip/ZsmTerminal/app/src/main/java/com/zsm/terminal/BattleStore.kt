package com.zsm.terminal

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/**
 * 本地战报账仓库（v2 核心）：APP 的「战场功能」完全本地，不写回任何数据库。
 * 去重以 fp(规范化业务字段 SHA-256) 为主键；同 battle_id 内容变化记为更新。
 */
class BattleStore(ctx: Context) :
    SQLiteOpenHelper(ctx, "zsm_local_battles.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS battles(
            fp TEXT PRIMARY KEY,
            battle_id TEXT, atk TEXT, def_name TEXT, city TEXT,
            x INTEGER, y INTEGER, time INTEGER, result INTEGER,
            raw TEXT NOT NULL, source TEXT, added_at INTEGER,
            version INTEGER DEFAULT 1)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_b_atk ON battles(atk)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_b_def ON battles(def_name)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_b_city ON battles(city)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_b_bid ON battles(battle_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_b_time ON battles(time)")
        db.execSQL("CREATE TABLE IF NOT EXISTS groups(name TEXT PRIMARY KEY, role_id INTEGER, gid INTEGER, grp TEXT)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS packets(
            id TEXT PRIMARY KEY, name TEXT, size INTEGER, added_at INTEGER,
            kind TEXT, battles INTEGER, duplicate INTEGER, updated INTEGER, sha TEXT)""")
        db.execSQL("CREATE TABLE IF NOT EXISTS favorites(name TEXT PRIMARY KEY, note TEXT, added_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS history(name TEXT PRIMARY KEY, hits INTEGER, last_at INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS intel(k TEXT PRIMARY KEY, v TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        if (old < 2) { onCreate(db) }
    }

    private fun dbw() = writableDatabase
    private fun dbr() = readableDatabase

    /** @return 0=新增 1=重复丢弃 2=同 battle_id 内容更新 */
    fun put(o: JsonObject, source: String): Int {
        val fp = Dedupe.fingerprint(o)
        val bid = Dedupe.battleKey(o)
        val raw = o.toString()
        fun s(k: String): String {
            val v = o.get(k) ?: return ""
            return if (v.isJsonPrimitive) v.asString.trim() else ""
        }
        fun n(k: String): Int = try { s(k).toDouble().toInt() } catch (e: Exception) { 0 }
        val atk = Names.cleanName(
            listOf("attack_name", "atk", "atk_name").firstNotNullOfOrNull { s(it).ifEmpty { null } } ?: ""
        )
        val def = Names.cleanName(
            listOf("defend_name", "def", "def_name").firstNotNullOfOrNull { s(it).ifEmpty { null } } ?: ""
        )
        val city = listOf("wid_name", "city_name", "city", "place")
            .firstNotNullOfOrNull { s(it).ifEmpty { null } } ?: "未知地点"
        var time = listOf("time", "battle_time").firstNotNullOfOrNull { s(it).ifEmpty { null } }
            ?.let { try { it.toDouble().toLong() } catch (e: Exception) { 0L } } ?: 0L
        if (time > 1e11) time /= 1000L
        val result = n("result")
        val x = n("x"); val y = n("y")

        val db = dbw()
        db.beginTransaction()
        try {
            val dup = db.rawQuery("SELECT 1 FROM battles WHERE fp=? LIMIT 1", arrayOf(fp)).use { it.moveToFirst() }
            if (dup) return 1                       // 一模一样 → 不要
            var updated = false
            var conflict = false
            if (bid.isNotEmpty()) {
                var oldRaw: String? = null
                var oldVer = 1
                db.rawQuery("SELECT raw,version FROM battles WHERE battle_id=? LIMIT 1", arrayOf(bid)).use { c ->
                    if (c.moveToFirst()) { oldRaw = c.getString(0); oldVer = c.getInt(1) }
                }
                if (oldRaw != null && oldRaw != raw) {
                    db.delete("battles", "battle_id=?", arrayOf(bid))
                    updated = true
                    putRow(db, fp, bid, atk, def, city, x, y, time, result, raw, source, oldVer + 1)
                } else if (oldRaw != null) {
                    conflict = true      // raw 相同但 fp 不同（防御性处理）
                }
            }
            if (conflict) return 1
            if (!updated) putRow(db, fp, bid, atk, def, city, x, y, time, result, raw, source, 1)
            db.setTransactionSuccessful()
            return if (updated) 2 else 0
        } finally { db.endTransaction() }
    }

    private fun putRow(db: SQLiteDatabase, fp: String, bid: String, atk: String, def: String,
                       city: String, x: Int, y: Int, time: Long, result: Int,
                       raw: String, source: String, ver: Int) {
        val cv = ContentValues().apply {
            put("fp", fp); put("battle_id", bid); put("atk", atk); put("def_name", def)
            put("city", city); put("x", x); put("y", y); put("time", time)
            put("result", result); put("raw", raw); put("source", source)
            put("added_at", System.currentTimeMillis()); put("version", ver)
        }
        db.insertWithOnConflict("battles", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun putGroup(name: String, roleId: Long, gid: Int, grp: String) {
        if (name.isEmpty() || grp !in Names.WHITE || Names.GID_MAP[gid] != grp) return
        dbw().insertWithOnConflict("groups", null, ContentValues().apply {
            put("name", name); put("role_id", roleId); put("gid", gid); put("grp", grp)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun groupOf(name: String): String {
        val base = Names.baseName(name)
        dbr().rawQuery("SELECT grp FROM groups WHERE name=? LIMIT 1", arrayOf(name)).use {
            if (it.moveToFirst()) return it.getString(0)
        }
        dbr().rawQuery("SELECT grp FROM groups WHERE name=? LIMIT 1", arrayOf(base)).use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return ""
    }

    fun groupCount(): Int = dbr().rawQuery("SELECT COUNT(*) FROM groups", null).use {
        if (it.moveToFirst()) it.getInt(0) else 0
    }

    fun putIntel(k: String, v: String) {
        if (k.isEmpty() || v.isEmpty()) return
        dbw().insertWithOnConflict("intel", null, ContentValues().apply {
            put("k", k); put("v", v)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun intel(k: String): String = dbr().rawQuery("SELECT v FROM intel WHERE k=? LIMIT 1", arrayOf(k)).use {
        if (it.moveToFirst()) it.getString(0) else ""
    }

    // ---------------- 账包 ----------------
    fun addPacket(p: PacketInfo) {
        dbw().insertWithOnConflict("packets", null, ContentValues().apply {
            put("id", p.id); put("name", p.name); put("size", p.size)
            put("added_at", p.addedAt); put("kind", p.kind)
            put("battles", p.battles); put("duplicate", p.duplicate)
            put("updated", p.updated); put("sha", p.sha)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun packets(): List<PacketInfo> {
        val out = ArrayList<PacketInfo>()
        dbr().rawQuery("SELECT id,name,size,added_at,kind,battles,duplicate,updated,sha FROM packets ORDER BY added_at DESC", null).use { c ->
            while (c.moveToNext()) out.add(
                PacketInfo(c.getString(0), c.getString(1), c.getLong(2), c.getLong(3),
                    c.getString(4), c.getInt(5), c.getInt(6), c.getInt(7), c.getString(8))
            )
        }
        return out
    }

    fun deletePacket(id: String) { dbw().delete("packets", "id=?", arrayOf(id)) }

    // ---------------- 检索 ----------------
    fun search(q: String, limit: Int = 40): List<PlayerHit> {
        if (q.isEmpty()) return recentPlayers(limit)
        val like = "%$q%"
        val sql = """SELECT name, COUNT(*) c, MAX(t) mt FROM (
                       SELECT atk name, time t FROM battles WHERE atk <> '' AND atk LIKE ?
                       UNION ALL
                       SELECT def_name name, time t FROM battles WHERE def_name <> '' AND def_name LIKE ?
                     ) GROUP BY name ORDER BY c DESC, mt DESC LIMIT $limit"""
        val out = ArrayList<PlayerHit>()
        dbr().rawQuery(sql, arrayOf(like, like)).use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0)
                out.add(PlayerHit(name, c.getInt(1), groupOf(name), c.getLong(2)))
            }
        }
        return out
    }

    fun recentPlayers(limit: Int = 40): List<PlayerHit> {
        val out = ArrayList<PlayerHit>()
        val sql = """SELECT name, COUNT(*) c, MAX(t) mt FROM (
                       SELECT atk name, time t FROM battles WHERE atk <> ''
                       UNION ALL
                       SELECT def_name name, time t FROM battles WHERE def_name <> ''
                     ) GROUP BY name ORDER BY mt DESC, c DESC LIMIT $limit"""
        dbr().rawQuery(sql, null).use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0)
                out.add(PlayerHit(name, c.getInt(1), groupOf(name), c.getLong(2)))
            }
        }
        return out
    }

    fun battlesOf(name: String): List<Battle> {
        val base = Names.baseName(name)
        val out = ArrayList<Battle>()
        val sql = "SELECT raw,source FROM battles WHERE atk=? OR def_name=? OR atk=? OR def_name=? ORDER BY time DESC LIMIT 60"
        dbr().rawQuery(sql, arrayOf(name, name, base, base)).use { c ->
            while (c.moveToNext()) {
                try {
                    val o = JsonParser.parseString(c.getString(0)).asJsonObject
                    BattleDecoder.battleFrom(o)?.let { out.add(it.copy(source = c.getString(1) ?: "本地账包")) }
                } catch (e: Exception) { }
            }
        }
        // 名字前缀匹配（「知夏丨江东」→「知夏」）
        if (out.isEmpty() && base.isNotEmpty()) {
            dbr().rawQuery("SELECT raw,source FROM battles WHERE atk LIKE ? OR def_name LIKE ? ORDER BY time DESC LIMIT 60",
                arrayOf("%$base%", "%$base%")).use { c ->
                while (c.moveToNext()) {
                    try {
                        val o = JsonParser.parseString(c.getString(0)).asJsonObject
                        BattleDecoder.battleFrom(o)?.let { out.add(it.copy(source = c.getString(1) ?: "本地账包")) }
                    } catch (e: Exception) { }
                }
            }
        }
        return out
    }

    // ---------------- 收藏 / 历史 / 备注 ----------------
    fun favorite(name: String): Boolean = dbr().rawQuery(
        "SELECT 1 FROM favorites WHERE name=? LIMIT 1", arrayOf(name)
    ).use { it.moveToFirst() }

    fun toggleFavorite(name: String) {
        if (favorite(name)) dbw().delete("favorites", "name=?", arrayOf(name))
        else dbw().insertWithOnConflict("favorites", null, ContentValues().apply {
            put("name", name); put("note", ""); put("added_at", System.currentTimeMillis())
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun note(name: String): String = dbr().rawQuery(
        "SELECT note FROM favorites WHERE name=? LIMIT 1", arrayOf(name)
    ).use { if (it.moveToFirst()) it.getString(0) ?: "" else "" }

    fun setNote(name: String, note: String) {
        if (!favorite(name)) toggleFavorite(name)
        dbw().execSQL("UPDATE favorites SET note=? WHERE name=?", arrayOf(note, name))
    }

    fun favorites(): List<String> {
        val out = ArrayList<String>()
        dbr().rawQuery("SELECT name FROM favorites ORDER BY added_at DESC", null).use {
            while (it.moveToNext()) out.add(it.getString(0))
        }
        return out
    }

    fun recordHistory(name: String) {
        dbw().execSQL(
            "INSERT INTO history(name,hits,last_at) VALUES(?,1,?) ON CONFLICT(name) DO UPDATE SET hits=hits+1,last_at=excluded.last_at",
            arrayOf(name, System.currentTimeMillis())
        )
    }

    fun history(): List<String> {
        val out = ArrayList<String>()
        dbr().rawQuery("SELECT name FROM history ORDER BY last_at DESC LIMIT 20", null).use {
            while (it.moveToNext()) out.add(it.getString(0))
        }
        return out
    }

    // ---------------- 统计 / 备份 ----------------
    fun counts(): IntArray {
        val b = dbr().rawQuery("SELECT COUNT(*),COUNT(DISTINCT battle_id) FROM battles", null).use {
            if (it.moveToFirst()) intArrayOf(it.getInt(0), it.getInt(1)) else intArrayOf(0, 0)
        }
        val p = dbr().rawQuery("SELECT COUNT(*) FROM packets", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        val pl = dbr().rawQuery("""SELECT COUNT(*) FROM (
                SELECT atk n FROM battles WHERE atk<>'' UNION SELECT def_name n FROM battles WHERE def_name<>'')""",
            null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        val g = groupCount()
        val c = dbr().rawQuery("SELECT COUNT(DISTINCT city) FROM battles WHERE city<>'' AND city<>'未知地点'", null)
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }
        return intArrayOf(b[0], b[1], p, pl, g, c)
    }

    fun dumpRawBattles(): List<String> {
        val out = ArrayList<String>()
        dbr().rawQuery("SELECT raw FROM battles ORDER BY time DESC", null).use {
            while (it.moveToNext()) out.add(it.getString(0))
        }
        return out
    }

    fun dumpGroups(): List<String> {
        val out = ArrayList<String>()
        dbr().rawQuery("SELECT name,role_id,gid,grp FROM groups", null).use {
            while (it.moveToNext()) out.add(listOf(it.getString(0), it.getLong(1).toString(),
                it.getInt(2).toString(), it.getString(3)).joinToString("\t"))
        }
        return out
    }

    fun dumpFavorites(): List<String> {
        val out = ArrayList<String>()
        dbr().rawQuery("SELECT name,note FROM favorites", null).use {
            while (it.moveToNext()) out.add(it.getString(0) + "\t" + (it.getString(1) ?: ""))
        }
        return out
    }

    fun restoreBattle(raw: String, source: String): Int {
        return try { put(JsonParser.parseString(raw).asJsonObject, source) } catch (e: Exception) { 1 }
    }

    fun restoreGroup(line: String) {
        val a = line.split("\t")
        if (a.size >= 4) putGroup(a[0], a[1].toLongOrNull() ?: 0L, a[2].toIntOrNull() ?: 0, a[3])
    }

    fun clearAll() {
        val db = dbw()
        listOf("battles", "groups", "packets", "favorites", "history", "intel").forEach {
            db.delete(it, null, null)
        }
    }
}
