package com.zsm.terminal

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/**
 * 解析内核：把解压出来的 JSON 文本，解成
 *  - 战报（battle_id / attack_name …，含三武将 + 战法 + 战损）
 *  - 分组（只认 9 个白名单，位置双校验，杜绝家族名/乱码混进来）
 *  - 情报（服务器代号 / ID / 同盟 ID / 渠道 / 会话令牌）
 * 与 tools/selfcheck.py 的 decode() 同构，可交叉验证。
 */
object BattleDecoder {

    private val TRIPLE = Regex("\\[\\s*(\\d{3,7})\\s*,\\s*(\\d{1,3})\\s*,\\s*\"([^\"]{1,12})\"\\s*\\]")
    private val STUB = Regex("\\[\\s*(\\d{3,7})\\s*,\\s*\"([^\"]{1,24})\"\\s*,")
    private val SERVER_ARR = Regex("\"server\"\\s*:\\s*\\[\\s*\"([^\"]+)\"\\s*,\\s*\\d+\\s*,\\s*(\\d{3,7})")
    private val SERVER_NUM = Regex("\"server\"\\s*:\\s*(\\d{3,7})")
    private val ALLIANCE = Regex("\"alliance_id\"\\s*:\\s*(\\d+)")
    private val ALLIANCE_NAME = Regex("\"(?:alliance_name|union_name|guild_name)\"\\s*:\\s*\"([^\"]{1,20})\"")
    private val CHANNEL = Regex("\"(\\d{6}),(\\d{9,11})\"")
    private val TOKEN = Regex("([0-9a-f]{32})_?")
    private val DNS = Regex("(?:proxima|netease|sdkgate|pushv3|omega\\d+|ntes\\d+|drpf-[a-z0-9]+|lbc-[a-z0-9-]+)")

    fun decodeText(text: String, r: DecodeResult) {
        // 1) 三元组：分组在抓包里的固定位置 [roleId, gid, "城池"]
        TRIPLE.findAll(text).forEach { m ->
            val gid = m.groupValues[2].toIntOrNull() ?: return@forEach
            val city = m.groupValues[3]
            if (Names.GID_MAP[gid] == city && city in Names.WHITE) {
                val rid = m.groupValues[1].toLongOrNull() ?: return@forEach
                r.groupByRoleId[rid] = city
                r.groupCount[city] = (r.groupCount[city] ?: 0) + 1
            }
        }
        // 2) 名字前缀：报告被截断时，至少把 [id,"名字", 抢救出来
        val nameById = HashMap<Long, String>()
        STUB.findAll(text).forEach { m ->
            val nm = Names.cleanName(m.groupValues[2])
            val rid = m.groupValues[1].toLongOrNull() ?: return@forEach
            if (nm.isNotEmpty() && !nameById.containsKey(rid)) nameById[rid] = nm
        }
        r.groupByRoleId.forEach { (rid, g) -> nameById[rid]?.let { r.groupByName[it] = g } }

        // 3) 元数据
        SERVER_ARR.find(text)?.let {
            if (r.intel.serverCode.isEmpty()) r.intel.serverCode = it.groupValues[1]
            if (r.intel.serverId.isEmpty()) r.intel.serverId = it.groupValues[2]
        }
        if (r.intel.serverId.isEmpty()) SERVER_NUM.find(text)?.let { r.intel.serverId = it.groupValues[1] }
        if (r.intel.allianceId.isEmpty()) ALLIANCE.find(text)?.let { r.intel.allianceId = it.groupValues[1] }
        if (r.intel.allianceName.isEmpty()) ALLIANCE_NAME.find(text)?.let { r.intel.allianceName = it.groupValues[1] }
        if (r.intel.channel.isEmpty()) CHANNEL.find(text)?.let { r.intel.channel = it.groupValues[1] }
        if (r.intel.token.isEmpty()) TOKEN.find(text)?.let { r.intel.token = it.groupValues[1] }
        DNS.findAll(text).map { it.value }.distinct().take(12).forEach {
            if (it !in r.intel.dns) r.intel.dns.add(it)
        }

        // 4) 完整 JSON 深度遍历
        try {
            walk(JsonParser.parseString(text), r, 0)
        } catch (e: Exception) {
            // 报告 TXT 可能被截断，正则部分仍然有效
        }
    }

    private fun str(o: JsonObject, vararg keys: String): String {
        for (k in keys) {
            val e = o.get(k) ?: continue
            if (e.isJsonPrimitive) return e.asString ?: ""
        }
        return ""
    }

    fun n(v: JsonElement?): Int {
        if (v == null || !v.isJsonPrimitive) return 0
        return try { v.asString.trim().toDouble().toInt() } catch (e: Exception) { 0 }
    }

    private fun num(o: JsonObject, vararg keys: String): Int {
        for (k in keys) { val e = o.get(k) ?: continue; val x = n(e); if (x != 0) return x }
        return 0
    }

    private fun walk(el: JsonElement, r: DecodeResult, depth: Int) {
        if (depth > 40) return
        if (el.isJsonArray) {
            val a = el.asJsonArray
            // 成员数组固定位置：0=roleId 1=名字 12=gid 13=城池名
            if (a.size() >= 30 && a.get(1).isJsonPrimitive) {
                val gid = n(a.get(12))
                val city = if (a.get(13).isJsonPrimitive) a.get(13).asString.trim() else ""
                if (Names.GID_MAP[gid] == city && city in Names.WHITE) {
                    val nm = Names.cleanName(a.get(1).asString)
                    if (nm.isNotEmpty()) {
                        val rid = try { a.get(0).asString.toLong() } catch (e: Exception) { 0L }
                        r.members.add(Member(rid, nm, gid, city, n(a.get(2))))
                        r.groupByName[nm] = city
                        r.groupByRoleId[rid] = city
                    }
                }
            }
            for (i in 0 until a.size()) {
                try { walk(a.get(i), r, depth + 1) } catch (e: Exception) { }
            }
            return
        }
        if (!el.isJsonObject) return
        val o = el.asJsonObject
        if (o.has("battle_id") && o.has("attack_name")) {
            battleFrom(o)?.let { b ->
                if (r.battles.none { it.id == b.id }) {
                    r.battles.add(b)
                    if (b.atk.isNotEmpty()) r.names.add(b.atk)
                    if (b.defName.isNotEmpty()) r.names.add(b.defName)
                    if (b.city.isNotEmpty() && b.city != "未知地点") r.cities.add(b.city)
                }
            }
        }
        val lg = o.getAsJsonObject("log")
        if (lg != null) {
            val nm = Names.cleanName(str(lg, "role_name"))
            if (nm.isNotEmpty()) r.names.add(nm)
        }
        for ((_, v) in o.entrySet()) {
            try { walk(v, r, depth + 1) } catch (e: Exception) { }
        }
    }

    /** 云端「同盟战报」库返回的扁平行也走这里，字段别名全兼容 */
    fun battleFrom(o: JsonObject): Battle? {
        val id = str(o, "battle_id", "id", "uid", "_uid")
        val atk = Names.cleanName(str(o, "attack_name", "atk", "atk_name"))
        val def = Names.cleanName(str(o, "defend_name", "def", "def_name"))
        if (id.isEmpty() && atk.isEmpty()) return null
        val atkU = parseHeroes(str(o, "attack_all_hero_info", "atk_heroes"))
        val defU = parseHeroes(str(o, "defend_all_hero_info", "def_heroes"))
        val (ask, dsk) = parseSkills(str(o, "all_skill_info", "skills"))
        val aa = advArr(o.get("attack_advance"))
        val da = advArr(o.get("defend_advance"))
        atkU.forEachIndexed { i, u ->
            u.advance = pickAdv(aa, i, atkU.size)
            if (i < ask.size) u.skills.addAll(ask[i])
        }
        defU.forEachIndexed { i, u ->
            u.advance = pickAdv(da, i, defU.size)
            if (i < dsk.size) u.skills.addAll(dsk[i])
        }
        var time = num(o, "time", "battle_time").toLong()
        if (time > 1e11) time /= 1000L
        val city = str(o, "wid_name", "city_name", "city", "place").ifEmpty { "未知地点" }
        return Battle(
            id = id.ifEmpty { "$atk-${num(o, "time", "battle_time")}" },
            time = time,
            city = city,
            x = num(o, "x", "pos_x", "posx", "position_x"),
            y = num(o, "y", "pos_y", "posy", "position_y"),
            atk = atk, defName = def,
            atkUnion = str(o, "attack_union_name", "atk_union"),
            defUnion = str(o, "defend_union_name", "def_union"),
            result = num(o, "result"),
            atkUnits = atkU, defUnits = defU,
            atkLoss = atkU.sumOf { it.loss }, defLoss = defU.sumOf { it.loss }
        )
    }

    fun parseHeroes(s: String): MutableList<HeroUnit> {
        val out = mutableListOf<HeroUnit>()
        if (s.isEmpty()) return out
        s.split(';').forEach { row ->
            val seg = row.split(',')
            if (seg.size < 3 || numStr(seg[0]) == 0) return@forEach
            val mx = numStr(seg[2]); val rm = if (seg.size > 3) numStr(seg[3]) else 0
            val wd = if (seg.size > 4) numStr(seg[4]) else 0
            val loss = maxOf(0, mx - rm)
            var adv = 0
            for (k in 5 until minOf(seg.size, 9)) {
                val v = numStr(seg[k])
                if (v in 1..5) { adv = v; break }
            }
            out.add(
                HeroUnit(
                    slot = out.size + 1,
                    heroId = numStr(seg[0]).toLong(),
                    level = numStr(seg[1]),
                    maxHp = mx, remainHp = rm, wounded = wd,
                    dead = maxOf(0, loss - wd), loss = loss, advance = adv
                )
            )
        }
        return out
    }

    fun parseSkills(s: String): Pair<List<List<SkillInfo>>, List<List<SkillInfo>>> {
        val atk = mutableListOf<List<SkillInfo>>()
        val dfs = mutableListOf<List<SkillInfo>>()
        if (s.isEmpty()) return atk to dfs
        s.split(';').forEachIndexed { i, row ->
            val seg = row.split(',')
            if (seg.size < 2) return@forEachIndexed
            val raw = numStr(seg[0])
            val sideAttack = raw in 1..3
            val slot = when {
                raw in 4..6 -> raw - 3
                raw in 7..9 -> raw - 6
                else -> (i % 3) + 1
            }
            val list = mutableListOf<SkillInfo>()
            var j = 1
            while (j + 1 < seg.size && list.size < 3) {
                val sid = numStr(seg[j]).toLong()
                val lv = numStr(seg[j + 1])
                if (sid != 0L) list.add(SkillInfo(sid, lv, slot))
                j += 2
            }
            (if (sideAttack) atk else dfs).add(list)
        }
        return atk to dfs
    }

    fun advArr(v: JsonElement?): List<Int> {
        if (v == null) return emptyList()
        if (v.isJsonArray) return v.asJsonArray.map { n(it) }
        if (!v.isJsonPrimitive) return emptyList()
        return v.asString.split(Regex("[,;\\s]+")).filter { it.isNotEmpty() }
            .mapNotNull { it.trim().toIntOrNull() }
    }

    fun pickAdv(arr: List<Int>, idx: Int, total: Int): Int {
        if (arr.size == total && idx < arr.size && arr[idx] in 0..5) return arr[idx]
        if (arr.size == 1 && arr[0] in 0..5) return arr[0]
        if (arr.size > idx && arr[idx] in 0..5) return arr[idx]
        return 0
    }

    private fun numStr(v: String): Int = try { v.trim().toDouble().toInt() } catch (e: Exception) { 0 }
}
