# 率土战情终端（Android）

> PCAPdroid 抓包 → 手机终端本地解析 → 队伍情报浮层 → 点队伍名弹出武将 / 战法 / 分组 / 城池。
> 网站（率土战情中枢）保持不动，本仓库是**独立的 Android App**，复用同一个 Supabase 同盟战报库。

---

## 一、它解决什么

游戏地图里点「知夏丨江东」这类队伍标记，App 会直接弹出该队伍的信息卡：

| 字段 | 来源 |
|---|---|
| 队伍名 / 分组名字（7 天门） | 抓包成员数组 + 三元组，9 组白名单 |
| 城池名字（零陵 / 坐标 1315,374） | 战报 `wid_name` / `x` / `y` |
| 服务器代号 X6201、同盟 ID | 抓包 `server` / `alliance_id` |
| 三武将、等级、红度、战损 | 战报 `attack_all_hero_info` |
| 每人战法 + 等级 | 战报 `all_skill_info` |
| 历史阵容 | 网站已上传的「同盟战报」库 |

> **关于「点一下游戏里的队伍就弹窗」**：普通 App 拿不到游戏内的点击坐标，自动识别需要无障碍权限（敏感权限、上架受限）。
> 本版采用你确认的方案：**悬浮球 → 队伍列表 → 点一行弹队伍卡**，只需悬浮窗权限，体验接近、权限干净。

---

## 二、数据怎么进来（两种都支持）

### A. 实时流（推荐，边打边出）
1. App 里点「启动接收服务」（默认 TCP 端口 **15432**）。
2. PCAPdroid → 设置 → **流量转储 → TCP 导出器** → 填 `手机局域网IP:15432`（pcap-over-ip）。
3. 手机和抓包设备在同一 WiFi / 热点下；App 前台服务常驻接收。
4. 解析结果每 ~700ms 增量刷新到悬浮球列表。

### B. 文件导入（稳，适合 274MB 大包）
1. PCAPdroid → **流量转储 → PCAP 文件**，抓完得到 `.pcap` / `.pcapng`。
2. App 里点「导入 .pcap / .pcapng / .gz 文件」，选文件即可。
3. **流式读取**：64KB 分块喂解析器，绝不整文件进内存，274MB 不 OOM；`.gz` 自动解。

### 解析链路（与 `tools/selfcheck.py` 完全同构，可交叉验证）
```
pcap/pcapng 字节流
  → 按 linktype 取 IPv4/TCP 段（Ethernet / RAW / SLL / SLL2）
  → 四元组流重组 + seq 去重
  → 找 0x78 9c|01|da|5e 头，java.util.zip.Inflater 解压（对齐 pako 的 total_in）
  → UTF-8 文本
  → 战报对象 battle_id / attack_name → 三武将 + 战法 + 战损
  → 成员数组 [id,"名字",…,gid,"城池",…] 与三元组 [roleId,gid,"城池"] → 9 组白名单
  → server / alliance_id / 渠道码 / 会话令牌 / DNS 标签
  → TeamRepository 合并本地与云端 → 队伍卡
```

分组只认你给的 9 个：`6武陵 7天门 8桂阳 9长沙 10南 11襄阳 12南阳 13江夏 50铺路组`。
判定用**位置双校验**（gid 命中映射表 且 紧跟城池名等于映射值），家族名、玩家名、乱码一律不进分组。

---

## 三、同盟战报库（你已把战报全部上传）

App 复用网站现有 Supabase 项目，默认地址与 publishable key 已内置（与网站一致，是公开 key）。

1. 优先 `POST /rest/v1/rpc/get_my_battles`，参数 `{p_id, p_pin, p_limit}`，即网站账号的 **id + pin**。
2. RPC 不可用 / 返回空时，退回 `GET /rest/v1/{表名}?select=*&limit=1000`（默认表名 `zsm_battles`，可改）。
3. 返回的扁平行走 `BattleDecoder.battleFrom()`，与本地抓包**同一套字段适配**；若行里有 `payload` 列存原始战报 JSON，也会自动展开。
4. 解析结果缓存在 `filesDir`，离线可用。

> 账号 id / pin 在 App「⑤ 设置」里填；网站登录后 `currentUser.id` 与 `currentUser.token` 就是这两个值。
> 详细字段约定见 [docs/数据结构与接口.md](docs/数据结构与接口.md)。

---

## 四、用仓库打包（GitHub Actions）

你选的是 **GitHub Actions**。仓库已带 `.github/workflows/build.yml`：

- 触发：`push` 到 main/master、PR、打 `v*` tag、或手动 `workflow_dispatch`
- 环境：JDK 17 + Gradle 8.7 + Android SDK（setup-android）
- 步骤：生成 Gradle Wrapper → **跑解析链路自测** → `:app:assembleDebug` → 上传 APK artifact
- 打 `v1.0.0` 这类 tag 时自动发布 Release 并附上 APK

**首次使用**
```bash
git init
git add .
git commit -m "率土战情终端 v1.0"
git remote add origin https://github.com/<你的账号>/ZsmTerminal.git
git push -u origin main
```
去 Actions 页面等构建完成 → 下载 `ZsmTerminal-debug` artifact → 得到 `app-debug.apk` → 安装。

> 仓库里**不存 `gradle-wrapper.jar` 二进制**，由 CI 第一步 `gradle wrapper` 自举生成，保持仓库纯文本、可 diff。
> 本地用 Android Studio 打开时 IDE 会自动补齐 wrapper；也可手动 `gradle wrapper --gradle-version 8.7`。

**本地构建（需 Android SDK + JDK 17）**
```bash
gradle wrapper --gradle-version 8.7
./gradlew :app:assembleDebug
```

---

## 五、首次使用清单

1. 安装 APK → 打开 → 「授权悬浮窗」→ 「显示悬浮球」。
2. 「启动接收服务」（或先「导入 pcap 文件」验证）。
3. 「④ 同步同盟战报」填 id / pin，拉云端历史阵容。
4. 切到游戏 → 点悬浮球 → 队伍列表 → 点「知夏丨江东」→ 队伍卡弹出。

权限：`INTERNET` / `FOREGROUND_SERVICE` / `SYSTEM_ALERT_WINDOW` / `POST_NOTIFICATIONS`。
**不申请无障碍、不申请 VPN、不读通讯录**；抓包能力由 PCAPdroid 自己提供。

---

## 六、工程结构

```
app/src/main/java/com/zsm/terminal/
├── Models.kt            数据模型
├── Names.kt             9 组白名单 / 武将战法字典 / 队伍名归一化
├── PcapParser.kt        流式 pcap / pcapng 解析（半包、粘包、大文件）
├── ZlibScan.kt          TCP 流重组 + 增量 zlib 解压
├── BattleDecoder.kt     战报 / 分组 / 情报解析内核
├── Settings.kt          端口 / 账号 / Supabase 配置
├── SupabaseClient.kt    RPC + REST 读取同盟战报库
├── TeamRepository.kt    本地 + 云端合并、按名字出队伍卡、缓存
├── AppState.kt          服务 ↔ 界面事件总线
├── ZsmApp.kt            通知渠道
├── CaptureService.kt    前台服务：TCP 监听 / 文件导入 / 增量解析
├── OverlayManager.kt    悬浮球 → 队伍列表 → 队伍卡
├── Ui.kt                纯代码 UI 控件工厂
└── MainActivity.kt      设置与状态界面
tools/selfcheck.py       同构参考实现 + 合成 pcap 全链路自测（CI 会跑）
docs/数据结构与接口.md   数据库字段与 RPC 约定
```

技术选型：Kotlin + 平台 UI（零 Compose / 零 AppCompat 依赖），仅 OkHttp + Gson。
`minSdk 26 / targetSdk 33 / compileSdk 34`，AGP 8.5.2 + Kotlin 1.9.24。

---

## 七、已知限制

- 普通 App 无法感知游戏内点击坐标，弹窗由悬浮球列表触发；若要「点地图自动弹」需无障碍权限（上架/合规风险高）。
- 报告 TXT 受导出脚本 `t[:5000]` 截断，名字↔分组只能还原部分；**导入原始 .pcap 可补全**。本 App 直接吃 pcap，不走那个脚本。
- 云端读取依赖网站账号 id/pin 与 RPC 可见性；RPC 不存在时退回 REST 表，表名需与你们实际库一致。
- `targetSdk 33`：内部分发够用；若要上架 Google Play 需升 34 并补 `FOREGROUND_SERVICE_DATA_SYNC` 等权限。
- 武将 / 战法字典为内置常见项，未收录的 ID 显示「武将xxxx」；可后续接字典接口补全。

---

## 八、验证（三道，CI 每次构建全跑）

```bash
python3 tools/selfcheck.py        # 合成 pcap 全链路：解析→解压→战报/9组/情报→队伍卡
python3 tools/verify_project.py   # 工程静态：XML / YAML / 资源引用 / Kotlin 词法 / 常量一致性
python3 tools/verify_regex.py     # 把 Kotlin 正则抽出来，用真实解压文本验证能匹配
```

`selfcheck.py` 是 Kotlin 解析内核的 **Python 同构参考实现**：生成合成 pcap 并跑通
`pcap → 流重组 → zlib 解压 → 战报/9组/情报 → 「知夏丨江东」队伍卡（天门 / 零陵 / 甄洛+先驱突击）`。
两边共用同一套 9 组白名单、队伍名归一化与字段别名，任一处改歪都会在校验里报出来。

> 沙盒/CI 的编译分工：解析链路与工程结构在本机零依赖验证；**APK 由 GitHub Actions 用 JDK 17 + Android SDK 编译产出**。
> 工程不依赖任何二进制文件（连 `gradle-wrapper.jar` 都由 CI 自举生成）。
