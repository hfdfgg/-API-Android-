// JNI bridge: LocalApiServer.Engine <-> llama.cpp (CPU inference on Android).
// Built only with -PwithLlama=true. See native-llama/README.md.
//
// Lessons applied from PocketPal / llama.rn:
//  * KV-cache-parameter compatibility enforcement BEFORE llama_init_from_model,
//    to prevent SIGABRT ("V cache quantization requires flash_attn").
//  * Big-core CPU affinity to kill DVFS / EAS scheduling jitter ("卡" is often
//    thread migration, not raw FLOPs).
//  * PP/TG split benchmark on a throwaway context, with warmup.
//  * Memory-mapped load, independent warmup, token micro-batching,
//    GGUF-native chat template, graceful prompt truncation.

#include <jni.h>
#include <cstring>
#include <ctime>
#include <string>
#include <vector>
#include <cstdint>
#include <cstdlib>
#include <type_traits>
#include <utility>
#include <sched.h>
#include <unistd.h>
#include <dirent.h>

#include "llama.h"
#include "ggml.h"
#include <android/log.h>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "llama_jni", __VA_ARGS__)
#define SEP '\x01'

namespace {

struct EngineCtx {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    int n_threads = 0;
    int n_batch = 0;
    int n_ubatch = 0;
};

static inline EngineCtx *as_ctx(jlong h) { return reinterpret_cast<EngineCtx *>(h); }

// ---------------------------------------------------------------- CPU affinity

/** Parse "4-7" or "0,2,4" and pin the CALLING thread. ggml's worker pool is
 *  created during context init and inherits this mask. */
static void applyAffinity(const char *mask) {
    if (mask == nullptr || mask[0] == '\0') return;
    cpu_set_t set;
    CPU_ZERO(&set);
    const char *p = mask;
    while (*p) {
        int a = static_cast<int>(strtol(p, const_cast<char **>(&p), 10));
        if (*p == '-') {
            p++;
            int b = static_cast<int>(strtol(p, const_cast<char **>(&p), 10));
            for (int i = a; i <= b && i < CPU_SETSIZE; ++i) CPU_SET(i, &set);
        } else {
            if (a >= 0 && a < CPU_SETSIZE) CPU_SET(a, &set);
        }
        if (*p == ',') p++;
        else if (*p != '\0' && *p != '-') break;
    }
    if (sched_setaffinity(0, sizeof(cpu_set_t), &set) != 0) {
        LOGE("sched_setaffinity failed (non-fatal); continuing without pinning");
    }
}

// ---------------------------------------------------------------- flash-attn compat

// Some llama.cpp tags expose llama_context_params::flash_attn_type, older ones
// only flash_attn / nothing at all. Detect the member so this file compiles
// against a range of pinned tags. ENABLED is encoded as 1 upstream; if a future
// tag renumbers it, the Kotlin loader's fallback chain handles the failure.
template <typename T, typename = void>
struct has_flash_type : std::false_type {};
template <typename T>
struct has_flash_type<T, std::void_t<decltype(std::declval<T &>().flash_attn_type)>>
        : std::true_type {};

template <typename P>
static void set_flash(P &cp, bool on) {
    if constexpr (has_flash_type<P>::value) {
        cp.flash_attn_type = static_cast<decltype(cp.flash_attn_type)>(on ? 1 : 0);
    } else {
        (void) on; // older upstream: leave AUTO, K-only quantization is safe
    }
}

static ggml_type kv_type(const char *s) {
    if (s == nullptr) return GGML_TYPE_F16;
    if (std::strcmp(s, "q8_0") == 0) return GGML_TYPE_Q8_0;
    if (std::strcmp(s, "q4_0") == 0) return GGML_TYPE_Q4_0;
    return GGML_TYPE_F16;
}

// ---------------------------------------------------------------- timing / memory

static double now_ms() {
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

static long peak_rss_kb() {
    FILE *f = fopen("/proc/self/status", "r");
    if (f == nullptr) return 0;
    char line[256];
    long kb = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "VmHWM:", 6) == 0) {
            sscanf(line + 6, "%ld", &kb);
            break;
        }
    }
    fclose(f);
    return kb;
}

// ---------------------------------------------------------------- utf8 / batching

static size_t utf8_len(unsigned char c) {
    if (c < 0x80) return 1;
    if ((c & 0xE0) == 0xC0) return 2;
    if ((c & 0xF0) == 0xE0) return 3;
    if ((c & 0xF8) == 0xF0) return 4;
    return 1;
}

static void drain_utf8(std::string &pending, std::string &out, bool force) {
    size_t i = 0;
    while (i < pending.size()) {
        const size_t n = utf8_len(static_cast<unsigned char>(pending[i]));
        if (i + n > pending.size()) break;
        out.append(pending, i, n);
        i += n;
    }
    pending.erase(0, i);
    if (force && !pending.empty()) { out.append(pending); pending.clear(); }
}

static bool emit(JNIEnv *env, jobject sink, jmethodID mid, std::string &out) {
    if (out.empty()) return true;
    jstring js = env->NewStringUTF(out.c_str());
    out.clear();
    if (js == nullptr) return false;
    env->CallVoidMethod(sink, mid, js);
    env->DeleteLocalRef(js);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
    return true;
}

static std::vector<llama_token> tokenize(const llama_vocab *vocab,
                                         const char *text, bool add_special) {
    const int32_t len = static_cast<int32_t>(std::strlen(text));
    std::vector<llama_token> out(static_cast<size_t>(len) + 16);
    int32_t n = llama_tokenize(vocab, text, len, out.data(),
                               static_cast<int32_t>(out.size()), add_special, true);
    if (n < 0) {
        out.resize(static_cast<size_t>(-n));
        n = llama_tokenize(vocab, text, len, out.data(),
                           static_cast<int32_t>(out.size()), add_special, true);
    }
    if (n < 0) return {};
    out.resize(static_cast<size_t>(n));
    return out;
}

static bool decode_with_positions(llama_context *ctx,
                                  const std::vector<llama_token> &tokens,
                                  llama_pos start_pos) {
    if (tokens.empty()) return true;
    std::vector<llama_pos> pos(tokens.size());
    for (size_t i = 0; i < tokens.size(); ++i)
        pos[i] = static_cast<llama_pos>(start_pos + static_cast<llama_pos>(i));
    llama_batch b = llama_batch_get_one(tokens.data(), static_cast<int32_t>(tokens.size()));
    b.pos = pos.data();
    return llama_decode(ctx, b) == 0;
}

/** Split "role SEP content SEP ..." into llama_chat_message[]. Copies into
 *  stable storage BEFORE taking c_str() (vector growth would dangle). */
static std::vector<llama_chat_message> parse_chat(const std::string &flat,
                                                  std::vector<std::string> &storage) {
    size_t start = 0;
    while (true) {
        size_t p = flat.find(SEP, start);
        if (p == std::string::npos) break;
        storage.push_back(flat.substr(start, p - start));
        start = p + 1;
    }
    std::vector<llama_chat_message> msgs;
    for (size_t i = 0; i + 1 < storage.size(); i += 2) {
        llama_chat_message m;
        m.role = storage[i].c_str();
        m.content = storage[i + 1].c_str();
        msgs.push_back(m);
    }
    return msgs;
}

static llama_context_params base_params(EngineCtx *c, int n_ctx) {
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = n_ctx;
    cp.n_threads = c->n_threads;
    cp.n_threads_batch = c->n_threads;
    cp.n_batch = c->n_batch;
    cp.n_ubatch = c->n_ubatch;
    return cp;
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeLoad(
        JNIEnv *env, jobject, jstring jpath, jint threads, jint n_ctx,
        jstring jkvK, jstring jkvV, jint n_batch, jint n_ubatch,
        jboolean jflash, jstring jaff) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    const char *kK = env->GetStringUTFChars(jkvK, nullptr);
    const char *kV = env->GetStringUTFChars(jkvV, nullptr);
    const char *aff = env->GetStringUTFChars(jaff, nullptr);
    if (path == nullptr || kK == nullptr || kV == nullptr) return 0;

    // Pin BEFORE context creation so ggml worker threads inherit the mask.
    if (aff != nullptr) applyAffinity(aff);

    ggml_type typeK = kv_type(kK);
    ggml_type typeV = kv_type(kV);
    bool flash = jflash == JNI_TRUE;

    // HARD GUARD: llama.cpp aborts (SIGABRT) when V is quantized without flash.
    // Even if the Kotlin validator misses it, never let it reach init.
    if (typeV != GGML_TYPE_F16 && !flash) {
        LOGE("V-cache quantization without flash-attn would abort; forcing V=F16");
        typeV = GGML_TYPE_F16;
    }

    env->ReleaseStringUTFChars(jkvK, kK);
    env->ReleaseStringUTFChars(jkvV, kV);
    if (aff != nullptr) env->ReleaseStringUTFChars(jaff, aff);

    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;    // CPU-only: portable across every phone
    mp.use_mmap = true;     // never copy a multi-GB model into RAM

    llama_model *model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (model == nullptr) {
        LOGE("llama_model_load_from_file failed");
        llama_backend_free();
        return 0;
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = n_ctx;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    cp.n_batch = n_batch;
    cp.n_ubatch = n_ubatch;
    cp.type_k = typeK;      // K-only quantization: main decode bandwidth win
    cp.type_v = typeV;      // kept F16 unless flash is provably on
    set_flash(cp, flash);

    llama_context *ctx = llama_init_from_model(model, cp);
    if (ctx == nullptr) {
        LOGE("llama_init_from_model failed");
        llama_model_free(model);
        llama_backend_free();
        return 0;
    }

    auto *c = new EngineCtx();
    c->model = model; c->ctx = ctx;
    c->vocab = llama_model_get_vocab(model);
    c->n_ctx = n_ctx; c->n_threads = threads;
    c->n_batch = n_batch; c->n_ubatch = n_ubatch;
    return reinterpret_cast<jlong>(c);
}

JNIEXPORT void JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeWarmup(
        JNIEnv *, jobject, jlong handle) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->model == nullptr || c->vocab == nullptr) return;
    llama_context_params wp = base_params(c, 32);
    wp.type_k = GGML_TYPE_F16;
    wp.type_v = GGML_TYPE_F16;
    llama_context *wctx = llama_init_from_model(c->model, wp);
    if (wctx == nullptr) return;
    auto toks = tokenize(c->vocab, "Hello", true);
    decode_with_positions(wctx, toks, 0);
    llama_free(wctx);
}

JNIEXPORT jstring JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeRenderChat(
        JNIEnv *env, jobject, jlong handle, jstring jflat) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->model == nullptr || jflat == nullptr) return nullptr;
    const char *raw = env->GetStringUTFChars(jflat, nullptr);
    if (raw == nullptr) return nullptr;
    std::string flat(raw);
    env->ReleaseStringUTFChars(jflat, raw);

    const char *tmpl = llama_model_chat_template(c->model, nullptr);
    if (tmpl == nullptr || tmpl[0] == '\0') return nullptr;
    std::vector<std::string> storage;
    auto msgs = parse_chat(flat, storage);
    if (msgs.empty()) return nullptr;

    char probe[8] = {0};
    int32_t need = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(),
                                             true, probe, sizeof(probe));
    if (need <= 0) return nullptr;
    std::vector<char> buf(static_cast<size_t>(need) + 16);
    int32_t n = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true,
                                          buf.data(), static_cast<int32_t>(buf.size()));
    if (n < 0 || n >= static_cast<int32_t>(buf.size())) return nullptr;
    buf[static_cast<size_t>(n)] = '\0';
    return env->NewStringUTF(buf.data());
}

JNIEXPORT void JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeFree(
        JNIEnv *, jobject, jlong handle) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr) return;
    if (c->ctx) llama_free(c->ctx);
    if (c->model) llama_model_free(c->model);
    llama_backend_free();
    delete c;
}

JNIEXPORT jint JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeTokenCount(
        JNIEnv *env, jobject, jlong handle, jstring jtext) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->vocab == nullptr || jtext == nullptr) return 0;
    const char *text = env->GetStringUTFChars(jtext, nullptr);
    if (text == nullptr) return 0;
    auto tokens = tokenize(c->vocab, text, true);
    env->ReleaseStringUTFChars(jtext, text);
    return static_cast<jint>(tokens.size());
}

/**
 * PP/TG split benchmark, modelled on llama.cpp's llama-bench (which PocketPal
 * uses): random token IDs, 16-token warmup, one batch decode for PP, then TG
 * single-token decodes. Runs on a THROWAWAY context so the live KV is untouched.
 * Returns "ppTps|tgTps|peakMb".
 */
JNIEXPORT jstring JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeBenchmark(
        JNIEnv *env, jobject, jlong handle, jint pp, jint tg, jint warmup) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->model == nullptr || c->vocab == nullptr) return nullptr;

    pp = pp < 8 ? 8 : (pp > 4096 ? 4096 : pp);
    tg = tg < 8 ? 8 : (tg > 2048 ? 2048 : tg);
    warmup = warmup < 0 ? 0 : (warmup > 128 ? 128 : warmup);

    // Token IDs 1..64 exist in essentially every GGUF vocab. Avoids any
    // version-specific vocab-size API and keeps the benchmark comparable.
    auto rnd = [](int i) -> llama_token {
        return static_cast<llama_token>(1 + (static_cast<uint32_t>(i) * 2654435761u & 63u));
    };

    // Warmup on a SEPARATE tiny context so it cannot occupy the benchmark KV
    // or collide with prompt positions.
    if (warmup > 0) {
        llama_context_params wp = base_params(c, warmup + 16);
        wp.n_batch = warmup + 8;
        wp.n_ubatch = warmup + 8;
        wp.type_k = GGML_TYPE_F16;
        wp.type_v = GGML_TYPE_F16;
        llama_context *wctx = llama_init_from_model(c->model, wp);
        if (wctx != nullptr) {
            std::vector<llama_token> w(static_cast<size_t>(warmup));
            for (int i = 0; i < warmup; ++i) w[static_cast<size_t>(i)] = rnd(i);
            decode_with_positions(wctx, w, 0);
            llama_free(wctx);
        }
    }

    llama_context_params bp = base_params(c, pp + tg + 64);
    bp.n_batch = pp + 8;
    bp.n_ubatch = pp + 8;
    bp.type_k = GGML_TYPE_F16;   // comparable across runs, zero compat risk
    bp.type_v = GGML_TYPE_F16;
    llama_context *bctx = llama_init_from_model(c->model, bp);
    if (bctx == nullptr) return nullptr;

    // Phase 1: prompt processing (one batched decode)
    std::vector<llama_token> prompt(static_cast<size_t>(pp));
    for (int i = 0; i < pp; ++i) prompt[static_cast<size_t>(i)] = rnd(i + 1000);
    double t0 = now_ms();
    bool ok = decode_with_positions(bctx, prompt, 0);
    double pp_ms = now_ms() - t0;

    // Phase 2: token generation (sequential single-token decodes)
    double tg_ms = 0.0;
    if (ok) {
        for (int i = 0; i < tg; ++i) {
            llama_token t = rnd(i + 5000);
            llama_pos pos = static_cast<llama_pos>(pp + i);
            llama_batch b = llama_batch_get_one(&t, 1);
            b.pos = &pos;
            double s = now_ms();
            if (llama_decode(bctx, b) != 0) { ok = false; break; }
            tg_ms += now_ms() - s;
        }
    }

    long peakMb = peak_rss_kb() / 1024;
    llama_free(bctx);
    if (!ok || pp_ms <= 0 || tg_ms <= 0) return nullptr;

    char buf[128];
    snprintf(buf, sizeof(buf), "%.2f|%.2f|%ld",
             pp * 1000.0 / pp_ms, tg * 1000.0 / tg_ms, peakMb);
    return env->NewStringUTF(buf);
}

JNIEXPORT jint JNICALL
Java_com_yuanbao_localmodel_engine_LlamaCppEngine_nativeGenerate(
        JNIEnv *env, jobject, jlong handle, jstring jprompt,
        jint max_tokens, jfloat temperature, jfloat top_p,
        jint jni_batch, jobject sink) {
    EngineCtx *c = as_ctx(handle);
    if (c == nullptr || c->ctx == nullptr || c->vocab == nullptr || sink == nullptr) return 0;

    jclass sink_cls = env->GetObjectClass(sink);
    jmethodID on_token = env->GetMethodID(sink_cls, "onToken", "(Ljava/lang/String;)V");
    env->DeleteLocalRef(sink_cls);
    if (on_token == nullptr) return 0;

    const char *prompt = env->GetStringUTFChars(jprompt, nullptr);
    if (prompt == nullptr) return 0;
    auto tokens = tokenize(c->vocab, prompt, true);
    env->ReleaseStringUTFChars(jprompt, prompt);
    if (tokens.empty()) return 0;

    // Context-shift style truncation: keep BOS + the most recent turns instead
    // of returning an empty answer when the conversation outgrows n_ctx.
    const int reserve = max_tokens > 0 ? max_tokens : 256;
    const int budget = c->n_ctx - reserve - 8;
    if (static_cast<int>(tokens.size()) > budget) {
        std::vector<llama_token> kept;
        kept.push_back(tokens.front());                       // BOS / special
        int take = budget - 1;
        if (take > 0) {
            size_t from = tokens.size() - static_cast<size_t>(take);
            kept.insert(kept.end(), tokens.begin() + from, tokens.end());
        }
        tokens.swap(kept);
        LOGE("prompt truncated to fit n_ctx=%d", c->n_ctx);
    }
    if (!decode_with_positions(c->ctx, tokens, 0)) {
        LOGE("prefill decode failed");
        return 0;
    }

    llama_sampler *sp = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temperature <= 0.0f) {
        llama_sampler_chain_add(sp, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(sp, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(sp, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(sp, llama_sampler_init_dist(
                static_cast<uint32_t>(std::time(nullptr))));
    }

    const int batch_n = jni_batch > 0 ? jni_batch : 6;
    llama_pos pos = static_cast<llama_pos>(tokens.size());
    std::string pending, outgoing;
    int since_emit = 0;
    int generated = 0;

    for (int i = 0; i < max_tokens; ++i) {
        llama_token id = llama_sampler_sample(sp, c->ctx, -1);
        llama_sampler_accept(sp, id);
        if (llama_vocab_is_eog(c->vocab, id)) break;

        std::vector<char> piece(32);
        int32_t n = llama_token_to_piece(c->vocab, id, piece.data(),
                                         static_cast<int32_t>(piece.size()), 0, true);
        if (n < 0) {
            piece.resize(static_cast<size_t>(-n));
            n = llama_token_to_piece(c->vocab, id, piece.data(),
                                     static_cast<int32_t>(piece.size()), 0, true);
        }
        if (n > 0) pending.append(piece.data(), static_cast<size_t>(n));
        drain_utf8(pending, outgoing, false);
        ++generated;
        ++since_emit;

        if (since_emit >= batch_n || outgoing.size() >= 48) {
            if (!emit(env, sink, on_token, outgoing)) break;
            since_emit = 0;
        }

        llama_token next = id;
        llama_pos step_pos = pos;
        llama_batch step = llama_batch_get_one(&next, 1);
        step.pos = &step_pos;
        if (llama_decode(c->ctx, step) != 0) break;
        ++pos;
        if (pos >= c->n_ctx) break;
    }

    drain_utf8(pending, outgoing, true);
    emit(env, sink, on_token, outgoing);
    llama_sampler_free(sp);
    return generated;
}

} // extern "C"
