#!/usr/bin/env bash
# Put the official, statically-linked cloudflared binary inside the APK so it
# lands in nativeLibraryDir with the executable bit intact (Android 10+ W^X).
#
#   ./scripts/prepare-tunnel-binary.sh                 # arm64-v8a (modern phones)
#   ./scripts/prepare-tunnel-binary.sh armeabi-v7a   # older 32-bit ARM phones
#   ./scripts/prepare-tunnel-binary.sh x86_64        # emulator
#
# The file is written to app/src/main/jniLibs/ which is git-ignored on purpose:
# CI regenerates it on every build, never commit a 40 MB binary.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ABI="${1:-arm64-v8a}"
case "$ABI" in
  arm64-v8a)    ASSET="cloudflared-linux-arm64" ;;
  armeabi-v7a)  ASSET="cloudflared-linux-arm" ;;
  x86_64)       ASSET="cloudflared-linux-amd64" ;;
  *) echo "unsupported ABI: $ABI" >&2; exit 2 ;;
esac

DEST_DIR="$ROOT/app/src/main/jniLibs/$ABI"
DEST="$DEST_DIR/libcloudflared.so"
# GitHub release assets are reachable from GitHub-hosted runners. If your
# network blocks them, point this at any mirror holding the same static binary:
#   CLOUDFLARED_URL=https://your-mirror/cloudflared-linux-arm64 ./scripts/prepare-tunnel-binary.sh
URL="${CLOUDFLARED_URL:-https://github.com/cloudflare/cloudflared/releases/latest/download/$ASSET}"

mkdir -p "$DEST_DIR"
echo "[*] downloading $ASSET"
curl -fL --retry 3 --connect-timeout 20 --max-time 180 \
     -A "LocalModelAPI/1.0" -o "$DEST.tmp" "$URL"

SIZE=$(stat -c%s "$DEST.tmp" 2>/dev/null || stat -f%z "$DEST.tmp")
if [ "$SIZE" -lt 1000000 ]; then
  echo "[!] suspicious size: $SIZE bytes" >&2
  rm -f "$DEST.tmp"
  exit 1
fi

# ELF magic check: 0x7f 'E' 'L' 'F'
MAGIC=$(od -An -tx1 -N4 "$DEST.tmp" | tr -d ' \n')
if [ "$MAGIC" != "7f454c46" ]; then
  echo "[!] not an ELF binary (got $MAGIC); release asset may have changed" >&2
  rm -f "$DEST.tmp"
  exit 1
fi

mv "$DEST.tmp" "$DEST"
chmod 755 "$DEST"
echo "[✓] $DEST ($(( SIZE / 1024 / 1024 )) MB)"
echo "    Build the APK now: ./gradlew assembleDebug"
echo "    In the app choose 公网访问 → Quick 隧道 / 命名隧道."
