#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
End-to-end protocol verification for LocalApiServer.

It boots the EXACT Java source shipped in the Android app on a plain JVM,
then drives it over real TCP with curl-equivalent requests. No mocks.

    python3 scripts/verify-protocol.py
    python3 scripts/verify-protocol.py --report VERIFY_REPORT.md

Exit code 0 = every assertion passed.
"""
import argparse
import http.client
import json
import os
import socket
import subprocess
import sys
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SERVER = os.path.join(
    ROOT, "app", "src", "main", "java", "com", "yuanbao", "localmodel", "server", "LocalApiServer.java"
)
KEY = "lm_verify_" + "a1b2c3d4e5f6" * 3
MODEL = "qwen2.5-3b-instruct-q4_k_m"


class Colors:
    G = "\033[32m"
    R = "\033[31m"
    Y = "\033[33m"
    N = "\033[0m"


class Results:
    def __init__(self):
        self.rows = []

    def check(self, name, ok, detail=""):
        self.rows.append((name, bool(ok), detail))
        mark = "PASS" if ok else "FAIL"
        color = Colors.G if ok else Colors.R
        print("%s[%s]%s %-46s %s" % (color, mark, Colors.N, name, detail))
        return ok

    @property
    def failed(self):
        return [r for r in self.rows if not r[1]]


class JvmServer:
    def __init__(self, port, rpm=120, extra=None):
        self.port = port
        self.rpm = rpm
        self.extra = extra or []
        self.proc = None
        self.stdout = []

    def start(self):
        cmd = ["java", SERVER, "--port", str(self.port), "--key", KEY,
               "--model", MODEL, "--rpm", str(self.rpm), "--fast"] + self.extra
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     cwd=ROOT, bufsize=1, universal_newlines=True)
        deadline = time.time() + 40
        while time.time() < deadline:
            line = self.proc.stdout.readline()
            if not line:
                if self.proc.poll() is not None:
                    raise RuntimeError("JVM exited early: " + "".join(self.stdout))
                continue
            self.stdout.append(line)
            if line.strip() == "READY":
                # drain remaining output in background so the pipe never fills
                threading.Thread(target=self._drain, daemon=True).start()
                return self
        raise RuntimeError("server did not become READY in 40s")

    def _drain(self):
        for line in self.proc.stdout:
            self.stdout.append(line)

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()

    def __enter__(self):
        return self.start()

    def __exit__(self, *a):
        self.stop()


def req(port, method, path, body=None, headers=None, timeout=15):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=timeout)
    h = dict(headers or {})
    if body is not None and "Content-Type" not in h:
        h["Content-Type"] = "application/json"
    c.request(method, path, body=body, headers=h)
    r = c.getresponse()
    data = r.read()
    out = (r.status, dict((k.lower(), v) for k, v in r.getheaders()), data)
    c.close()
    return out


def auth():
    return {"Authorization": "Bearer " + KEY}


def jbody(obj):
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


def raw_socket(port, raw: bytes, first_byte_timeout=3.0):
    """Send raw bytes, return (status_line, headers, time-to-first-byte, rest)."""
    s = socket.create_connection(("127.0.0.1", port), timeout=5)
    s.settimeout(first_byte_timeout)
    s.sendall(raw)
    t0 = time.time()
    buf = b""
    ttfb = None
    while b"\r\n\r\n" not in buf:
        chunk = s.recv(4096)
        if not chunk:
            break
        if ttfb is None:
            ttfb = (time.time() - t0) * 1000
        buf += chunk
    head, _, rest = buf.partition(b"\r\n\r\n")
    s.settimeout(5)
    try:
        while True:
            chunk = s.recv(4096)
            if not chunk:
                break
            rest += chunk
    except socket.timeout:
        pass
    s.close()
    lines = head.decode("iso-8859-1").split("\r\n")
    return lines[0] if lines else "", lines[1:], ttfb, rest


def decode_chunked(data: bytes) -> bytes:
    out = b""
    i = 0
    while i < len(data):
        j = data.find(b"\r\n", i)
        if j < 0:
            break
        try:
            n = int(data[i:j].split(b";")[0], 16)
        except ValueError:
            break
        if n == 0:
            break
        out += data[j + 2:j + 2 + n]
        i = j + 2 + n + 2
    return out


def run(res: Results):
    port = 18181
    with JvmServer(port) as srv:
        # ---- 1. health / docs -------------------------------------------------
        st, h, b = req(port, "GET", "/health")
        j = json.loads(b)
        res.check("GET /health 200 + model", st == 200 and j.get("model") == MODEL,
                  "status=%s model=%s" % (st, j.get("model")))
        res.check("security headers present",
                  h.get("x-content-type-options") == "nosniff" and h.get("x-frame-options") == "DENY")

        st, h, b = req(port, "GET", "/")
        html = b.decode("utf-8", "replace")
        res.check("GET / docs page (mobile viewport)",
                  st == 200 and "viewport" in html and "text/html" in h.get("content-type", ""))
        res.check("docs page never leaks API key", KEY not in html)

        # ---- 2. auth ----------------------------------------------------------
        st, h, b = req(port, "GET", "/v1/models")
        res.check("missing key -> 401", st == 401 and json.loads(b)["error"]["code"] == "invalid_api_key",
                  "status=%s" % st)
        res.check("401 carries WWW-Authenticate", "bearer" in h.get("www-authenticate", "").lower())

        st, _, b = req(port, "GET", "/v1/models", headers={"Authorization": "Bearer wrong-key"})
        res.check("wrong key -> 401", st == 401)

        st, _, b = req(port, "GET", "/v1/models", headers={"X-API-Key": KEY})
        res.check("X-API-Key alternative header", st == 200)

        st, _, b = req(port, "GET", "/v1/models", headers=auth())
        j = json.loads(b)
        res.check("GET /v1/models OpenAI shape",
                  st == 200 and j.get("object") == "list" and j["data"][0]["id"] == MODEL)

        # ---- 3. non-streaming chat -------------------------------------------
        payload = {"model": MODEL, "messages": [{"role": "user", "content": "用一句话介绍你自己"}],
                   "max_tokens": 64, "temperature": 0.7}
        t0 = time.time()
        st, h, b = req(port, "POST", "/v1/chat/completions", jbody(payload), auth())
        elapsed = (time.time() - t0) * 1000
        j = json.loads(b)
        ok = (st == 200 and j["object"] == "chat.completion"
              and j["choices"][0]["message"]["role"] == "assistant"
              and len(j["choices"][0]["message"]["content"]) > 10
              and "usage" in j and "local_timings" in j)
        res.check("POST /v1/chat/completions 200", ok, "%.0fms tps=%s" %
                  (elapsed, j.get("local_timings", {}).get("tokens_per_second")))
        res.check("response Content-Type json utf-8", "application/json" in h.get("content-type", ""))

        # ---- 4. legacy completions -------------------------------------------
        st, _, b = req(port, "POST", "/v1/completions", jbody({"prompt": "你好", "max_tokens": 32}), auth())
        j = json.loads(b)
        res.check("POST /v1/completions text_completion",
                  st == 200 and j["object"] == "text_completion")

        # ---- 5. SSE streaming --------------------------------------------------
        sse_body = jbody({"model": MODEL, "messages": [{"role": "user", "content": "流式测试"}],
                          "stream": True, "max_tokens": 48})
        raw = (b"POST /v1/chat/completions HTTP/1.1\r\nHost: 127.0.0.1\r\n"
               b"Authorization: Bearer " + KEY.encode() + b"\r\n"
               b"Content-Type: application/json\r\nConnection: close\r\n"
               b"Content-Length: " + str(len(sse_body)).encode() + b"\r\n\r\n" + sse_body)
        status_line, headers, ttfb, rest = raw_socket(port, raw)
        payload_bytes = decode_chunked(rest)
        text = payload_bytes.decode("utf-8", "replace")
        events = [ln[6:] for ln in text.splitlines() if ln.startswith("data: ")]
        chunk_objs = []
        for e in events:
            if e.strip() == "[DONE]":
                continue
            try:
                chunk_objs.append(json.loads(e))
            except ValueError:
                pass
        has_done = any(ln.strip() == "data: [DONE]" for ln in text.splitlines())
        res.check("SSE 200 + text/event-stream",
                  "200" in status_line and any("text/event-stream" in x.lower() for x in headers))
        res.check("SSE chunked stream (multiple deltas)", len(chunk_objs) >= 5,
                  "%d chunks" % len(chunk_objs))
        res.check("SSE first delta / [DONE] / finish_reason",
                  chunk_objs and chunk_objs[0]["object"] == "chat.completion.chunk"
                  and has_done and any(c["choices"][0]["finish_reason"] == "stop" for c in chunk_objs))
        res.check("SSE carries usage + local_timings",
                  any("usage" in c and "local_timings" in c for c in chunk_objs))
        gen_tokens = max((c.get("usage", {}).get("completion_tokens", 0)
                          for c in chunk_objs), default=0)
        res.check("SSE 微批合并（chunk 数 < 真实 token 数）",
                  gen_tokens > 0 and len(chunk_objs) < gen_tokens,
                  "%d chunks / %d tokens" % (len(chunk_objs), gen_tokens))
        res.check("usage.completion_tokens 为真实生成数", gen_tokens >= 40,
                  "%d tokens" % gen_tokens)
        res.check("SSE time-to-first-byte < 500ms", ttfb is not None and ttfb < 500,
                  "%.1fms" % (ttfb or -1))

        # ---- 6. CORS / errors --------------------------------------------------
        st, h, _ = req(port, "OPTIONS", "/v1/chat/completions",
                       headers={"Origin": "https://example.com"})
        res.check("OPTIONS CORS preflight 204", st == 204
                  and h.get("access-control-allow-origin") == "https://example.com")

        st, _, b = req(port, "GET", "/v1/nope", headers=auth())
        res.check("unknown route -> structured 404",
                  st == 404 and json.loads(b)["error"]["code"] == "not_found")

        st, _, b = req(port, "POST", "/v1/chat/completions", b"{not json", auth())
        res.check("invalid JSON -> 400",
                  st == 400 and json.loads(b)["error"]["code"] == "invalid_json")

        st, _, b = req(port, "POST", "/v1/chat/completions", jbody({"messages": []}), auth())
        res.check("empty messages -> 400", st == 400)

        # 413 declared but body not fully sent: server must reject before reading it
        big = b'POST /v1/chat/completions HTTP/1.1\r\nHost: 127.0.0.1\r\nAuthorization: Bearer ' \
              + KEY.encode() + b'\r\nContent-Type: application/json\r\n' \
              + b'Content-Length: 2000000\r\nConnection: close\r\n\r\n' + b'{"a":'
        try:
            status_line, _, _, _ = raw_socket(port, big, first_byte_timeout=3.0)
            res.check("oversized body -> 413", "413" in status_line, status_line)
        except Exception as e:
            res.check("oversized body -> 413", False, str(e))

        # ---- 6b. benchmark route (PocketPal-style PP/TG) ----------------------
        st, _, b = req(port, "POST", "/v1/benchmark", jbody({"pp": 64, "tg": 32}))
        res.check("benchmark 未鉴权 -> 401", st == 401)

        st, _, b = req(port, "POST", "/v1/benchmark",
                       jbody({"pp": 64, "tg": 32}), auth())
        j = json.loads(b)
        res.check("benchmark 无原生槽位 -> 结构化 501",
                  st == 501 and j["error"]["code"] == "benchmark_unavailable",
                  "status=%s" % st)

        # ---- 7. keep-alive reuse ----------------------------------------------
        c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
        c.request("GET", "/health")
        r1 = c.getresponse(); r1.read()
        c.request("GET", "/v1/models", headers=auth())
        r2 = c.getresponse(); r2.read()
        res.check("HTTP keep-alive connection reuse", r1.status == 200 and r2.status == 200)
        c.close()

        # ---- 8. concurrency ----------------------------------------------------
        out = [None] * 8
        def worker(i):
            st, _, b = req(port, "POST", "/v1/chat/completions",
                           jbody({"messages": [{"role": "user", "content": "并发%d" % i}],
                                  "max_tokens": 24}), auth(), timeout=25)
            out[i] = st
        ts = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        res.check("8 concurrent requests all 200", all(x == 200 for x in out),
                  "statuses=%s" % out)

        # ---- 9. no secret in logs ----------------------------------------------
        logs = "".join(srv.stdout)
        res.check("API key never written to logs", KEY not in logs)

    # ---- 10. rate limiting (separate low-limit instance) ----------------------
    with JvmServer(18182, rpm=3) as s2:
        codes = []
        for _ in range(5):
            st, _, _ = req(18182, "GET", "/v1/models", headers=auth())
            codes.append(st)
        res.check("per-key rate limit -> 429", codes[:3] == [200, 200, 200] and 429 in codes,
                  "codes=%s" % codes)

    # ---- 11. benchmark with a stub hook (Android supplies the real one) -------
    with JvmServer(18183, extra=["--fake-bench"]) as s3:
        st, _, b = req(18183, "POST", "/v1/benchmark",
                       jbody({"pp": 512, "tg": 128, "warmup": 16}), auth(), timeout=20)
        j = json.loads(b)
        res.check("benchmark 200 + PP/TG/峰值字段",
                  st == 200 and j.get("supported") is True
                  and j.get("pp_tps", 0) > 0 and j.get("tg_tps", 0) > 0
                  and j.get("peak_mb", 0) > 0,
                  "PP=%s TG=%s" % (j.get("pp_tps"), j.get("tg_tps")))
        res.check("benchmark 参数回显", "pp=512" in j.get("note", ""),
                  j.get("note", ""))
        st, _, b = req(18183, "POST", "/v1/benchmark",
                       jbody({"pp": 99999, "tg": 1}), auth(), timeout=20)
        j = json.loads(b)
        res.check("benchmark 参数被 clamp 到安全区间",
                  st == 200 and "pp=4096" in j.get("note", "") and "tg=8" in j.get("note", ""),
                  j.get("note", ""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", default=None, help="write a Markdown verification report")
    args = ap.parse_args()
    if not os.path.isfile(SERVER):
        print("missing " + SERVER); sys.exit(2)
    res = Results()
    print("\n=== Local LLM API / end-to-end protocol verification ===\n")
    t0 = time.time()
    run(res)
    dur = time.time() - t0
    print("\n%d checks, %d failed, %.1fs\n" % (len(res.rows), len(res.failed), dur))
    if args.report:
        lines = ["# 端到端验证报告", "",
                 "生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S %Z"),
                 "", "验证对象：`app/src/main/java/.../LocalApiServer.java`（与 Android APK 内同一份源码）",
                 "", "方式：真实启动 JVM 服务，通过 TCP 发起 HTTP/SSE 请求，无 mock。", "",
                 "| 检查项 | 结果 | 说明 |", "| --- | --- | --- |"]
        for name, ok, detail in res.rows:
            lines.append("| %s | %s | %s |" % (name.replace("|", "\\|"),
                                                "✅ PASS" if ok else "❌ FAIL",
                                                str(detail).replace("|", "\\|")))
        lines += ["", "**合计：%d 项，失败 %d 项，耗时 %.1fs。**" % (len(res.rows), len(res.failed), dur), ""]
        with open(args.report, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print("report -> " + args.report)
    sys.exit(1 if res.failed else 0)


if __name__ == "__main__":
    main()
