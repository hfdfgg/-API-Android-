# 本地模型 API（Android）

把 GGUF 量化模型放进手机，在设备本地推理，并对外暴露一个 **OpenAI 兼容、带密钥、走 HTTPS 公网** 的 API。复制地址和 API Key，就能在任何地方用 `curl`、OpenAI SDK、自己的程序调用这台手机。

```
你的手机                                    公网
┌───────────────────────────┐        ┌──────────────────┐
│ GGUF 模型 (app 私有目录)   │        │ Cloudflare 边缘   │
│   ↓                       │        │   HTTPS + WAF    │
│ llama.cpp CPU 推理        │        │        ↑         │
│   ↓ 逐 token 回调         │        │   cloudflared    │
│ LocalApiServer            │◄───────│   tunnel         │
│   127.0.0.1:8080          │  仅回环 │        ↑         │
│   Bearer Key / 限流 / SSE │        │  外部客户端      │
└───────────────────────────┘        └──────────────────┘
```

> **验证状态（请先看）**
> ✅ 服务端协议层已在本仓库真实启动并跑通 **33 项端到端检查**，工程一致性 **42 项**（含 v2/v3 全部防回归约束），报告见 `VERIFY_REPORT.md`。
> ⚠️ **真机端侧 GGUF 推理**、**真机公网连通**这两段需要在你的手机上验证：我这里没有 Android 设备，也没有你的 Cloudflare 域名 / Token。文档给出了逐步操作与自检命令。
> 本仓库不含任何真实密钥、模型文件或签名证书。

---

## 〇、v3：照着 PocketPal 重学了一遍

对照 `a-ghorbani/pocketpal-ai` 的四层架构（UI → 桥接 → 引擎 → 硬件）与 `llama.rn` 的参数体系，发现我们之前漏掉的**不是「再调快一点」，而是几个会真闪退 / 真卡顿**的结构问题：

| PocketPal 的做法 | 我们 v2 的问题 | v3 落地 |
| --- | --- | --- |
| 参数兼容校验，防 `SIGSEGV/SIGABRT` | **同时量化 K 和 V，却没开 FlashAttn** —— llama.cpp 遇到「V 量化 + 无 FA」会在加载时直接 abort | K/V 分离，V 恒为 F16；`ParamValidator` + JNI 硬兜底；加载失败按 3 档自动降级重试 |
| `activeModelService` 单例 + mutex | 多个 `/v1/chat/completions` 并发 decode **同一个 llama_context**（非线程安全）→ 崩溃/乱码 | `ModelSlot` 单例 + `ReentrantLock`，`Serialized` 引擎把生成串行化 |
| 切模型只换 context，不重建整栈 | 切模型 = 重启服务 = 隧道重连、地址/Key 全变、肉眼可见的「卡一下」 | `ACTION_SWAP_MODEL` 热切换：`server.setEngine()`，端口/Key/公网地址全不动 |
| 内存优先加载：`size×1.5` vs `60% RAM` | 直接硬加载，大模型 OOM 被系统杀 | `MemoryAdvisor` 预检 + 机型分档建议，超预算直接阻止并给换模型建议 |
| Auto Offload / Load | 一直持 1 小时 WakeLock + 模型常驻 → 后台被杀、耗电 | 后台自动卸载 context（服务仍在线），回前台自动重载；唤醒锁**只在推理期间**持有 |
| Benchmark：PP 512 / TG 128 / 16-token 预热 / 3 次平均 | 只有笼统的 `tok/s`，用户说「卡」没法量化 | `/v1/benchmark` + 控制台「基准测试」：PP、TG、峰值内存、评级（≥10 流畅 / <2 很慢） |
| OpenCL/Metal/NPU 优雅回退、参数预设 | 三档策略写死 | 保留三档，新增 K/V/Flash 组合校验与失败降级；诚实说明 Android GPU 只快 20–40%，瓶颈在内存带宽 |
| GenerationService 独立于 UI 生命周期 | v2 已修（appScope） | 保留并补静态防回归 |
| 绑大核 / 预升频治 DVFS 抖动 | 线程被 EAS 丢到小核、频率爬升滞后 → 首 token 忽快忽慢 | JNI `sched_setaffinity` 绑最高频核心；输入框触发 3 秒节流的预升频 |
| 屏幕常驻只在推理时 | 一直常亮 | 跟随 `GenerateLifecycle` 精细开关 |
| 日志/状态高频刷新 | 每行日志 emit 一个 200 项新 List → 整页重组 | `LogBus` 100ms 批量合并 |

**最诚实的一条**：公开数据表明 Android 上 GPU 加速对「吐字」只快 20–40%，decode 瓶颈是内存带宽；MNN / LiteRT-LM 的 CPU 路径往往更快。所以 v3 没吹「开 GPU 就飞」，而是把**不崩、不抖、不重启、不 OOM、能量化**这几件真正影响体感的事做完。

---

## 〇（续）、v2 修复清单（对应真机截图）

截图里 `Qwen2.5-1.5B-Q4_K_M` 已成功加载（`engine=LlamaCppEngine`），但一次流式对话花了 **46621ms**，随后报 `对话失败：The coroutine scope left the composition`。逐条修：

| # | 你的要求 | 真因 | 修复 |
| --- | --- | --- | --- |
| 1 | 模型跑得慢 | 默认 `max_tokens=512`；每 token 一次 JNI 回调 + 一次 SSE 写/flush；KV cache 用 F16 吃满内存带宽；首次推理缺页 | **加速器**：KV `q8_0` 量化、独立 context 预热、JNI 微批 6 token、SSE 微批 4 token/24ms、APP 默认 256 token、大核数自适应线程、三档性能策略 |
| 2 | 兼容性 / 加载性 / 流畅性 | 手写 chatml 模板只适配部分模型；单模型单文件；加载失败直接伪装成自检输出 | `auto` 读取 **GGUF 自带 chat template**（Qwen/Llama3/Gemma/Phi/Mistral 自动适配）；多模型列表/切换/删除；格式路由明确区分「可运行」与「需插件」，绝不伪装；Android 15 **16KB 页对齐**；低内存自动降级 |
| 3 | UI 优化 + 不要屎山 | 业务逻辑写在 Composable 里；状态散落 | 新增 `core/` 单一职责层（AppConfig / DeviceProbe / Accelerator / FormatDetector / EngineFactory / ChatController）；UI 只渲染，业务全在应用级；日志页自适应高度、中文排版、运行概览 |
| 4 | API 调用流畅 | `CallerRunsPolicy` 让慢推理占用 accept 线程，新连接排队；每 token 一次 flush | 改 `AbortPolicy` + 结构化 **503**；SSE 微批；`Engine.generate` 返回真实 token 数，`usage` 不再用「SSE 写次数」冒充 |
| 5 | 支持大部分手机 / vivo Y300 | 国产 ROM 冻结前台服务；32 位与低内存机型 OOM | 后台保活一键跳转（电池优化白名单）；设备画像自动降并发/ctx/线程；`-Pabis=` 可扩展 `armeabi-v7a` / `x86_64`；16KB 页对齐 |
| 6 | 多模型格式 | 只认 GGUF | GGUF 真跑；`.task`/LiteRT、TFLite、ONNX、MNN 可识别、导入、管理、切换，明确标注引擎未接入 |
| 7 | 加速器 | — | 控制台「省电 / 均衡 / 极速」三档，统一驱动 KV 量化、预热、预填批大小、微批、并发上限、上下文与 max_tokens，并实时显示策略说明 |
| 8 | 取消打字机 | 每个 delta 触发一次 Compose 重组 | 客户端聚合完整文本，**生成完成后一次回填**；生成中只显示「正在生成…」，可取消 |

**最关键的那个报错**：`rememberCoroutineScope()` 属于 Compose 组合，你从「对话」切到「日志」时组合销毁，正在跑的推理被取消并被当成失败。现在请求跑在 `AppGraph.appScope`（应用级 SupervisorJob），切页、旋转、离开 Activity 都不会中断。已加静态检查防止回归。

⚠️ 速度仍受硬件决定：1.5B Q4_K_M 在中端机通常 10–25 tok/s，46 秒那次是 512 token 上限 + 全链路逐 token 刷写叠加的结果，代码层已把可优化的都优化掉；真实 tok/s 以响应里的 `local_timings` 为准。

---

## 一、快速开始

1. 把本目录 `git init && git push` 到你自己的 GitHub 仓库（私有仓库也可以）。
2. 打开仓库 **Actions → 构建与验证**，等待完成（约 2–4 分钟）。
3. 下载产物 `LocalModelAPI-<run_number>` 里的 `app-debug.apk`，传到手机安装（需允许「安装未知来源应用」）。
4. 打开 APP → **控制台 → 启动服务**。
5. 在「服务状态」卡片复制 **Base URL** 和 **API Key**（密钥默认隐藏，点「显示」或「复制密钥」）。
6. 用另一台设备调用：

```bash
curl http://127.0.0.1:8080/health     # 同一台手机内，免鉴权

curl https://<你的公网域名>/v1/chat/completions \
  -H "Authorization: Bearer <API_KEY>" \
  -H "Content-Type: application/json" \
  -N -d '{"model":"<模型名>","messages":[{"role":"user","content":"你好"}],"stream":true}'
```

CI 每次都会先跑协议回归，失败就不出包；产物里同时附上 `VERIFY_REPORT.md`。

---

## 二、拿到公网 HTTPS 地址

手机一般在运营商 NAT 后面，没有固定公网 IP，必须借助隧道。APP 里 **控制台 → 公网访问** 提供四档，改完点「重启生效」，地址会自动出现在「服务状态」和「调用」页。

| 模式 | 适用场景 | 你需要准备 |
| --- | --- | --- |
| 关闭 | 只在手机本机 / 局域网用 | 无 |
| Quick 隧道 | 立刻要一个临时公网地址，零配置 | 无，自动得到 `https://xxx.trycloudflare.com` |
| 命名隧道 | 固定自定义域名、长期稳定 | Cloudflare Tunnel Token + 域名 |
| 外部地址 | 最稳妥，适合正式使用 | 你在有公网的机器/Nginx 上跑隧道，把 `https://` 地址填进来 |

**命名隧道配置**
1. Cloudflare Zero Trust → Networks → Tunnels → Create a tunnel，拿到 Token。
2. Public Hostname 里把 `llm.example.com` 指向 `http://127.0.0.1:8080`（这是隧道**所在机器**视角，填本机即可）。
3. APP 里选「命名隧道」，填 Token 和域名，重启服务。
4. 强烈建议再给这个 hostname 加一条 **Access 策略**（邮箱 / Service Token），等于在 Bearer Key 之外再加一道门。

**为什么安全**：服务端默认只绑定 `127.0.0.1`，公网侧由 Cloudflare 终止 TLS；明文仅允许回环（见 `network_security_config.xml`），`usesCleartextTraffic=false`。CI 会通过 `scripts/prepare-tunnel-binary.sh` 把官方静态 `cloudflared` 随 APK 打包进 `nativeLibraryDir`——这是 Android 10+ 上唯一允许应用执行二进制的位置，避免运行时下载到私有目录被 W^X 拦掉。

> 若日志出现「Permission denied / 无法执行」，请改用 **外部地址** 模式：在你自己的服务器上运行
> `cloudflared tunnel --url http://<手机局域网IP>:8080`（或 frp / Nginx + HTTPS），把生成的 HTTPS 地址填入 APP。
>
> 若 CI 下载 release 资产失败（网络受限），可设置变量 `CLOUDFLARED_URL` 指向同版本静态二进制镜像后重跑 workflow；这一步失败只会告警，不会阻断 APK 产出。

---

## 三、调用方式（APP 自动生成）

「调用」页会按当前公网地址和密钥实时生成四种示例，点「复制完整调用包」可一次拿到 Base URL + Key + curl + Python。

**Python（OpenAI SDK）**

```python
from openai import OpenAI
client = OpenAI(base_url="https://<域名>/v1", api_key="<API_KEY>")
for chunk in client.chat.completions.create(
    model="<模型名>",
    messages=[{"role": "user", "content": "你好"}],
    stream=True,
):
    print(chunk.choices[0].delta.content or "", end="", flush=True)
```

**接口清单**

| 路径 | 鉴权 | 说明 |
| --- | --- | --- |
| `GET /health` | 免 | 状态、模型、引擎、运行时长 |
| `GET /` `/docs` | 免 | 手机适配的 API 文档页，**不显示密钥** |
| `GET /v1/models` | 需要 | OpenAI 兼容模型列表 |
| `POST /v1/chat/completions` | 需要 | 对话，支持 `stream:true` SSE |
| `POST /v1/completions` | 需要 | 传统补全接口 |
| `POST /v1/benchmark` | 需要 | PP/TG 分离测速，返回 `pp_tps` / `tg_tps` / `peak_mb` |

两种鉴权头都支持：`Authorization: Bearer <key>` 或 `X-API-Key: <key>`。响应额外带 `local_timings`（首 token 延迟、总耗时、tok/s），方便你观察手机上的真实速度。

---

## 四、界面与功能

四个底部 Tab，全部按手机竖屏比例设计（`screenOrientation="portrait"`）：

- **控制台**：服务开关、状态卡片、公网模式、模型导入、线程数 / 上下文长度 / 提示词模板 / 端口 / 局域网开关。
- **对话**：APP 内对话走的**就是**对外那个 API 的 SSE 流式接口，你在里面测到的行为和其他设备调用完全一致。
- **调用**：连接信息 + 自动生成的 curl / Python / Node.js / Kotlin 示例，一键复制。
- **日志**：实时运行日志，自动脱敏，密钥、请求头、正文一律不写入。

模型导入用系统文件选择器（SAF），**不需要任何存储权限**；GGUF 会被复制到 APP 私有目录并校验文件头。建议 Q4_K_M 及以下量化、7B 以内，内存 8GB+ 的手机体验更稳。

---

## 五、真机端侧推理（GGUF）

默认 CI 出的是**零 NDK 依赖**的轻量包，能装、能起服务、能对话（内置自检引擎会明确标注，不会伪装成真实模型）。要跑真实 GGUF：

```bash
# 本地（需 Android NDK 27 + CMake 3.22.1）
./gradlew assembleDebug -PwithLlama=true
```

或在 GitHub Actions 手动触发 `workflow_dispatch`，把 `with_llama` 选成 `true`。需要更多 ABI 时：

```bash
./gradlew assembleDebug -PwithLlama=true -Pabis=arm64-v8a,armeabi-v7a,x86_64
```

`native-llama/CMakeLists.txt` 会拉取固定 tag 的 llama.cpp，编译 CPU-only 的 `libllama_jni.so`，并对所有 `.so` 做 **16KB 页对齐**（Android 15 新机必需）。JNI 层实现 KV cache `q8_0` 量化、独立 context 预热、GGUF 自带 chat template 自动渲染、token 微批回调与 UTF-8 边界保护。

细节与排错见 `native-llama/README.md`。

**加速器怎么用**：控制台「省电 / 均衡 / 极速」三档一键切换，重启服务生效。三档统一驱动线程数、上下文、KV 量化、预填批大小、预热、JNI/SSE 微批、并发上限与 APP 默认 `max_tokens`；设备画像会自动识别大核数与低内存机型并降级。响应里的 `local_timings` 给出真实首 token 延迟与 tok/s。

**速度仍取决于模型与手机**：量化等级、内存带宽、大核调度、温升都会影响结果。代码能消除的是不必要的跨层调用与内存带宽浪费，不能突破硬件上限。

---

## 六、权限（最小必需）

| 权限 | 用途 |
| --- | --- |
| `INTERNET` / `ACCESS_NETWORK_STATE` | 隧道与对外服务 |
| `FOREGROUND_SERVICE` / `..._DATA_SYNC` | 模型常驻内存、服务不被杀 |
| `POST_NOTIFICATIONS` | Android 13+ 前台服务通知（唯一运行时申请项） |
| `WAKE_LOCK` | 推理期间不完全休眠 |

不申请定位、通讯录、相机、短信、读取外部存储。Android 沙盒里不存在「完整权限」这一说法，过度申请只会被商店拒绝并放大风险；APK 侧载不受商店审核，但依然按最小权限实现。

---

## 七、安全设计

- **密钥**：256 位随机 `lm_...`，仅存 `MODE_PRIVATE`，`allowBackup=false` + `data_extraction_rules` 全量排除；永不写日志、永不进文档页、永不进仓库；控制台可一键重置。
- **鉴权**：所有 `/v1/*` 强制 Bearer Key，常数时间比较（SHA-256 摘要比对）；401 带 `WWW-Authenticate`。
- **限流与体积**：每 Key 120 次/分钟、请求体上限 1 MiB、请求头 100 行、连接空闲 30s、`max_tokens` 硬上限 2048（APP 默认 256）、并发按性能档 2–8，满载返回结构化 503 而非阻塞。
- **传输**：公网强制 HTTPS；明文仅放行 `127.0.0.1` / `localhost`；CORS、安全响应头齐全。
- **隔离**：无导出 Provider、无备份、无外部存储写入、模型文件仅本应用可读。
- 建议在 Cloudflare Zero Trust 再加 Access 策略；密钥泄露时立刻在控制台重置。

---

## 八、已经验证 / 尚未验证

**已验证（可复现）**
```bash
python3 scripts/static-check.py                              # 42 项
python3 scripts/verify-protocol.py --report VERIFY_REPORT.md  # 33 项
```
真实启动 `app/src/main/java/.../LocalApiServer.java`（APK 里就是这份源码），通过 TCP 发起 HTTP/SSE 请求。协议 33 项覆盖：health / 文档页 / 401 / 错误 Key / 双鉴权头 / model 列表 / 非流式对话 / 传统补全 / SSE 多 chunk / `[DONE]` / finish_reason / usage / **微批合并（16 chunk < 48 token）** / **真实 completion_tokens** / 首字节 < 500ms / CORS / 404 / 400 / 413 / **benchmark 鉴权 401 / 无槽位 501 / 注入钩子 200 / 参数 clamp** / keep-alive / 8 并发 / 限流 429 / 日志无密钥。

静态 42 项除语法、资源、Gradle 别名、package 一致性、密钥扫描外，把 v2/v3 修复全部固化为**防回归约束**：应用级协程、无逐 delta 刷新、SSE 微批、503、KV 量化、自动模板、预热、16KB 页对齐、多格式路由、保活引导，以及 v3 的单一模型槽位/互斥、热切换、推理串行化、KV-Flash 兼容校验、内存预检、降级重试、后台自动卸载、PP/TG 测速、CPU 大核亲和、超长 prompt 截断、推理期唤醒锁、日志节流、DVFS 预升频。改坏了 CI 会直接失败。

**需要你在真机上完成**
1. 安装 APK、授予通知权限、启动服务、导入 GGUF。
2. 配好 Quick 隧道或命名隧道，用另一台设备 `curl` 公网 `/health` 与 `/v1/chat/completions`。
3. 确认厂商后台保活策略（部分国产 ROM 会杀前台服务，需加入电池优化白名单）。
4. 若启用 `-PwithLlama=true`，确认 `libllama_jni.so` 加载成功、真实模型吐字与 tok/s 符合预期。

我没法替你完成这四步，也不会把它们描述成「已跑通」。CI 里的协议回归是自动的，真机验证是手动的。

---

## 九、已知限制

- Android 不是服务器：后台保活、温控降频、内存回收都受系统管制；长时间高负载推理建议插电。
- CPU 推理速度受硬件限制，7B 以上模型在手机上会明显慢；追求速度请换更小量化 / 更小模型。
- `cloudflared` 在部分 ROM / SELinux 策略下仍可能无法执行，备用方案是「外部地址」模式。
- 不支持 root / 系统级权限，也不申请任何敏感权限；这是系统沙盒的边界，不是实现缺口。
- 未上架应用商店，签名 release 需要你自己的 keystore（CI 已留好 secrets 接口）。

---

## 十、目录

```
app/src/main/java/com/yuanbao/localmodel/
├── core/                        # 单一职责业务层（UI 不含逻辑）
│   ├── AppCore.kt               # 常量 / 设备画像 / 加速器 / 内存预检 / 参数校验 / 格式识别
│   ├── ModelSlot.kt             # 单例互斥模型槽位 / 热切换 / 推理串行化 / 自动卸载
│   ├── EngineFactory.kt         # 格式路由、内存预检、3 档降级重试、诚实状态
│   └── ChatController.kt        # 应用级协程、聚合输出、一次性回填、进度与重试
├── server/LocalApiServer.java   # 零依赖 HTTP/SSE 服务 + 鉴权 + 微批（JVM/Android 同一份）
├── engine/LlamaCppEngine.kt     # 可选 GGUF 真机引擎（JNI）
├── service/                     # 前台服务 + Cloudflare 隧道
├── ui/                          # Compose 竖屏界面，只负责渲染
└── util/                        # 密钥、多模型仓库、日志、SSE 客户端
native-llama/                    # 可选 JNI 桥接与 CMake（16KB 对齐）
scripts/                         # 静态自检、协议验证、隧道二进制准备
.github/workflows/build.yml      # 协议回归 + 自动出 APK + 可选 Release
```

后续可继续加：LiteRT-LM / ExecuTorch 引擎插件（PocketPal 也在测这两条 Android 路径，格式路由已留接口）、GGUF 下载器、OpenCL/Vulkan 后端、Zero Trust 一键配置、用量统计面板。按你的反馈排优先级。

⚠️ 关于 GPU：Android 上 OpenCL/Vulkan 对 decode 提速通常只有 20–40%，prefill 收益更大；不同 ROM 的驱动差异极大，PocketPal 也是以 CPU 为通用回退。当前构建坚持 CPU-only + 大核亲和，优先保证「不崩、不抖」，不拿不确定的加速承诺换稳定性。
