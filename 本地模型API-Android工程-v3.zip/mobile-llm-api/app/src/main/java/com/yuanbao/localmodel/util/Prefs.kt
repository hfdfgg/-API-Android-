package com.yuanbao.localmodel.util

import android.content.Context
import com.yuanbao.localmodel.core.PerfMode
import com.yuanbao.localmodel.server.LocalApiServer
import java.io.File

/** API key is app-private, never backed up, never logged, never committed. */
class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val keyFile = File(ctx.filesDir, "api_key.txt")

    fun apiKey(): String {
        if (!keyFile.exists()) return resetApiKey()
        val k = keyFile.readText().trim()
        return if (k.startsWith("lm_") && k.length >= 40) k else resetApiKey()
    }

    fun resetApiKey(): String {
        val k = LocalApiServer.generateApiKey()
        keyFile.writeText(k)
        return k
    }

    var port: Int
        get() = sp.getInt("port", 8080)
        set(v) = sp.edit().putInt("port", v).apply()

    var lanMode: Boolean
        get() = sp.getBoolean("lan", false)
        set(v) = sp.edit().putBoolean("lan", v).apply()

    var perfMode: String
        get() = sp.getString("perf", PerfMode.BALANCED.id) ?: PerfMode.BALANCED.id
        set(v) = sp.edit().putString("perf", v).apply()

    /** auto | chatml | llama3 | gemma | phi | raw ; "auto" reads the GGUF's own template. */
    var promptTemplate: String
        get() = sp.getString("template", "auto") ?: "auto"
        set(v) = sp.edit().putString("template", v).apply()

    var tunnelMode: String
        get() = sp.getString("tunnel", "off") ?: "off"
        set(v) = sp.edit().putString("tunnel", v).apply()

    var tunnelToken: String
        get() = sp.getString("tunnel_token", "") ?: ""
        set(v) = sp.edit().putString("tunnel_token", v).apply()

    var publicHostname: String
        get() = sp.getString("public_hostname", "") ?: ""
        set(v) = sp.edit().putString("public_hostname", v).apply()

    var externalBase: String
        get() = sp.getString("external_base", "") ?: ""
        set(v) = sp.edit().putString("external_base", v).apply()
}
