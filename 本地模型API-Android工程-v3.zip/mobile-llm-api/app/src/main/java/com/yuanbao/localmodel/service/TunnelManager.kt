package com.yuanbao.localmodel.service

import android.content.Context
import android.os.Build
import com.yuanbao.localmodel.util.LogBus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Public reachability for a phone behind carrier NAT.
 *
 *  - quick    : Cloudflare Quick Tunnel, no account needed, random *.trycloudflare.com
 *  - token    : your own named tunnel (custom domain) via cloudflared token
 *  - external : you run cloudflared/frp on a machine you control and paste the
 *               public HTTPS base URL here; the app never executes a binary.
 *
 * All three expose ONLY HTTPS. The HTTP server itself still binds loopback,
 * so nothing on the internet can reach the raw port.
 */
class TunnelManager(private val ctx: Context, private val log: LogBus) {

    private val _url = MutableStateFlow("")
    val url: StateFlow<String> = _url.asStateFlow()
    private val _status = MutableStateFlow("未开启")
    val status: StateFlow<String> = _status.asStateFlow()

    private var process: Process? = null
    private val stopping = AtomicBoolean(false)

    companion object {
        private const val RELEASE =
            "https://github.com/cloudflare/cloudflared/releases/latest/download/"
        private val QUICK_URL = Regex("https://[a-z0-9-]+\\.trycloudflare\\.com")
    }

    fun start(port: Int, mode: String, token: String, hostname: String, externalBase: String) {
        stop()
        stopping.set(false)
        when (mode) {
            "external" -> {
                val base = externalBase.trim().trimEnd('/')
                if (base.startsWith("https://")) {
                    _url.value = base
                    _status.value = "外部 HTTPS 已配置"
                    log.info("公网地址已设为 $base（由你的隧道负责 TLS 与转发）")
                } else {
                    _status.value = "请填写 https:// 开头的公网地址"
                    log.warn("外部公网地址必须是 https://")
                }
                return
            }
            "quick", "token" -> { /* fall through to binary */ }
            else -> return
        }

        try {
            val bin = ensureBinary()
            val cmd = mutableListOf(bin.absolutePath, "tunnel")
            if (mode == "quick") {
                cmd += listOf("--url", "http://127.0.0.1:$port", "--no-autoupdate")
            } else {
                if (token.isBlank()) {
                    _status.value = "缺少 Tunnel Token"
                    log.warn("命名隧道需要填写 Token")
                    return
                }
                cmd += listOf("run", "--token", token, "--no-autoupdate")
                if (hostname.isNotBlank()) {
                    _url.value = "https://" + hostname.trim().removePrefix("https://")
                    _status.value = "命名隧道连接中"
                }
            }

            val pb = ProcessBuilder(cmd)
                .directory(ctx.filesDir)
                .redirectErrorStream(true)
            pb.environment()["HOME"] = ctx.filesDir.absolutePath
            pb.environment()["TMPDIR"] = ctx.cacheDir.absolutePath
            pb.environment()["GODEBUG"] = "netdns=go"
            pb.environment()["NO_AUTOUPDATE"] = "1"

            _status.value = "连接 Cloudflare 边缘…"
            process = pb.start()
            log.info("cloudflared 已启动（mode=$mode）")

            Thread {
                try {
                    process?.inputStream?.bufferedReader()?.useLines { lines ->
                        for (raw in lines) {
                            if (stopping.get()) break
                            val line = if (token.isBlank()) raw else raw.replace(token, "***")
                            val found = QUICK_URL.find(line)
                            if (found != null && mode == "quick") {
                                _url.value = found.value
                                _status.value = "公网 HTTPS 已就绪"
                                log.info("公网地址：${found.value}")
                            }
                            if (line.contains("ERR", true) || line.contains("error", true)) {
                                log.warn("cloudflared: ${line.take(180)}")
                            }
                        }
                    }
                } catch (t: Throwable) {
                    if (!stopping.get()) log.warn("隧道输出读取结束：${t.javaClass.simpleName}")
                }
            }.apply { name = "cloudflared-log"; isDaemon = true }.start()
        } catch (t: Throwable) {
            _status.value = "隧道启动失败：${t.javaClass.simpleName}"
            log.error("cloudflared 无法在设备上执行：${t.message ?: ""}")
            log.warn("可改用「外部公网地址」模式：在任意有公网的机器运行 cloudflared 后填入地址")
        }
    }

    fun stop() {
        stopping.set(true)
        try {
            process?.destroyForcibly()
        } catch (t: Throwable) {
            // ignore
        }
        process = null
        _url.value = ""
        _status.value = "未开启"
    }

    /**
     * Where the binary can be executed from.
     *
     * Android 10+ (API 29) blocks `untrusted_app` from executing files written to
     * its own data directory (W^X / SELinux). Files installed as part of the APK
     * into nativeLibraryDir DO keep the executable bit and are allowed to run —
     * that is why the CI optionally ships `libcloudflared.so` inside the APK.
     *
     * Priority:
     *   1. APK-shipped binary in nativeLibraryDir (reliable, works on modern Android)
     *   2. cached download in filesDir (works on older devices / debuggable builds)
     *   3. fresh download from the official GitHub release
     */
    private fun ensureBinary(): File {
        bundledBinary()?.let {
            log.info("使用 APK 内置 cloudflared（可执行目录）")
            return it
        }

        val binDir = File(ctx.filesDir, "bin").apply { mkdirs() }
        val bin = File(binDir, "cloudflared")
        if (bin.exists() && bin.length() > 1_000_000 && bin.canExecute()) return bin

        val asset = if (Build.SUPPORTED_ABIS.any { it.contains("arm64") })
            "cloudflared-linux-arm64" else "cloudflared-linux-amd64"
        log.info("首次使用：下载 $asset …")
        val tmp = File(binDir, "cloudflared.download")
        val conn = (URL(RELEASE + asset).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 120_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "LocalModelAPI/1.0")
        }
        try {
            conn.inputStream.use { input -> tmp.outputStream().buffered().use { out -> input.copyTo(out) } }
            if (!tmp.renameTo(bin)) {
                tmp.copyTo(bin, overwrite = true)
                tmp.delete()
            }
            if (!bin.setExecutable(true, false)) throw IllegalStateException("无法设置可执行权限")
        } finally {
            conn.disconnect()
        }
        log.warn("Android 10+ 可能禁止执行应用私有目录中的文件；建议用 scripts/prepare-tunnel-binary.sh 把二进制随 APK 打包")
        log.info("cloudflared 就绪（${bin.length() / 1024 / 1024} MB）")
        return bin
    }

    private fun bundledBinary(): File? {
        val dir = ctx.applicationInfo.nativeLibraryDir ?: return null
        val names = listOf("libcloudflared.so", "cloudflared")
        for (n in names) {
            val f = File(dir, n)
            if (f.isFile && f.length() > 1_000_000 && f.canExecute()) return f
        }
        return null
    }
}
