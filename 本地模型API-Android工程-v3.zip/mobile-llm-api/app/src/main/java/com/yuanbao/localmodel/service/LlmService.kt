package com.yuanbao.localmodel.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.MainActivity
import com.yuanbao.localmodel.R
import com.yuanbao.localmodel.core.EngineFactory
import com.yuanbao.localmodel.core.MemoryAdvisor
import com.yuanbao.localmodel.core.ModelSlot
import com.yuanbao.localmodel.core.PerfPolicy
import com.yuanbao.localmodel.server.LocalApiServer
import com.yuanbao.localmodel.util.ModelInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.atomic.AtomicInteger

class LlmService : Service() {

    companion object {
        const val ACTION_START = "com.yuanbao.localmodel.START"
        const val ACTION_STOP = "com.yuanbao.localmodel.STOP"
        const val ACTION_RESET_KEY = "com.yuanbao.localmodel.RESET_KEY"
        const val ACTION_SWAP_MODEL = "com.yuanbao.localmodel.SWAP_MODEL"
        const val ACTION_OFFLOAD = "com.yuanbao.localmodel.OFFLOAD"
        const val ACTION_RELOAD = "com.yuanbao.localmodel.RELOAD"
        private const val CHANNEL = "llm_service"
        private const val NOTIF_ID = 1001

        private fun intent(ctx: Context, action: String) =
            Intent(ctx, LlmService::class.java).setAction(action)

        fun start(ctx: Context) = ctx.startForegroundService(intent(ctx, ACTION_START))
        fun stop(ctx: Context) = ctx.startService(intent(ctx, ACTION_STOP))
        fun resetKey(ctx: Context) = ctx.startForegroundService(intent(ctx, ACTION_RESET_KEY))
        fun swapModel(ctx: Context) = ctx.startForegroundService(intent(ctx, ACTION_SWAP_MODEL))
        fun offload(ctx: Context) = ctx.startService(intent(ctx, ACTION_OFFLOAD))
        fun reload(ctx: Context) = ctx.startForegroundService(intent(ctx, ACTION_RELOAD))
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var server: LocalApiServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val wakeRefs = AtomicInteger(0)
    private lateinit var tunnel: TunnelManager

    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
        tunnel = TunnelManager(this, AppGraph.logs)
        createChannel()
        observeFlows()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAll()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_RESET_KEY -> {
                AppGraph.prefs.resetApiKey()
                AppGraph.logs.info("API Key 已重置，服务重启中")
                restart()
            }
            ACTION_SWAP_MODEL -> hotSwap()
            ACTION_OFFLOAD -> autoOffload()
            ACTION_RELOAD -> autoReload()
            else -> startAll()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopAll()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ lifecycle

    private fun restart() {
        stopAll()
        startAll()
    }

    private fun startAll() {
        AppGraph.refreshPolicy()
        val policy = AppGraph.policy.value ?: return
        val prefs = AppGraph.prefs

        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        val model = AppGraph.models.current()
        val result = EngineFactory.create(model, policy, AppGraph.device, prefs, AppGraph.logs)
        ModelSlot.swap(result.engine, result.native, policy, result.label, result.real)
        publishModelAdvice(model, policy)

        val cfg = LocalApiServer.Config().apply {
            host = if (prefs.lanMode) "0.0.0.0" else "127.0.0.1"
            port = prefs.port
            apiKey = prefs.apiKey()
            modelId = model?.name ?: "local-selfcheck"
            requestsPerMinute = 120
            maxConcurrent = policy.maxConcurrent
            sseBatchTokens = policy.sseBatchTokens
            sseBatchMs = policy.sseBatchMs
            maxTokensDefault = policy.appMaxTokens
            maxTokensHardCap = 2048
            benchmarkHook = LocalApiServer.BenchmarkHook { pp, tg, warm -> runBenchmark(pp, tg, warm) }
            lifecycle = object : LocalApiServer.GenerateLifecycle {
                override fun onStart() = acquireWake()
                override fun onEnd() = releaseWake()
            }
        }

        var attempts = 0
        while (attempts < 6) {
            try {
                val s = LocalApiServer(cfg, ModelSlot.engine(), AppGraph.logs)
                s.start()
                server = s
                break
            } catch (e: Exception) {
                attempts++
                cfg.port++
                AppGraph.logs.warn("端口 ${cfg.port - 1} 被占用，尝试 ${cfg.port}")
            }
        }

        if (server == null) {
            AppGraph.logs.error("端口全部被占用，服务启动失败")
        } else {
            if (prefs.tunnelMode != "off") {
                tunnel.start(cfg.port, prefs.tunnelMode, prefs.tunnelToken,
                    prefs.publicHostname, prefs.externalBase)
            }
            AppGraph.logs.info("本地 API 已就绪：${server!!.baseUrl()}")
        }
        publish(cfg, policy)
    }

    /**
     * PocketPal lesson: switching models must not restart the HTTP server.
     * The public URL, port and API Key stay valid; only the engine is replaced,
     * under the same lock that serializes generation.
     */
    private fun hotSwap() {
        val s = server
        if (s == null) {
            startAll()
            return
        }
        AppGraph.refreshPolicy()
        val policy = AppGraph.policy.value ?: return
        val model = AppGraph.models.current()
        AppGraph.logs.info("热切换模型：${model?.name ?: "无"}（服务与公网地址不变）")
        val result = EngineFactory.create(model, policy, AppGraph.device, AppGraph.prefs, AppGraph.logs)
        ModelSlot.swap(result.engine, result.native, policy, result.label, result.real)
        ModelSlot.attach(s)
        publishModelAdvice(model, policy)
        AppGraph.update {
            it.copy(
                engineName = result.label, engineReal = result.real,
                modelName = model?.name ?: "未导入模型",
                modelSize = if (model != null) AppGraph.models.formatSize(model.sizeBytes) else "",
                modelPath = model?.path ?: "",
                modelFormat = model?.format?.label ?: "",
                policyInfo = com.yuanbao.localmodel.core.Accelerator.explain(policy, AppGraph.device),
                offloaded = false,
            )
        }
        AppGraph.logs.info("热切换完成，无需重连隧道 / 无需换 Key")
    }

    /** App went to background: free the native context, keep server + tunnel alive. */
    private fun autoOffload() {
        val policy = AppGraph.policy.value ?: return
        if (!policy.autoOffload || !ModelSlot.real) return
        ModelSlot.offload()
        AppGraph.update { it.copy(offloaded = true, engineName = ModelSlot.label) }
        AppGraph.logs.info("进入后台：已卸载模型释放内存（服务仍在线）")
    }

    private fun autoReload() {
        if (server == null || !ModelSlot.offloaded) return
        AppGraph.logs.info("回到前台：自动重载模型…")
        hotSwap()
    }

    private fun stopAll() {
        tunnel.stop()
        try { server?.stop() } catch (t: Throwable) { }
        server = null
        ModelSlot.release()
        forceReleaseWake()
        AppGraph.update {
            it.copy(running = false, publicUrl = "", tunnelStatus = "未开启",
                streaming = false, offloaded = false)
        }
        AppGraph.chat.cancel()
    }

    private fun runBenchmark(pp: Int, tg: Int, warm: Int): Map<String, Any?> {
        val r = ModelSlot.benchmark(pp, tg, warm)
        val map = LinkedHashMap<String, Any?>()
        map["supported"] = r.supported
        map["pp_tps"] = r.ppTps
        map["tg_tps"] = r.tgTps
        map["peak_mb"] = r.peakMb
        map["note"] = r.note
        if (r.supported) {
            val cfg = LinkedHashMap<String, Any?>()
            cfg["n_threads"] = r.threads
            cfg["n_ctx"] = r.ctx
            cfg["pp"] = pp
            cfg["tg"] = tg
            cfg["warmup"] = warm
            map["config"] = cfg
        }
        AppGraph.update { it.copy(bench = r) }
        return map
    }

    private fun publishModelAdvice(model: ModelInfo?, policy: PerfPolicy) {
        val advice = if (model != null) MemoryAdvisor.evaluate(model.sizeBytes, AppGraph.device).advice else ""
        AppGraph.update { it.copy(memoryAdvice = advice) }
    }

    private fun publish(cfg: LocalApiServer.Config, policy: PerfPolicy) {
        val lan = if (cfg.host == "0.0.0.0") "http://${lanIp()}:${cfg.port}" else ""
        AppGraph.update { s ->
            s.copy(
                running = server?.isRunning == true,
                port = cfg.port,
                lanMode = cfg.host == "0.0.0.0",
                perfMode = AppGraph.prefs.perfMode,
                promptTemplate = AppGraph.prefs.promptTemplate,
                tunnelMode = AppGraph.prefs.tunnelMode,
                tunnelToken = AppGraph.prefs.tunnelToken,
                publicHostname = AppGraph.prefs.publicHostname,
                externalBase = AppGraph.prefs.externalBase,
                localUrl = server?.baseUrl() ?: "",
                lanUrl = lan,
                apiKey = cfg.apiKey,
                engineName = ModelSlot.label,
                engineReal = ModelSlot.real,
                offloaded = ModelSlot.offloaded,
                deviceInfo = AppGraph.device.summary,
                policyInfo = com.yuanbao.localmodel.core.Accelerator.explain(policy, AppGraph.device),
            )
        }
    }

    private fun observeFlows() {
        scope.launch { AppGraph.logs.lines.collect { l -> AppGraph.update { it.copy(logs = l) } } }
        scope.launch { tunnel.url.collect { u -> AppGraph.update { it.copy(publicUrl = u) } } }
        scope.launch { tunnel.status.collect { t -> AppGraph.update { it.copy(tunnelStatus = t) } } }
    }

    // ------------------------------------------------------------------ fine-grained wake lock

    private fun acquireWake() {
        if (wakeRefs.incrementAndGet() == 1) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalModelAPI:infer").apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 1000L)
            }
        }
    }

    private fun releaseWake() {
        if (wakeRefs.get() == 0) return
        if (wakeRefs.decrementAndGet() == 0) forceReleaseWake()
    }

    private fun forceReleaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (t: Throwable) { }
        wakeLock = null
        wakeRefs.set(0)
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW).apply {
                description = getString(R.string.notif_channel_desc)
            })
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(pi)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE).build()
    }

    private fun lanIp(): String = try {
        val nifs = NetworkInterface.getNetworkInterfaces()
        while (nifs.hasMoreElements()) {
            val addrs = nifs.nextElement().inetAddresses
            while (addrs.hasMoreElements()) {
                val a = addrs.nextElement()
                if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress ?: ""
            }
        }
        ""
    } catch (t: Throwable) { "" }
}
