package com.yuanbao.localmodel.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.yuanbao.localmodel.core.FormatDetector
import com.yuanbao.localmodel.core.ModelFormat
import java.io.File

data class ModelInfo(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val format: ModelFormat,
) {
    val runnable: Boolean get() = format.runnable
}

/**
 * Multiple models, multiple formats. Files are copied into app-private storage
 * through SAF (no storage permission), and can be selected / removed one by one.
 */
class ModelRepository(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "models").apply { mkdirs() }
    private val sp = ctx.getSharedPreferences("models", Context.MODE_PRIVATE)

    fun list(): List<ModelInfo> = dir.listFiles()
        ?.filter { it.isFile }
        ?.map { describe(it) }
        ?.sortedByDescending { it.sizeBytes }
        ?: emptyList()

    fun current(): ModelInfo? {
        val path = sp.getString("current", null) ?: return list().firstOrNull()?.also { select(it.path) }
        val f = File(path)
        return if (f.isFile) describe(f) else null
    }

    fun select(path: String) {
        if (File(path).isFile) sp.edit().putString("current", path).apply()
    }

    fun remove(path: String) {
        val f = File(path)
        if (f.parentFile?.absolutePath == dir.absolutePath) f.delete()
        if (sp.getString("current", null) == path) {
            sp.edit().remove("current").apply()
            list().firstOrNull()?.let { select(it.path) }
        }
    }

    fun clear() {
        sp.edit().remove("current").apply()
        dir.listFiles()?.forEach { it.delete() }
    }

    fun import(uri: Uri): ModelInfo {
        val rawName = displayName(uri) ?: "model_${System.currentTimeMillis()}"
        val safe = rawName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        val dest = File(dir, safe)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().buffered(1024 * 1024).use { out -> input.copyTo(out) }
        } ?: throw IllegalArgumentException("无法读取所选文件，请重新选择")

        val info = describe(dest)
        select(dest.absolutePath)
        return info
    }

    fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return "%.1f KB".format(kb)
        val mb = kb / 1024.0
        return if (mb < 1024) "%.1f MB".format(mb) else "%.2f GB".format(mb / 1024.0)
    }

    private fun describe(f: File) = ModelInfo(
        name = f.name,
        path = f.absolutePath,
        sizeBytes = f.length(),
        format = FormatDetector.detect(f),
    )

    private fun displayName(uri: Uri): String? = try {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }
    } catch (e: Exception) {
        null
    }
}
