package com.yuanbao.localmodel.util

import com.yuanbao.localmodel.ChatLine
import com.yuanbao.localmodel.core.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * The in-app chat calls the SAME OpenAI-compatible endpoint as external clients,
 * so the app is a real end-to-end test of the public API.
 *
 * Tokens are accumulated here and returned as one string. The UI writes them
 * once (no typewriter), which also removes hundreds of recompositions per reply.
 */
object ApiClient {

    data class ChatResult(val text: String, val firstTokenMs: Long, val tps: Double)

    data class BenchData(val ppTps: Double, val tgTps: Double, val peakMb: Long, val note: String)

    /** Call the public-compatible /v1/benchmark endpoint (PP/TG split). */
    suspend fun benchmark(
        port: Int, apiKey: String, pp: Int, tg: Int, warmup: Int,
    ): BenchData = withContext(Dispatchers.IO) {
        val body = JSONObject().put("pp", pp).put("tg", tg).put("warmup", warmup).toString()
        val conn = (URL("http://127.0.0.1:$port/v1/benchmark").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = AppConfig.CONNECT_TIMEOUT_MS
            readTimeout = 300_000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode != 200) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw IllegalStateException("HTTP ${conn.responseCode} ${err.take(160)}")
            }
            val raw = conn.inputStream.bufferedReader().use { it.readText() }
            val j = JSONObject(raw)
            if (!j.optBoolean("supported", false)) {
                throw IllegalStateException(j.optString("note", "当前构建不支持测速"))
            }
            BenchData(
                j.optDouble("pp_tps", 0.0), j.optDouble("tg_tps", 0.0),
                j.optLong("peak_mb", 0L), j.optString("note", ""),
            )
        } finally {
            conn.disconnect()
        }
    }

    suspend fun streamChat(
        port: Int,
        apiKey: String,
        model: String,
        history: List<ChatLine>,
        userText: String,
        maxTokens: Int = 256,
    ): ChatResult = withContext(Dispatchers.IO) {
        val messages = JSONArray()
        history.takeLast(12).forEach {
            messages.put(JSONObject().put("role", it.role).put("content", it.text))
        }
        messages.put(JSONObject().put("role", "user").put("content", userText))

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("stream", true)
            .put("max_tokens", maxTokens)
            .put("temperature", 0.7)
            .toString()

        val conn = (URL("http://127.0.0.1:$port/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = AppConfig.CONNECT_TIMEOUT_MS
            readTimeout = AppConfig.READ_TIMEOUT_MS
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "text/event-stream")
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Connection", "close")
        }

        try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode != 200) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw IllegalStateException("HTTP ${conn.responseCode} ${err.take(200)}")
            }

            val sb = StringBuilder()
            var firstTokenMs = 0L
            var tps = 0.0
            BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data: ")) continue
                    val data = line.removePrefix("data: ").trim()
                    if (data == "[DONE]") break
                    val obj = JSONObject(data)
                    val delta = obj.optJSONArray("choices")
                        ?.optJSONObject(0)?.optJSONObject("delta")
                    val piece = delta?.optString("content") ?: ""
                    if (piece.isNotEmpty()) sb.append(piece)
                    obj.optJSONObject("local_timings")?.let {
                        tps = it.optDouble("tokens_per_second", 0.0)
                        firstTokenMs = it.optLong("first_token_ms", 0L)
                    }
                }
            }
            ChatResult(sb.toString(), firstTokenMs, tps)
        } finally {
            conn.disconnect()
        }
    }
}
