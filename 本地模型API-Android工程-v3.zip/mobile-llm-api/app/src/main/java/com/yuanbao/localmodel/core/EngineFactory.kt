package com.yuanbao.localmodel.core

import com.yuanbao.localmodel.engine.LlamaCppEngine
import com.yuanbao.localmodel.server.LocalApiServer
import com.yuanbao.localmodel.util.LogBus
import com.yuanbao.localmodel.util.ModelInfo
import com.yuanbao.localmodel.util.Prefs

/** Result of an engine attempt: engine + native handle + honest one-line status. */
data class EngineResult(
    val engine: LocalApiServer.Engine,
    val native: LlamaCppEngine?,
    val label: String,
    val real: Boolean,
)

/**
 * The only place that decides which engine runs. Everything else depends on the
 * LocalApiServer.Engine interface, so adding LiteRT-LM / ExecuTorch later is one
 * branch here (PocketPal's four-layer "engine" tier, same idea).
 */
object EngineFactory {

    fun create(
        model: ModelInfo?,
        policy: PerfPolicy,
        device: DeviceProfile,
        prefs: Prefs,
        log: LogBus,
    ): EngineResult {
        if (model == null) {
            log.info("未导入模型：启动内置自检引擎（输出明确标注，不伪装成真实模型）")
            return fallback("local-selfcheck", "内置自检引擎 · 未导入模型")
        }

        if (model.format != ModelFormat.GGUF) {
            log.warn("${model.name} 是 ${model.format.label}，当前 APK 未包含 ${model.format.engine}")
            log.warn("可导入与管理，但不会执行推理；GGUF 才是当前唯一可跑格式")
            return EngineResult(
                UnavailableEngine(model.name, model.format.label), null,
                "${model.format.label} · 引擎未接入", false)
        }

        // PocketPal lesson #2: memory-first loading, before touching native code.
        val fit = MemoryAdvisor.evaluate(model.sizeBytes, device)
        log.info(fit.advice)
        if (!fit.ok) {
            log.warn("已阻止加载：预估内存超预算。换更小量化或切「省电」档可避免系统杀进程")
            return EngineResult(
                UnavailableEngine(model.name, "内存不足"), null,
                "内存预检未通过 · 已阻止加载", false)
        }

        if (!LlamaCppEngine.available) {
            log.warn("未检测到 libllama_jni.so，回退自检引擎；真机推理需 -PwithLlama=true")
            return fallback(model.name, "内置自检引擎 · 缺少原生库")
        }

        // PocketPal lesson #3: enforce GPU / flash-attn / KV-cache compatibility
        // BEFORE calling native init, otherwise llama.cpp aborts (SIGABRT).
        val safe = ParamValidator.resolve(policy)
        if (safe.note.isNotBlank()) log.warn(safe.note)

        val attempts = buildList {
            add(policy.copy(kvK = safe.kvK, kvV = safe.kvV, flashAttn = safe.flash))
            // Graceful fallback chain, mirroring PocketPal's "fall back to CPU-only".
            add(policy.copy(kvK = "q8_0", kvV = "f16", flashAttn = false,
                ctxSize = minOf(policy.ctxSize, 2048)))
            add(policy.copy(kvK = "f16", kvV = "f16", flashAttn = false,
                ctxSize = minOf(policy.ctxSize, 1024),
                threads = minOf(policy.threads, 2)))
        }

        var lastError: String? = null
        for ((i, attempt) in attempts.withIndex()) {
            val e = LlamaCppEngine(
                modelPath = model.path,
                policy = attempt,
                templateId = prefs.promptTemplate,
                log = log,
            )
            try {
                e.load()
                if (attempt.warmup) {
                    log.info("预热中：触发权重页加载与 CPU 后端初始化…")
                    e.warmup()
                    log.info("预热完成，首 token 延迟会明显下降")
                }
                if (i > 0) log.warn("加载降级到第 ${i + 1} 档后成功：$lastError")
                log.info("GGUF 已载入：${model.name}（${attempt.threads}线程 / ${attempt.ctxSize}ctx / " +
                        "K=${attempt.kvK} V=${attempt.kvV} / 绑核=${attempt.affinityMask.ifBlank { "关" }}）")
                return EngineResult(e, e, "llama.cpp · 真实 GGUF 推理", true)
            } catch (t: Throwable) {
                lastError = t.message ?: t.javaClass.simpleName
                log.warn("第 ${i + 1} 档加载失败：$lastError")
                try { e.close() } catch (ignored: Throwable) { }
            }
        }

        log.error("全部档位加载失败：$lastError")
        log.warn("常见原因：内存不足、llama.cpp 版本 API 不匹配、模型架构不支持当前 KV 设置")
        return fallback(model.name, "内置自检引擎 · 模型加载失败（已尝试降级）")
    }

    private fun fallback(id: String, label: String) = EngineResult(
        LocalApiServer.BuiltinEngine(id), null, label, false)

    /** Honest stub: never generates text; server answers 503 instead of faking output. */
    private class UnavailableEngine(
        private val id: String,
        private val reason: String,
    ) : LocalApiServer.Engine {
        override fun modelId() = id
        override fun isLoaded() = false
        override fun estimatePromptTokens(prompt: LocalApiServer.Prompt) = 0
        override fun generate(prompt: LocalApiServer.Prompt, sink: LocalApiServer.TokenSink): Int {
            throw IllegalStateException("模型不可用：$reason")
        }
    }
}
