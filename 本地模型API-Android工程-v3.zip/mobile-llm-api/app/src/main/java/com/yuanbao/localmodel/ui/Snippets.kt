package com.yuanbao.localmodel.ui

import com.yuanbao.localmodel.UiState

/** Public base URL takes priority; LAN address is a fallback when tunnel is off. */
fun effectiveBase(s: UiState): String = when {
    s.publicUrl.isNotBlank() -> s.publicUrl.trimEnd('/')
    s.lanMode && s.lanUrl.isNotBlank() -> s.lanUrl.trimEnd('/')
    else -> s.localUrl.trimEnd('/')
}

object Snippets {

    fun curl(base: String, key: String, model: String) = """
curl $base/v1/chat/completions \
  -H "Authorization: Bearer $key" \
  -H "Content-Type: application/json" \
  -N -d '{"model":"$model","messages":[{"role":"user","content":"你好"}],"stream":true}'
""".trim()

    fun python(base: String, key: String, model: String) = """
from openai import OpenAI

client = OpenAI(base_url="$base/v1", api_key="$key")
resp = client.chat.completions.create(
    model="$model",
    messages=[{"role": "user", "content": "你好"}],
    stream=True,
)
for chunk in resp:
    print(chunk.choices[0].delta.content or "", end="", flush=True)
""".trim()

    fun node(base: String, key: String, model: String) = """
const res = await fetch("$base/v1/chat/completions", {
  method: "POST",
  headers: {
    "Authorization": "Bearer $key",
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "$model",
    messages: [{ role: "user", content: "你好" }],
    stream: true,
  }),
});
const reader = res.body.getReader();
const dec = new TextDecoder();
while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  for (const line of dec.decode(value).split("\n")) {
    if (!line.startsWith("data: ")) continue;
    const d = line.slice(6).trim();
    if (d === "[DONE]") break;
    process.stdout.write(JSON.parse(d).choices[0].delta.content || "");
  }
}
""".trim()

    fun kotlin(base: String, key: String, model: String) = """
val url = URL("$base/v1/chat/completions")
val conn = (url.openConnection() as HttpURLConnection).apply {
    requestMethod = "POST"; doOutput = true
    setRequestProperty("Authorization", "Bearer $key")
    setRequestProperty("Content-Type", "application/json")
}
val body = JSONObject()
    .put("model", "$model")
    .put("messages", JSONArray().put(JSONObject()
        .put("role", "user").put("content", "你好")))
    .put("stream", true)
conn.outputStream.use { it.write(body.toString().toByteArray()) }
conn.inputStream.bufferedReader().useLines { lines ->
    lines.filter { it.startsWith("data: ") }
         .map { JSONObject(it.removePrefix("data: ")) }
         .forEach { print(it.getJSONArray("choices")
             .getJSONObject(0).getJSONObject("delta").optString("content")) }
}
""".trim()

    /** One tap copies everything needed to call this phone from anywhere. */
    fun bundle(base: String, key: String, model: String) = """
Base URL : $base/v1
API Key  : $key
Model    : $model

--- curl ---
${curl(base, key, model)}

--- Python (openai sdk) ---
${python(base, key, model)}
""".trim()
}
