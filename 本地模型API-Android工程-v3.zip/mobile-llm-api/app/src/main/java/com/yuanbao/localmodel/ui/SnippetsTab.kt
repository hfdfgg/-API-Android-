package com.yuanbao.localmodel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuanbao.localmodel.AppGraph

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SnippetsTab() {
    val s by AppGraph.ui.collectAsState()
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(0) }
    val base = effectiveBase(s)
    val ready = base.isNotBlank() && s.apiKey.isNotBlank()
    val langs = listOf("curl", "Python", "Node.js", "Kotlin")
    val code = when (lang) {
        0 -> Snippets.curl(base, s.apiKey, s.modelName)
        1 -> Snippets.python(base, s.apiKey, s.modelName)
        2 -> Snippets.node(base, s.apiKey, s.modelName)
        else -> Snippets.kotlin(base, s.apiKey, s.modelName)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("连接信息 · 复制即可用") {
            MonoLine("Base URL : ${if (ready) "$base/v1" else "启动服务后生成"}")
            MonoLine("API Key  : ${if (s.apiKey.isBlank()) "—" else s.apiKey}")
            MonoLine("Model    : ${s.modelName}")
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = ready,
                    onClick = {
                        copyText(ctx, "完整调用包", Snippets.bundle(base, s.apiKey, s.modelName))
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("复制完整调用包") }
                TextButton(enabled = ready, onClick = { copyText(ctx, "API Key", s.apiKey) }) {
                    Text("复制密钥")
                }
            }
        }

        SectionCard("生成的调用示例") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                langs.forEachIndexed { i, label ->
                    FilterChip(
                        selected = lang == i,
                        onClick = { lang = i },
                        label = { Text(label, fontSize = 10.sp) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.fillMaxWidth().background(
                    MaterialTheme.colorScheme.surfaceVariant,
                    androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
                )
            ) {
                Text(
                    text = if (ready) code else "请先启动服务，示例会自动填入公网地址与密钥。",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .padding(12.dp)
                        .horizontalScroll(rememberScrollState()),
                )
            }
            Spacer(Modifier.height(8.dp))
            TextButton(enabled = ready, onClick = { copyText(ctx, langs[lang] + " 示例", code) }) {
                Text("复制这段代码")
            }
        }

        SectionCard("安全说明") {
            Text(
                "· 公网流量经 Cloudflare 边缘强制 HTTPS，手机上的服务只监听 127.0.0.1，原始端口不暴露。\n" +
                        "· 所有 /v1/* 接口都要 Bearer Key；/health 与文档页免鉴权，但文档页不会显示密钥。\n" +
                        "· 每 Key 每分钟 120 次限流、请求体上限 1 MiB、日志与备份都不包含密钥。\n" +
                        "· 需要更强隔离时，在 Cloudflare Zero Trust 加一层 Access 策略，或在控制台点「重置密钥」。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 20.sp,
            )
        }
        Spacer(Modifier.height(20.dp))
    }
}
