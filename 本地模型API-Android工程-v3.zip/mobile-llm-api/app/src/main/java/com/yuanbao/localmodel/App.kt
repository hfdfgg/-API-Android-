package com.yuanbao.localmodel

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import com.yuanbao.localmodel.core.Accelerator
import com.yuanbao.localmodel.core.BenchResult
import com.yuanbao.localmodel.core.ChatController
import com.yuanbao.localmodel.core.DeviceProbe
import com.yuanbao.localmodel.core.DeviceProfile
import com.yuanbao.localmodel.core.ModelSlot
import com.yuanbao.localmodel.core.PerfMode
import com.yuanbao.localmodel.core.PerfPolicy
import com.yuanbao.localmodel.service.LlmService
import com.yuanbao.localmodel.util.LogBus
import com.yuanbao.localmodel.util.ModelRepository
import com.yuanbao.localmodel.util.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ChatLine(val role: String, val text: String)

data class UiState(
    val running: Boolean = false,
    val port: Int = 8080,
    val lanMode: Boolean = false,
    val perfMode: String = PerfMode.BALANCED.id,
    val promptTemplate: String = "auto",
    val tunnelMode: String = "off",
    val tunnelToken: String = "",
    val publicHostname: String = "",
    val externalBase: String = "",
    val tunnelStatus: String = "未开启",
    val publicUrl: String = "",
    val localUrl: String = "",
    val lanUrl: String = "",
    val apiKey: String = "",
    val modelName: String = "未导入模型",
    val modelSize: String = "",
    val modelPath: String = "",
    val modelFormat: String = "",
    val engineName: String = "",
    val engineReal: Boolean = false,
    val offloaded: Boolean = false,
    val deviceInfo: String = "",
    val policyInfo: String = "",
    val memoryAdvice: String = "",
    val bench: BenchResult? = null,
    val logs: List<String> = emptyList(),
    val chat: List<ChatLine> = emptyList(),
    val streaming: Boolean = false,
    val progressMs: Long = 0L,
    val firstTokenMs: Long = 0L,
    val tps: Double = 0.0,
)

class App : Application() {
    private var startedActivities = 0

    override fun onCreate() {
        super.onCreate()
        AppGraph.init(applicationContext)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: Activity) {
                // Never start the service implicitly: foreground-service starts
                // from the background are restricted on Android 12+.
                if (startedActivities == 0 && AppGraph.ui.value.offloaded) {
                    LlmService.reload(this@App)
                }
                startedActivities++
            }
            override fun onActivityStopped(a: Activity) {
                startedActivities = (startedActivities - 1).coerceAtLeast(0)
                if (startedActivities == 0 && AppGraph.ui.value.running) {
                    LlmService.offload(this@App)
                }
            }
            override fun onActivityCreated(a: Activity, s: Bundle?) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, s: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}

/**
 * One process-wide graph. Activity, Service and background jobs all read/write
 * the same StateFlow; no business logic lives inside Composables.
 */
object AppGraph {
    private lateinit var ctx: Context

    /** Independent of any Activity/Compose lifecycle — chat survives tab switches. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val prefs: Prefs by lazy { Prefs(ctx) }
    val models: ModelRepository by lazy { ModelRepository(ctx) }
    val logs: LogBus by lazy { LogBus(appScope) }
    val device: DeviceProfile by lazy { DeviceProbe.detect(ctx) }
    val chat: ChatController by lazy { ChatController() }

    private val _policy = MutableStateFlow<PerfPolicy?>(null)
    val policy: StateFlow<PerfPolicy?> = _policy.asStateFlow()

    private val _state = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _state.asStateFlow()

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        refreshPolicy()
        update {
            it.copy(
                perfMode = prefs.perfMode,
                promptTemplate = prefs.promptTemplate,
                tunnelMode = prefs.tunnelMode,
                tunnelToken = prefs.tunnelToken,
                publicHostname = prefs.publicHostname,
                externalBase = prefs.externalBase,
                port = prefs.port,
                lanMode = prefs.lanMode,
                apiKey = prefs.apiKey(),
                deviceInfo = device.summary,
            )
        }
        models.current()?.let { m ->
            update {
                it.copy(modelName = m.name, modelSize = models.formatSize(m.sizeBytes),
                    modelPath = m.path, modelFormat = m.format.label,
                    memoryAdvice = com.yuanbao.localmodel.core.MemoryAdvisor
                        .evaluate(m.sizeBytes, device).advice)
            }
        }
    }

    fun context(): Context = ctx

    fun refreshPolicy() {
        val p = Accelerator.policy(PerfMode.from(prefs.perfMode), device)
        _policy.value = p
        update { it.copy(policyInfo = Accelerator.explain(p, device)) }
    }

    fun update(block: (UiState) -> UiState) {
        _state.value = block(_state.value)
    }

    @Volatile
    private var lastBoostMs = 0L

    /** User starts typing → pre-warm once every 3s, not on every keystroke. */
    fun preBoost() {
        if (!ui.value.running) return
        val now = System.currentTimeMillis()
        if (now - lastBoostMs < 3_000) return
        lastBoostMs = now
        appScope.launch(Dispatchers.Default) { ModelSlot.preBoost() }
    }
}
