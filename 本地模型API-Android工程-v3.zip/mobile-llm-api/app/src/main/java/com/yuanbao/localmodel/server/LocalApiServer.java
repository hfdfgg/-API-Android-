package com.yuanbao.localmodel.server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Local LLM API Server — zero external dependencies, Java 8 compatible.
 *
 * Runs identically on:
 *   - Android (embedded, called from LlmService)
 *   - any JVM (java LocalApiServer.java --port 8080) for protocol verification
 *
 * Security model:
 *   - binds to 127.0.0.1 by default; only Cloudflare Tunnel can reach it from the internet
 *   - every /v1/* endpoint requires a Bearer API key (random 256-bit)
 *   - per-key rate limiting, 1 MiB body cap, idle timeout, no key ever logged
 *   - cleartext is ONLY permitted for loopback (see network_security_config.xml)
 *
 * Wire protocol: OpenAI-compatible /v1/chat/completions, /v1/completions,
 * /v1/models, with SSE streaming and chunked transfer encoding.
 */
public final class LocalApiServer {

    // ------------------------------------------------------------------ config

    public static final class Config {
        public String host = "127.0.0.1";
        public int port = 8080;
        public String apiKey = generateApiKey();
        public String modelId = "local-model";
        public boolean docsEnabled = true;
        public int maxBodyBytes = 1024 * 1024;
        public int maxConcurrent = 16;
        /** SSE micro-batching: fewer writes/flushes without breaking OpenAI clients. */
        public int sseBatchTokens = 4;
        public int sseBatchMs = 24;
        public int requestsPerMinute = 120;
        public int idleTimeoutMs = 30000;
        public int maxTokensDefault = 512;
        public int maxTokensHardCap = 4096;
        public BenchmarkHook benchmarkHook = null;
        /** Fine-grained wake lock: held only while a generation is actually running. */
        public GenerateLifecycle lifecycle = null;
    }

    public interface GenerateLifecycle {
        void onStart();
        void onEnd();
    }

    public interface LogSink {
        void log(String level, String message);
    }

    /** Stream token consumer. Implementations must be thread-confined to the request thread. */
    public interface TokenSink {
        void onToken(String token) throws IOException;
    }

    public static final class Msg {
        public final String role;
        public final String content;
        public Msg(String role, String content) { this.role = role; this.content = content; }
    }

    public static final class Prompt {
        public List<Msg> messages = new ArrayList<Msg>();
        public int maxTokens = 512;
        public double temperature = 0.7;
        public double topP = 0.95;
        public List<String> stop = Collections.emptyList();
    }

    /** Optional PP/TG benchmark provider, supplied by the Android ModelSlot. */
    public interface BenchmarkHook {
        Map<String, Object> run(int pp, int tg, int warmup);
    }

    /** Pluggable inference backend. Android supplies LlamaCppEngine; JVM self-test uses BuiltinEngine. */
    public interface Engine {
        String modelId();
        boolean isLoaded();
        /** @return the real number of generated tokens (not the number of SSE writes). */
        int generate(Prompt prompt, TokenSink sink) throws Exception;
        int estimatePromptTokens(Prompt prompt);
    }

    // ------------------------------------------------------------------ api key

    public static String generateApiKey() {
        byte[] b = new byte[32];
        new SecureRandom().nextBytes(b);
        return "lm_" + Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    /** Constant-time comparison, avoids timing oracles on the key. */
    public static boolean keyEquals(String expected, String presented) {
        if (expected == null || presented == null) return false;
        byte[] a = expected.getBytes(StandardCharsets.UTF_8);
        byte[] b = presented.getBytes(StandardCharsets.UTF_8);
        try {
            return MessageDigest.isEqual(
                    MessageDigest.getInstance("SHA-256").digest(a),
                    MessageDigest.getInstance("SHA-256").digest(b));
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ logging

    private static final class StdoutLog implements LogSink {
        public void log(String level, String message) {
            System.out.println("[" + level + "] " + message);
        }
    }

    // ------------------------------------------------------------------ state

    private final Config config;
    private final LogSink log;
    private volatile Engine engine;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicLong startedAt = new AtomicLong(0);
    private final AtomicLong requestSeq = new AtomicLong(0);
    private final RateLimiter limiter;
    private ServerSocket serverSocket;
    private ThreadPoolExecutor pool;
    private Thread acceptThread;

    public LocalApiServer(Config config, Engine engine, LogSink log) {
        this.config = config == null ? new Config() : config;
        this.engine = engine == null ? new BuiltinEngine(this.config.modelId) : engine;
        this.log = log == null ? new StdoutLog() : log;
        this.limiter = new RateLimiter(this.config.requestsPerMinute);
    }

    public void setEngine(Engine e) {
        this.engine = e;
        if (e != null && e.modelId() != null) this.config.modelId = e.modelId();
    }

    public Engine getEngine() { return engine; }

    public String baseUrl() {
        return "http://" + ("0.0.0.0".equals(config.host) ? "127.0.0.1" : config.host) + ":" + config.port;
    }

    public boolean isRunning() { return running.get(); }

    public synchronized void start() throws IOException {
        if (running.get()) return;
        int max = Math.max(4, config.maxConcurrent);
        // AbortPolicy + 503: never let a slow inference occupy the accept thread
        // (CallerRunsPolicy used to stall every new connection under load).
        pool = new ThreadPoolExecutor(max, max, 30L, TimeUnit.SECONDS,
                new ArrayBlockingQueue<Runnable>(64), new ThreadPoolExecutor.AbortPolicy());
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(config.host, config.port));
        running.set(true);
        startedAt.set(System.currentTimeMillis());
        acceptThread = new Thread(new Runnable() {
            public void run() { acceptLoop(); }
        }, "llm-api-accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
        log.log("INFO", "server up on " + config.host + ":" + config.port
                + " | model=" + config.modelId + " | engine=" + engine.getClass().getSimpleName());
    }

    public synchronized void stop() {
        running.set(false);
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) {}
        if (pool != null) pool.shutdownNow();
        log.log("INFO", "server stopped");
    }

    private void acceptLoop() {
        while (running.get()) {
            Socket s = null;
            try {
                s = serverSocket.accept();
                s.setSoTimeout(config.idleTimeoutMs);
                s.setTcpNoDelay(true);
                final Socket cs = s;
                pool.execute(new Runnable() {
                    public void run() { handleConnection(cs); }
                });
            } catch (java.util.concurrent.RejectedExecutionException busy) {
                log.log("WARN", "concurrency limit reached -> 503");
                writeBusy(s);
            } catch (IOException e) {
                if (running.get()) log.log("WARN", "accept: " + e.getMessage());
                return;
            }
        }
    }

    private void writeBusy(Socket s) {
        if (s == null) return;
        try {
            OutputStream out = new BufferedOutputStream(s.getOutputStream(), 1024);
            Map<String, Object> e = new LinkedHashMap<String, Object>();
            e.put("message", "Too many concurrent requests. Retry shortly.");
            e.put("type", "server_busy");
            e.put("code", "server_busy");
            Map<String, Object> root = new LinkedHashMap<String, Object>();
            root.put("error", e);
            writeRaw(out, 503, "Service Unavailable", "application/json; charset=utf-8",
                    Json.stringify(root).getBytes(StandardCharsets.UTF_8),
                    commonHeaders(null, false), false);
            out.flush();
        } catch (IOException ignored) {
        } finally {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    // ------------------------------------------------------------------ http

    private static final class Req {
        String method, target, version;
        Map<String, String> headers = new HashMap<String, String>();
        byte[] body = new byte[0];
        String path;
    }

    private static final class HttpError extends Exception {
        final int status;
        final String code;
        final Map<String, String> headers;
        HttpError(int status, String code, String msg) { this(status, code, msg, null); }
        HttpError(int status, String code, String msg, Map<String, String> headers) {
            super(msg);
            this.status = status;
            this.code = code;
            this.headers = headers;
        }
    }

    private void handleConnection(Socket s) {
        try {
            InputStream in = new BufferedInputStream(s.getInputStream(), 8192);
            OutputStream out = new BufferedOutputStream(s.getOutputStream(), 8192);
            boolean keepAlive = true;
            while (keepAlive && running.get()) {
                Req r = null;
                try {
                    r = readRequest(in);
                    if (r == null) break;
                    String conn = r.headers.get("connection");
                    keepAlive = !"close".equalsIgnoreCase(conn == null ? "" : conn);
                    dispatch(r, out);
                } catch (HttpError e) {
                    Map<String, String> h = commonHeaders(r == null ? null : r.headers.get("origin"), false);
                    if (e.headers != null) h.putAll(e.headers);
                    writeJsonErrorWithHeaders(out, e.status, e.code, e.getMessage(), false, h);
                    keepAlive = false;
                } catch (Exception e) {
                    log.log("ERROR", "request failed: " + e.getClass().getSimpleName());
                    writeJsonError(out, 500, "internal_error", "inference failed", false);
                    keepAlive = false;
                }
                out.flush();
                if (!keepAlive) break;
            }
        } catch (Exception e) {
            // client disconnects during streaming are normal; never log headers or keys
            log.log("DEBUG", "connection closed: " + e.getClass().getSimpleName());
        } finally {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    private Req readRequest(InputStream in) throws IOException, HttpError {
        String line = readLine(in);
        if (line == null || line.isEmpty()) return null;
        String[] parts = line.split(" ");
        if (parts.length < 3) throw new HttpError(400, "bad_request", "malformed request line");
        Req r = new Req();
        r.method = parts[0].toUpperCase(Locale.US);
        r.target = parts[1];
        r.version = parts[2];
        int q = r.target.indexOf('?');
        r.path = q >= 0 ? r.target.substring(0, q) : r.target;

        int headerCount = 0;
        while (true) {
            String h = readLine(in);
            if (h == null) return null;
            if (h.isEmpty()) break;
            if (++headerCount > 100) throw new HttpError(431, "header_too_large", "too many headers");
            int c = h.indexOf(':');
            if (c > 0) {
                r.headers.put(h.substring(0, c).trim().toLowerCase(Locale.US), h.substring(c + 1).trim());
            }
        }

        String cl = r.headers.get("content-length");
        if (cl != null) {
            int len;
            try { len = Integer.parseInt(cl); }
            catch (NumberFormatException e) { throw new HttpError(400, "bad_request", "invalid content-length"); }
            if (len < 0 || len > config.maxBodyBytes)
                throw new HttpError(413, "payload_too_large", "body exceeds " + config.maxBodyBytes + " bytes");
            r.body = new byte[len];
            int off = 0;
            while (off < len) {
                int n = in.read(r.body, off, len - off);
                if (n < 0) throw new HttpError(400, "bad_request", "truncated body");
                off += n;
            }
        } else if ("chunked".equalsIgnoreCase(r.headers.get("transfer-encoding") == null ? "" : r.headers.get("transfer-encoding"))) {
            r.body = readChunkedBody(in);
        }
        return r;
    }

    private byte[] readChunkedBody(InputStream in) throws IOException, HttpError {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while (true) {
            int size = Integer.parseInt(readLine(in).split(";")[0].trim(), 16);
            if (size == 0) { readLine(in); break; }
            if (bos.size() + size > config.maxBodyBytes)
                throw new HttpError(413, "payload_too_large", "body too large");
            byte[] chunk = new byte[size];
            int off = 0;
            while (off < size) { int n = in.read(chunk, off, size - off); if (n < 0) return bos.toByteArray(); off += n; }
            bos.write(chunk, 0, size);
            readLine(in);
        }
        return bos.toByteArray();
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') {
                if (b.size() > 0 && b.toByteArray()[b.size() - 1] == '\r') {
                    byte[] arr = b.toByteArray();
                    return new String(arr, 0, arr.length - 1, StandardCharsets.UTF_8);
                }
                return new String(b.toByteArray(), StandardCharsets.UTF_8);
            }
            if (b.size() > 16384) throw new IOException("header line too long");
            b.write(c);
        }
        return b.size() == 0 ? null : new String(b.toByteArray(), StandardCharsets.UTF_8);
    }

    // ------------------------------------------------------------------ routing

    private void dispatch(Req r, OutputStream out) throws Exception {
        long t0 = System.nanoTime();
        String origin = r.headers.get("origin");

        if ("OPTIONS".equals(r.method)) {
            writeRaw(out, 204, "No Content", "text/plain", new byte[0], commonHeaders(origin, false), true);
            return;
        }

        if ("GET".equals(r.method) && "/health".equals(r.path)) {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("status", "ok");
            m.put("model", config.modelId);
            m.put("engine", engine.getClass().getSimpleName());
            m.put("model_loaded", engine.isLoaded());
            m.put("uptime_ms", System.currentTimeMillis() - startedAt.get());
            writeJson(out, 200, m, origin, true);
            return;
        }

        if ("GET".equals(r.method) && ("/".equals(r.path) || "/docs".equals(r.path))) {
            if (!config.docsEnabled) throw new HttpError(404, "not_found", "docs disabled");
            byte[] html = docsHtml().getBytes(StandardCharsets.UTF_8);
            Map<String, String> h = commonHeaders(origin, false);
            h.put("Content-Type", "text/html; charset=utf-8");
            writeRaw(out, 200, "OK", "text/html; charset=utf-8", html, h, true);
            return;
        }

        // everything below is authenticated
        String presented = extractKey(r);
        if (!keyEquals(config.apiKey, presented)) {
            Map<String, String> h = new LinkedHashMap<String, String>();
            h.put("WWW-Authenticate", "Bearer realm=\"local-llm\"");
            throw new HttpError(401, "invalid_api_key",
                    "Missing or invalid API key. Send Authorization: Bearer <key>.", h);
        }
        if (!limiter.allow(config.apiKey)) {
            throw new HttpError(429, "rate_limited",
                    "Too many requests. Limit: " + config.requestsPerMinute + "/min.");
        }

        if ("GET".equals(r.method) && "/v1/models".equals(r.path)) {
            Map<String, Object> item = new LinkedHashMap<String, Object>();
            item.put("id", config.modelId);
            item.put("object", "model");
            item.put("created", startedAt.get() / 1000);
            item.put("owned_by", "local-device");
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("object", "list");
            m.put("data", Collections.singletonList(item));
            writeJson(out, 200, m, origin, true);
            return;
        }

        if ("POST".equals(r.method) && "/v1/benchmark".equals(r.path)) {
            handleBenchmark(r, out, origin);
            return;
        }

        if ("POST".equals(r.method) && ("/v1/chat/completions".equals(r.path) || "/v1/completions".equals(r.path))) {
            boolean chat = "/v1/chat/completions".equals(r.path);
            handleCompletion(r, out, origin, chat, t0);
            return;
        }

        throw new HttpError(404, "not_found", "No route for " + r.method + " " + r.path);
    }

    private void handleBenchmark(Req r, OutputStream out, String origin) throws Exception {
        if (config.benchmarkHook == null) {
            throw new HttpError(501, "benchmark_unavailable",
                    "This build has no native model slot loaded.");
        }
        int pp = 512, tg = 128, warm = 16;
        if (r.body.length > 0) {
            Object parsed = Json.parse(new String(r.body, StandardCharsets.UTF_8));
            if (parsed instanceof Map) {
                Map<String, Object> b = (Map<String, Object>) parsed;
                pp = clamp(intVal(b.get("pp"), pp), 8, 4096);
                tg = clamp(intVal(b.get("tg"), tg), 8, 2048);
                warm = clamp(intVal(b.get("warmup"), warm), 0, 128);
            }
        }
        log.log("INFO", "benchmark start pp=" + pp + " tg=" + tg);
        Map<String, Object> result;
        if (config.lifecycle != null) config.lifecycle.onStart();
        try {
            result = config.benchmarkHook.run(pp, tg, warm);
        } finally {
            if (config.lifecycle != null) config.lifecycle.onEnd();
        }
        writeJson(out, 200, result, origin, true);
        log.log("INFO", "benchmark done");
    }

    private String extractKey(Req r) {
        String a = r.headers.get("authorization");
        if (a != null && a.regionMatches(true, 0, "Bearer ", 0, 7)) return a.substring(7).trim();
        return r.headers.get("x-api-key");
    }

    @SuppressWarnings("unchecked")
    private void handleCompletion(Req r, OutputStream out, String origin, boolean chat, long t0) throws Exception {
        String body = new String(r.body, StandardCharsets.UTF_8);
        Object parsed;
        try { parsed = Json.parse(body); }
        catch (Exception e) { throw new HttpError(400, "invalid_json", "Request body is not valid JSON"); }
        if (!(parsed instanceof Map)) throw new HttpError(400, "invalid_request", "body must be a JSON object");
        Map<String, Object> req = (Map<String, Object>) parsed;

        Prompt p = new Prompt();
        Object msgs = req.get("messages");
        if (chat) {
            if (msgs instanceof List) {
                for (Object o : (List<Object>) msgs) {
                    if (o instanceof Map) {
                        Map<String, Object> mm = (Map<String, Object>) o;
                        p.messages.add(new Msg(str(mm.get("role"), "user"), str(mm.get("content"), "")));
                    }
                }
            } else {
                throw new HttpError(400, "invalid_request", "messages[] is required");
            }
            if (p.messages.isEmpty()) throw new HttpError(400, "invalid_request", "messages[] must not be empty");
        } else {
            Object pr = req.get("prompt");
            p.messages.add(new Msg("user", pr == null ? "" : String.valueOf(pr)));
        }

        p.maxTokens = clamp(intVal(req.get("max_tokens"), config.maxTokensDefault), 1, config.maxTokensHardCap);
        p.temperature = clamp(dblVal(req.get("temperature"), 0.7), 0.0, 2.0);
        p.topP = clamp(dblVal(req.get("top_p"), 0.95), 0.0, 1.0);
        Object st = req.get("stop");
        if (st instanceof String) p.stop = Collections.singletonList((String) st);
        else if (st instanceof List) {
            List<String> l = new ArrayList<String>();
            for (Object o : (List<Object>) st) if (o != null) l.add(String.valueOf(o));
            p.stop = l;
        }

        if (!engine.isLoaded())
            throw new HttpError(503, "model_not_loaded", "No model loaded. Import a GGUF file in the app first.");

        boolean stream = boolVal(req.get("stream"), false);
        String id = "chatcmpl-" + Long.toHexString(requestSeq.incrementAndGet())
                + Long.toHexString(System.nanoTime());
        long created = System.currentTimeMillis() / 1000L;
        String model = str(req.get("model"), config.modelId);

        // PocketPal lesson: keep the screen/CPU awake ONLY during inference.
        if (config.lifecycle != null) config.lifecycle.onStart();
        try {
            if (stream) {
                streamCompletion(out, origin, id, created, model, chat, p);
            } else {
                final StringBuilder sb = new StringBuilder();
                final long[] first = {-1};
                long genStart = System.nanoTime();
                int generated = engine.generate(p, new TokenSink() {
                    public void onToken(String t) {
                        if (first[0] < 0) first[0] = System.nanoTime();
                        sb.append(t);
                    }
                });
                long totalMs = (System.nanoTime() - genStart) / 1000000L;
                long firstMs = first[0] < 0 ? 0 : (first[0] - genStart) / 1000000L;
                writeJson(out, 200, completionObject(id, created, model, chat, sb.toString(),
                        p, generated, firstMs, totalMs, false), origin, true);
            }
        } finally {
            if (config.lifecycle != null) config.lifecycle.onEnd();
        }
        log.log("INFO", reqLabel(chat) + " 200 " + ((System.nanoTime() - t0) / 1000000L) + "ms stream=" + stream);
    }

    private void streamCompletion(OutputStream out, String origin, String id, long created,
                                  String model, boolean chat, Prompt p) throws Exception {
        Map<String, String> h = commonHeaders(origin, true);
        h.put("Content-Type", "text/event-stream; charset=utf-8");
        h.put("Cache-Control", "no-cache, no-transform");
        h.put("X-Accel-Buffering", "no");
        h.put("Transfer-Encoding", "chunked");
        h.put("Connection", "keep-alive");

        writeStatusHeaders(out, 200, "OK", h);
        out.flush();

        // initial role delta (OpenAI SDK expects it)
        Map<String, Object> roleDelta = new LinkedHashMap<String, Object>();
        roleDelta.put("role", "assistant");
        sse(out, chunkObject(id, created, model, roleDelta, null, chat));

        final long[] first = {-1};
        final long genStart = System.nanoTime();
        final int batchTokens = Math.max(1, config.sseBatchTokens);
        final long batchMs = Math.max(0, config.sseBatchMs);

        /**
         * Micro-batching bridge. The native engine already groups ~6 tokens per
         * JNI call; here we group again before writing SSE. First piece goes out
         * immediately (low time-to-first-byte), later pieces are merged into
         * fewer chunks/flushes — dramatically less syscalls and less client-side
         * recomposition while staying 100% OpenAI-SDK compatible.
         */
        class MicroBatchSink implements TokenSink {
            private final StringBuilder buf = new StringBuilder();
            private int pieces = 0;
            private long lastFlush = System.nanoTime();
            private boolean firstSent = false;

            public void onToken(String t) throws IOException {
                if (t == null || t.isEmpty()) return;
                if (first[0] < 0) first[0] = System.nanoTime();
                buf.append(t);
                pieces++;
                long now = System.nanoTime();
                if (!firstSent || pieces >= batchTokens
                        || (now - lastFlush) / 1000000L >= batchMs) {
                    flush();
                }
            }

            void flush() throws IOException {
                if (buf.length() == 0) return;
                Map<String, Object> d = new LinkedHashMap<String, Object>();
                d.put("content", buf.toString());
                sse(out, chunkObject(id, created, model, d, null, chat));
                buf.setLength(0);
                pieces = 0;
                lastFlush = System.nanoTime();
                firstSent = true;
            }
        }

        MicroBatchSink sink = new MicroBatchSink();
        int generated = engine.generate(p, sink);
        sink.flush();

        sse(out, chunkObject(id, created, model, new LinkedHashMap<String, Object>(), "stop", chat));
        long totalMs = (System.nanoTime() - genStart) / 1000000L;
        long firstMs = first[0] < 0 ? 0 : (first[0] - genStart) / 1000000L;
        // final chunk carries local timing extensions
        Map<String, Object> last = chunkObject(id, created, model, new LinkedHashMap<String, Object>(), null, chat);
        Map<String, Object> usage = new LinkedHashMap<String, Object>();
        usage.put("prompt_tokens", engine.estimatePromptTokens(p));
        usage.put("completion_tokens", generated);
        usage.put("total_tokens", engine.estimatePromptTokens(p) + generated);
        Map<String, Object> timings = new LinkedHashMap<String, Object>();
        timings.put("first_token_ms", firstMs);
        timings.put("total_ms", totalMs);
        timings.put("tokens_per_second", totalMs == 0 ? 0 : Math.round(generated * 1000.0 / totalMs * 10) / 10.0);
        last.put("usage", usage);
        last.put("local_timings", timings);
        sse(out, last);
        writeChunk(out, "data: [DONE]\n\n".getBytes(StandardCharsets.UTF_8));
        writeChunk(out, new byte[0]); // terminating 0-length chunk
        out.flush();
    }

    private void sse(OutputStream out, Object chunk) throws IOException {
        writeChunk(out, ("data: " + Json.stringify(chunk) + "\n\n").getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private static void writeChunk(OutputStream out, byte[] data) throws IOException {
        out.write((Integer.toHexString(data.length) + "\r\n").getBytes(StandardCharsets.US_ASCII));
        if (data.length > 0) out.write(data);
        out.write("\r\n".getBytes(StandardCharsets.US_ASCII));
    }

    private Map<String, Object> chunkObject(String id, long created, String model,
                                            Map<String, Object> delta, Object finishReason, boolean chat) {
        Map<String, Object> c = new LinkedHashMap<String, Object>();
        c.put("index", 0);
        c.put("delta", delta);
        c.put("finish_reason", finishReason);
        Map<String, Object> root = new LinkedHashMap<String, Object>();
        root.put("id", id);
        root.put("object", chat ? "chat.completion.chunk" : "text_completion.chunk");
        root.put("created", created);
        root.put("model", model);
        root.put("choices", Collections.singletonList(c));
        return root;
    }

    private Map<String, Object> completionObject(String id, long created, String model, boolean chat,
                                                 String content, Prompt p, int completionTokens,
                                                 long firstMs, long totalMs, boolean streaming) {
        Map<String, Object> msg = new LinkedHashMap<String, Object>();
        msg.put("role", "assistant");
        msg.put("content", content);
        Map<String, Object> choice = new LinkedHashMap<String, Object>();
        choice.put("index", 0);
        choice.put("message", msg);
        choice.put("finish_reason", "stop");
        if (!chat) choice.put("text", content);

        int promptTokens = engine.estimatePromptTokens(p);
        Map<String, Object> usage = new LinkedHashMap<String, Object>();
        usage.put("prompt_tokens", promptTokens);
        usage.put("completion_tokens", completionTokens);
        usage.put("total_tokens", promptTokens + completionTokens);

        Map<String, Object> timings = new LinkedHashMap<String, Object>();
        timings.put("first_token_ms", firstMs);
        timings.put("total_ms", totalMs);
        timings.put("tokens_per_second", totalMs == 0 ? 0 : Math.round(completionTokens * 1000.0 / totalMs * 10) / 10.0);

        Map<String, Object> root = new LinkedHashMap<String, Object>();
        root.put("id", id);
        root.put("object", chat ? "chat.completion" : "text_completion");
        root.put("created", created);
        root.put("model", model);
        root.put("choices", Collections.singletonList(choice));
        root.put("usage", usage);
        root.put("local_timings", timings);
        return root;
    }

    private static String reqLabel(boolean chat) { return chat ? "chat/completions" : "completions"; }

    // ------------------------------------------------------------------ responses

    private Map<String, String> commonHeaders(String origin, boolean sse) {
        Map<String, String> h = new LinkedHashMap<String, String>();
        h.put("Access-Control-Allow-Origin", origin == null ? "*" : origin);
        h.put("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        h.put("Access-Control-Allow-Headers", "Authorization, X-API-Key, Content-Type");
        h.put("Access-Control-Max-Age", "600");
        h.put("X-Content-Type-Options", "nosniff");
        h.put("X-Frame-Options", "DENY");
        h.put("Referrer-Policy", "no-referrer");
        h.put("Cache-Control", "no-store");
        h.put("Server", "LocalLLM/1.0");
        return h;
    }

    private void writeJson(OutputStream out, int status, Object obj, String origin, boolean keepAlive) throws IOException {
        Map<String, String> h = commonHeaders(origin, false);
        h.put("Content-Type", "application/json; charset=utf-8");
        writeRaw(out, status, statusText(status), "application/json; charset=utf-8",
                Json.stringify(obj).getBytes(StandardCharsets.UTF_8), h, keepAlive);
    }

    private void writeJsonError(OutputStream out, int status, String code, String msg,
                                boolean keepAlive) throws IOException {
        writeJsonErrorWithHeaders(out, status, code, msg, keepAlive, commonHeaders(null, false));
    }

    private void writeJsonErrorWithHeaders(OutputStream out, int status, String code, String msg,
                                           boolean keepAlive, Map<String, String> h) throws IOException {
        Map<String, Object> e = new LinkedHashMap<String, Object>();
        e.put("message", msg);
        e.put("type", "invalid_request_error");
        e.put("code", code);
        Map<String, Object> root = new LinkedHashMap<String, Object>();
        root.put("error", e);
        h.put("Content-Type", "application/json; charset=utf-8");
        writeRaw(out, status, statusText(status), "application/json; charset=utf-8",
                Json.stringify(root).getBytes(StandardCharsets.UTF_8), h, keepAlive);
    }

    private void writeRaw(OutputStream out, int status, String reason, String ctype,
                          byte[] body, Map<String, String> headers, boolean keepAlive) throws IOException {
        Map<String, String> h = new LinkedHashMap<String, String>(headers);
        if (ctype != null && !h.containsKey("Content-Type")) h.put("Content-Type", ctype);
        h.put("Content-Length", String.valueOf(body.length));
        h.put("Connection", keepAlive ? "keep-alive" : "close");
        writeStatusHeaders(out, status, reason, h);
        out.write(body);
    }

    private void writeStatusHeaders(OutputStream out, int status, String reason,
                                    Map<String, String> h) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n");
        sb.append("Date: ").append(new java.util.Date().toString()).append("\r\n");
        for (Map.Entry<String, String> e : h.entrySet()) {
            sb.append(e.getKey()).append(": ").append(e.getValue()).append("\r\n");
        }
        sb.append("\r\n");
        out.write(sb.toString().getBytes(StandardCharsets.US_ASCII));
    }

    private static String statusText(int s) {
        switch (s) {
            case 200: return "OK";
            case 204: return "No Content";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 404: return "Not Found";
            case 413: return "Payload Too Large";
            case 429: return "Too Many Requests";
            case 431: return "Request Header Fields Too Large";
            case 503: return "Service Unavailable";
            default: return "Error";
        }
    }

    // ------------------------------------------------------------------ helpers

    private static String str(Object o, String d) { return o == null ? d : String.valueOf(o); }

    private static int intVal(Object o, int d) {
        if (o instanceof Number) return ((Number) o).intValue();
        if (o instanceof String) { try { return Integer.parseInt((String) o); } catch (Exception e) {} }
        return d;
    }

    private static double dblVal(Object o, double d) {
        if (o instanceof Number) return ((Number) o).doubleValue();
        if (o instanceof String) { try { return Double.parseDouble((String) o); } catch (Exception e) {} }
        return d;
    }

    private static boolean boolVal(Object o, boolean d) {
        if (o instanceof Boolean) return (Boolean) o;
        return d;
    }

    private static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    private static double clamp(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

    // ------------------------------------------------------------------ rate limit

    private static final class RateLimiter {
        private final int limit;
        private final ConcurrentHashMap<String, long[]> windows = new ConcurrentHashMap<String, long[]>();
        RateLimiter(int limit) { this.limit = limit; }
        boolean allow(String key) {
            long now = System.currentTimeMillis() / 60000L;
            long[] w = windows.get(key);
            if (w == null) {
                windows.putIfAbsent(key, new long[]{now, 0});
                w = windows.get(key);
            }
            synchronized (w) {
                if (w[0] != now) { w[0] = now; w[1] = 0; }
                if (w[1] >= limit) return false;
                w[1]++;
                return true;
            }
        }
    }

    // ------------------------------------------------------------------ built-in engine (self-test / demo)

    /** Deterministic lightweight generator so the full API chain works with zero model file. */
    public static final class BuiltinEngine implements Engine {
        private final String id;
        private final long tokenDelayMicros;
        public BuiltinEngine(String id) { this(id, 6000L); }
        public BuiltinEngine(String id, long tokenDelayMicros) {
            this.id = id == null ? "builtin-echo" : id;
            this.tokenDelayMicros = tokenDelayMicros;
        }
        public String modelId() { return id; }
        public boolean isLoaded() { return true; }
        public int estimatePromptTokens(Prompt p) {
            int n = 0;
            for (Msg m : p.messages) n += Math.max(1, m.content.length() / 4);
            return n;
        }
        public int generate(Prompt prompt, TokenSink sink) throws Exception {
            String last = "";
            for (int i = prompt.messages.size() - 1; i >= 0; i--) {
                if ("user".equals(prompt.messages.get(i).role)) { last = prompt.messages.get(i).content; break; }
            }
            String reply = "我在本机离线运行，没有走任何云端推理。你刚才说的是：「" + last.trim()
                    + "」。当前是内置自检引擎；导入 GGUF 模型后，这里会输出真实模型的逐 token 流式结果。"
                    + " 服务已启用 Bearer 鉴权、SSE 流式与公网 HTTPS 隧道，可直接用 OpenAI SDK 调用。";
            List<String> tokens = tokenize(reply);
            int cap = Math.min(tokens.size(), Math.max(1, prompt.maxTokens));
            for (int i = 0; i < cap; i++) {
                sink.onToken(tokens.get(i));
                if (tokenDelayMicros > 0) {
                    long deadline = System.nanoTime() + tokenDelayMicros * 1000L;
                    while (System.nanoTime() < deadline) {
                        java.util.concurrent.locks.LockSupport.parkNanos(Math.min(1000L, deadline - System.nanoTime()));
                    }
                }
            }
            return cap;
        }
        private static List<String> tokenize(String s) {
            List<String> l = new ArrayList<String>();
            for (int i = 0; i < s.length(); i += 2) l.add(s.substring(i, Math.min(s.length(), i + 2)));
            return l;
        }
    }

    // ------------------------------------------------------------------ docs page (never embeds the key)

    private String docsHtml() {
        return "<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>Local LLM API</title><style>"
                + "body{margin:0;padding:20px;background:#0d1117;color:#e6edf3;font:15px/1.6 -apple-system,system-ui,sans-serif}"
                + "h1{font-size:20px}code,pre{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:10px;"
                + "display:block;overflow:auto;font-size:12px;color:#79c0ff}"
                + ".k{color:#ffa657}.tip{border-left:3px solid #3fb950;padding-left:12px;color:#8b949e}"
                + "</style></head><body><h1>Local LLM API</h1>"
                + "<p>OpenAI 兼容接口，模型运行在这台手机上。</p>"
                + "<p><b>Base URL</b>：<code>" + htmlEsc(publicBaseHint()) + "/v1</code></p>"
                + "<p><b>API Key</b>：在 APP 内查看并复制，本文档不会展示密钥。</p>"
                + "<pre>curl " + htmlEsc(publicBaseHint()) + "/v1/chat/completions \\\n"
                + "  -H \"Authorization: Bearer &lt;YOUR_API_KEY&gt;\" \\\n"
                + "  -H \"Content-Type: application/json\" \\\n"
                + "  -d '{\"model\":\"" + htmlEsc(config.modelId) + "\","
                + "\"messages\":[{\"role\":\"user\",\"content\":\"你好\"}],\"stream\":true}'</pre>"
                + "<p class=\"tip\">GET /health 免鉴权；/v1/* 全部需要 Bearer Key。"
                + "POST /v1/benchmark 可测 PP/TG 吞吐与峰值内存。"
                + "公网流量经 Cloudflare Tunnel 强制 HTTPS，服务端仅监听回环地址。</p>"
                + "</body></html>";
    }

    private String publicBaseHint() { return "https://<YOUR-TUNNEL-DOMAIN>"; }

    private static String htmlEsc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    // ------------------------------------------------------------------ minimal JSON (no deps)

    /** Recursive-descent JSON parser + serializer. Avoids third-party libs on Android. */
    public static final class Json {
        private final String s;
        private int i;
        private Json(String s) { this.s = s; }

        public static Object parse(String s) {
            if (s == null) throw new IllegalArgumentException("null json");
            Json p = new Json(s);
            p.ws();
            Object v = p.value();
            p.ws();
            if (p.i != s.length()) throw new IllegalArgumentException("trailing content at " + p.i);
            return v;
        }

        private Object value() {
            ws();
            if (i >= s.length()) throw new IllegalArgumentException("unexpected end");
            char c = s.charAt(i);
            switch (c) {
                case '{': return object();
                case '[': return array();
                case '"': return string();
                case 't': expect("true"); return Boolean.TRUE;
                case 'f': expect("false"); return Boolean.FALSE;
                case 'n': expect("null"); return null;
                default: return number();
            }
        }

        private Map<String, Object> object() {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            i++; ws();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                ws();
                String k = string();
                ws();
                if (i >= s.length() || s.charAt(i) != ':') throw new IllegalArgumentException("expected ':' at " + i);
                i++;
                m.put(k, value());
                ws();
                if (i >= s.length()) throw new IllegalArgumentException("unterminated object");
                char c = s.charAt(i++);
                if (c == '}') return m;
                if (c != ',') throw new IllegalArgumentException("expected ',' at " + (i - 1));
            }
        }

        private List<Object> array() {
            List<Object> l = new ArrayList<Object>();
            i++; ws();
            if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
            while (true) {
                l.add(value());
                ws();
                if (i >= s.length()) throw new IllegalArgumentException("unterminated array");
                char c = s.charAt(i++);
                if (c == ']') return l;
                if (c != ',') throw new IllegalArgumentException("expected ',' at " + (i - 1));
            }
        }

        private String string() {
            if (i >= s.length() || s.charAt(i) != '"') throw new IllegalArgumentException("expected string at " + i);
            i++;
            StringBuilder b = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    if (i >= s.length()) break;
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"': b.append('"'); break;
                        case '\\': b.append('\\'); break;
                        case '/': b.append('/'); break;
                        case 'b': b.append('\b'); break;
                        case 'f': b.append('\f'); break;
                        case 'n': b.append('\n'); break;
                        case 'r': b.append('\r'); break;
                        case 't': b.append('\t'); break;
                        case 'u':
                            if (i + 4 > s.length()) throw new IllegalArgumentException("bad \\u escape");
                            b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                            break;
                        default: throw new IllegalArgumentException("bad escape \\" + e);
                    }
                } else if (c < 0x20) {
                    throw new IllegalArgumentException("control char in string");
                } else {
                    b.append(c);
                }
            }
            throw new IllegalArgumentException("unterminated string");
        }

        private Object number() {
            int st = i;
            if (i < s.length() && s.charAt(i) == '-') i++;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            boolean fp = false;
            if (i < s.length() && s.charAt(i) == '.') { fp = true; i++; while (i < s.length() && Character.isDigit(s.charAt(i))) i++; }
            if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                fp = true; i++;
                if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            }
            if (i == st) throw new IllegalArgumentException("expected value at " + i);
            String n = s.substring(st, i);
            try {
                return fp ? (Object) Double.valueOf(n) : (Object) Long.valueOf(n);
            } catch (NumberFormatException e) {
                return Double.valueOf(n);
            }
        }

        private void expect(String w) {
            if (!s.regionMatches(i, w, 0, w.length())) throw new IllegalArgumentException("expected " + w + " at " + i);
            i += w.length();
        }

        private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

        @SuppressWarnings("unchecked")
        public static String stringify(Object o) {
            StringBuilder b = new StringBuilder();
            write(o, b);
            return b.toString();
        }

        private static void write(Object o, StringBuilder b) {
            if (o == null) { b.append("null"); return; }
            if (o instanceof String) { quote((String) o, b); return; }
            if (o instanceof Boolean || o instanceof Number) {
                if (o instanceof Double && (Double.isNaN((Double) o) || Double.isInfinite((Double) o))) b.append("null");
                else b.append(o.toString());
                return;
            }
            if (o instanceof Map) {
                b.append('{');
                boolean first = true;
                for (Map.Entry<String, Object> e : ((Map<String, Object>) o).entrySet()) {
                    if (!first) b.append(',');
                    first = false;
                    quote(e.getKey(), b);
                    b.append(':');
                    write(e.getValue(), b);
                }
                b.append('}');
                return;
            }
            if (o instanceof Iterable) {
                b.append('[');
                boolean first = true;
                for (Object x : (Iterable<Object>) o) {
                    if (!first) b.append(',');
                    first = false;
                    write(x, b);
                }
                b.append(']');
                return;
            }
            quote(String.valueOf(o), b);
        }

        private static void quote(String s, StringBuilder b) {
            b.append('"');
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': b.append("\\\""); break;
                    case '\\': b.append("\\\\"); break;
                    case '\n': b.append("\\n"); break;
                    case '\r': b.append("\\r"); break;
                    case '\t': b.append("\\t"); break;
                    case '\b': b.append("\\b"); break;
                    case '\f': b.append("\\f"); break;
                    default:
                        if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                        else b.append(c);
                }
            }
            b.append('"');
        }
    }

    // ------------------------------------------------------------------ JVM entry point (self-test / CI)

    /**
     * Run the exact same server on any JVM:
     *   java LocalApiServer.java --port 18080 --key lm_demo_key --fast
     * Used by scripts/verify-protocol.sh and .github/workflows/protocol-test.yml.
     */
    public static void main(String[] args) throws Exception {
        Config c = new Config();
        String key = null;
        boolean fast = false;
        boolean printKey = false;
        boolean fakeBench = false;
        for (int i = 0; i < args.length; i++) {
            if ("--port".equals(args[i]) && i + 1 < args.length) c.port = Integer.parseInt(args[++i]);
            else if ("--host".equals(args[i]) && i + 1 < args.length) c.host = args[++i];
            else if ("--key".equals(args[i]) && i + 1 < args.length) key = args[++i];
            else if ("--model".equals(args[i]) && i + 1 < args.length) c.modelId = args[++i];
            else if ("--rpm".equals(args[i]) && i + 1 < args.length) c.requestsPerMinute = Integer.parseInt(args[++i]);
            else if ("--fast".equals(args[i])) fast = true;
            else if ("--print-key".equals(args[i])) printKey = true;
            else if ("--fake-bench".equals(args[i])) fakeBench = true;
            else if ("--help".equals(args[i])) {
                System.out.println("Usage: java LocalApiServer.java [--port N] [--host IP] [--key KEY] [--model ID] [--rpm N] [--fast] [--print-key] [--fake-bench]");
                return;
            }
        }
        if (key != null) c.apiKey = key;
        if (fakeBench) {
            c.benchmarkHook = new BenchmarkHook() {
                public Map<String, Object> run(int pp, int tg, int warm) {
                    Map<String, Object> m = new LinkedHashMap<String, Object>();
                    m.put("supported", true);
                    m.put("pp_tps", 123.45);
                    m.put("tg_tps", 12.34);
                    m.put("peak_mb", 1024);
                    m.put("note", "selftest pp=" + pp + " tg=" + tg + " warm=" + warm);
                    return m;
                }
            };
        }
        final LocalApiServer srv = new LocalApiServer(c, new BuiltinEngine(c.modelId, fast ? 0L : 6000L), null);
        srv.start();
        System.out.println("BASE_URL=" + srv.baseUrl());
        // The key is NEVER written to logs. It is only echoed when the operator
        // explicitly asks for it during a local self-test. Android never calls main().
        System.out.println("API_KEY=" + (printKey ? c.apiKey : "<hidden> use --print-key for local self-test"));
        System.out.println("MODEL=" + c.modelId);
        System.out.println("READY");
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            public void run() { srv.stop(); }
        }));
        Thread.currentThread().join();
    }
}
