package com.yuanbao.localmodel.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yuanbao.localmodel.UiState
import com.yuanbao.localmodel.core.PerfMode

fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(ctx, "已复制：$label", Toast.LENGTH_SHORT).show()
}

@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun MonoLine(text: String, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface) {
    Text(
        text = text,
        modifier = modifier.fillMaxWidth(),
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        color = color,
    )
}

@Composable
fun StatusCard(s: UiState, onResetKey: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var showKey by remember { mutableStateOf(false) }
    val base = effectiveBase(s)
    val green = Color(0xFF3FB950)

    SectionCard("服务状态") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(9.dp).background(
                    if (s.running) green else Color(0xFFF85149), CircleShape
                )
            )
            Spacer(Modifier.width(8.dp))
            Text(
                when {
                    !s.running -> "已停止"
                    s.offloaded -> "运行中 · 后台已卸载模型（回前台自动恢复）"
                    else -> "运行中 · 模型常驻内存"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
            if (s.engineName.isNotBlank()) {
                Text(s.engineName, style = MaterialTheme.typography.labelSmall,
                    color = if (s.engineReal) MaterialTheme.colorScheme.secondary
                            else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (s.modelFormat.isNotBlank() || s.policyInfo.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text("${s.modelFormat} · ${PerfMode.from(s.perfMode).label} · ${s.policyInfo}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
        }

        Spacer(Modifier.height(12.dp))
        Text("Base URL（公网优先）", style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        MonoLine(if (base.isBlank()) "启动服务后生成" else "$base/v1")
        Row {
            TextButton(enabled = base.isNotBlank(),
                onClick = { copyText(ctx, "Base URL", "$base/v1") }) { Text("复制地址") }
            TextButton(enabled = base.isNotBlank(),
                onClick = { copyText(ctx, "健康检查", "$base/health") }) { Text("复制 /health") }
        }

        Spacer(Modifier.height(6.dp))
        Text("API Key", style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        MonoLine(if (showKey) s.apiKey.ifBlank { "—" } else "lm_••••••••••••••••••••••••")
        Row {
            TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "隐藏" else "显示") }
            TextButton(enabled = s.apiKey.isNotBlank(),
                onClick = { copyText(ctx, "API Key", s.apiKey) }) { Text("复制密钥") }
            TextButton(onClick = onResetKey) { Text("重置密钥") }
        }

        if (s.memoryAdvice.isNotBlank()) {
            Text(s.memoryAdvice, style = MaterialTheme.typography.labelSmall,
                color = if (s.memoryAdvice.startsWith("⚠")) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (s.firstTokenMs > 0 || s.tps > 0) {
            Spacer(Modifier.height(6.dp))
            Text("首 token ${s.firstTokenMs}ms · ${"%.1f".format(s.tps)} tok/s",
                style = MaterialTheme.typography.labelSmall, color = green)
        }
        s.bench?.takeIf { it.supported }?.let {
            Text("测速 PP ${"%.1f".format(it.ppTps)} · TG ${"%.1f".format(it.tgTps)} tok/s",
                style = MaterialTheme.typography.labelSmall, color = green)
        }
        if (s.tunnelStatus != "未开启") {
            Text("公网：${s.tunnelStatus}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
