package com.yuanbao.localmodel.core

import com.yuanbao.localmodel.server.LocalApiServer
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * PocketPal lesson #1: a single, mutex-protected model slot.
 *
 * Why this matters on a phone:
 *  - llama_context is NOT thread-safe. Concurrent /v1/chat/completions requests
 *    decoding into the same context can corrupt the KV cache or SIGSEGV.
 *  - Loading a second GGUF while one is in memory doubles the peak RAM and the
 *    system kills the app.
 *  - Switching models must NOT restart the HTTP server: the public tunnel URL,
 *    port and API Key stay valid while the engine is swapped in place.
 */
object ModelSlot {

    private val lock = ReentrantLock()
    private var raw: LocalApiServer.Engine? = null
    private var llama: com.yuanbao.localmodel.engine.LlamaCppEngine? = null
    private var wrapped: LocalApiServer.Engine? = null
    private var policy: PerfPolicy? = null

    @Volatile
    var label: String = "未加载"
        private set

    @Volatile
    var real: Boolean = false
        private set

    @Volatile
    var offloaded: Boolean = false
        private set

    /** Wrap every real engine so generation is serialized on the same lock. */
    private class Serialized(
        private val d: LocalApiServer.Engine,
        private val gate: ReentrantLock,
    ) : LocalApiServer.Engine {
        override fun modelId() = d.modelId()
        override fun isLoaded() = !ModelSlot.offloaded && d.isLoaded()
        override fun estimatePromptTokens(p: LocalApiServer.Prompt) = d.estimatePromptTokens(p)
        override fun generate(p: LocalApiServer.Prompt, s: LocalApiServer.TokenSink): Int =
            gate.withLock { d.generate(p, s) }
    }

    /**
     * Replace the engine without touching the server / tunnel / key / port.
     * Blocks until any in-flight generation finishes (same lock).
     */
    fun swap(
        next: LocalApiServer.Engine,
        native: com.yuanbao.localmodel.engine.LlamaCppEngine?,
        p: PerfPolicy,
        newLabel: String,
        newReal: Boolean,
    ) = lock.withLock {
        releaseLocked()
        raw = next
        llama = native
        policy = p
        wrapped = Serialized(next, lock)
        label = newLabel
        real = newReal
        offloaded = false
    }

    /** The engine handed to LocalApiServer. */
    fun engine(): LocalApiServer.Engine? = wrapped

    /** Hot-swap into an already running server. Returns true on success. */
    fun attach(server: LocalApiServer?) {
        val e = wrapped ?: return
        lock.withLock { server?.setEngine(e) }
    }

    /** Background auto-offload: free the native context but keep the slot. */
    fun offload() = lock.withLock {
        if (offloaded || llama == null) return@withLock
        try { llama?.close() } catch (t: Throwable) { }
        offloaded = true
        label = "已卸载（回到前台自动重载）"
    }

    fun release() = lock.withLock { releaseLocked() }

    private fun releaseLocked() {
        try { llama?.close() } catch (t: Throwable) { }
        llama = null
        raw = null
        wrapped = null
        policy = null
        offloaded = false
        label = "未加载"
        real = false
    }

    /** Benchmark runs under the same lock, on a throwaway context in native code. */
    fun benchmark(pp: Int, tg: Int, warmup: Int): BenchResult = lock.withLock {
        val e = llama
        if (e == null || offloaded) {
            BenchResult.unsupported("未加载真实 GGUF，无法测速")
        } else {
            e.benchmark(pp, tg, warmup)
        }
    }

    /** DVFS pre-boost: warm the backend while the user is still typing. */
    fun preBoost() {
        if (!offloaded) runCatching { llama?.preBoost() }
    }
}

data class BenchResult(
    val supported: Boolean,
    val ppTps: Double,
    val tgTps: Double,
    val peakMb: Long,
    val threads: Int,
    val ctx: Int,
    val note: String,
) {
    companion object {
        fun unsupported(note: String) = BenchResult(false, 0.0, 0.0, 0, 0, 0, note)
    }
}
