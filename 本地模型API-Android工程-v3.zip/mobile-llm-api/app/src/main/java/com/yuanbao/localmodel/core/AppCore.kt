package com.yuanbao.localmodel.core

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File

/** Single place for tunables. No magic numbers scattered across UI / service / engine. */
object AppConfig {
    const val DEFAULT_PORT = 8080
    const val MIN_PORT = 1024
    const val MAX_PORT = 65535

    const val RPM = 120
    const val MAX_BODY_BYTES = 1024 * 1024
    const val MAX_CONCURRENT = 8
    const val HARD_MAX_TOKENS = 2048

    const val JNI_BATCH_TOKENS = 6
    const val SSE_BATCH_TOKENS = 4
    const val SSE_BATCH_MS = 24

    const val CONNECT_TIMEOUT_MS = 5_000
    const val READ_TIMEOUT_MS = 180_000

    // PocketPal-style benchmark defaults: PP 512 / TG 128 / 16-token warmup / 3 runs.
    const val BENCH_PP = 512
    const val BENCH_TG = 128
    const val BENCH_WARMUP = 16

    /** Android must keep 25–35% RAM for the system; use 60% as the app budget. */
    const val RAM_BUDGET_RATIO = 0.60
    const val RAM_OVERHEAD_FACTOR = 1.5
}

// ---------------------------------------------------------------------------
// Device capability probe
// ---------------------------------------------------------------------------

data class DeviceProfile(
    val abis: List<String>,
    val totalCores: Int,
    val bigCores: Int,
    val bigCoreIds: List<Int>,
    val totalMemMb: Long,
    val availMemMb: Long,
    val lowRam: Boolean,
    val sdk: Int,
    val model: String,
) {
    val is64Bit: Boolean get() = abis.any { it.contains("64") }
    val summary: String
        get() = "${Build.MANUFACTURER} $model · ${abis.firstOrNull() ?: "?"} · " +
                "${bigCores}大核/${totalCores}核 · ${totalMemMb / 1024}GB · Android $sdk"

    /** e.g. "4-7" — passed to sched_setaffinity in the native layer. */
    val affinityMask: String
        get() = if (bigCoreIds.isEmpty()) "" else "${bigCoreIds.first()}-${bigCoreIds.last()}"
}

object DeviceProbe {
    fun detect(ctx: Context): DeviceProfile {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val freqs = cpuMaxFreqs()
        val bigIds = bigCoreIds(freqs, cores)
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val mi = ActivityManager.MemoryInfo()
        try { am?.getMemoryInfo(mi) } catch (t: Throwable) { }
        val totalMb = mi.totalMem / 1024 / 1024
        return DeviceProfile(
            abis = Build.SUPPORTED_ABIS.toList(),
            totalCores = cores,
            bigCores = bigIds.size.coerceAtLeast(1),
            bigCoreIds = bigIds,
            totalMemMb = totalMb,
            availMemMb = mi.availMem / 1024 / 1024,
            lowRam = (am?.isLowRamDevice == true) || totalMb in 1..4096,
            sdk = Build.VERSION.SDK_INT,
            model = Build.MODEL,
        )
    }

    private fun cpuMaxFreqs(): Map<Int, Long> {
        val out = LinkedHashMap<Int, Long>()
        for (i in 0..15) {
            val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
            if (!f.isFile) continue
            try { f.readText().trim().toLongOrNull()?.let { out[i] = it } } catch (t: Throwable) { }
        }
        return out
    }

    /** Cores within 90% of the fastest clock are "big". Contiguous range for affinity. */
    private fun bigCoreIds(freqs: Map<Int, Long>, cores: Int): List<Int> {
        if (freqs.isEmpty()) return (0 until (cores / 2).coerceAtLeast(1)).toList()
        val max = freqs.values.maxOrNull() ?: return listOf(0)
        val ids = freqs.filter { it.value >= max * 9 / 10 }.keys.sorted()
        return ids.ifEmpty { listOf(freqs.maxByOrNull { it.value }!!.key) }
    }
}

// ---------------------------------------------------------------------------
// Accelerator
// ---------------------------------------------------------------------------

enum class PerfMode(val id: String, val label: String) {
    POWER_SAVE("power", "省电"),
    BALANCED("balanced", "均衡"),
    TURBO("turbo", "极速"),
    ;
    companion object { fun from(id: String) = values().firstOrNull { it.id == id } ?: BALANCED }
}

/**
 * One policy object drives EVERY layer that affects perceived speed.
 *
 * Compatibility rule learned from PocketPal / llama.cpp:
 *   quantizing the **V** cache requires flash attention; asking for it without
 *   FA makes llama.cpp abort at model load (SIGABRT). So the default is
 *   K-only quantization (safe on every backend) and V stays f16. Symmetric
 *   K+V is only attempted in TURBO with flash explicitly enabled, and the
 *   loader falls back automatically if init fails.
 */
data class PerfPolicy(
    val threads: Int,
    val ctxSize: Int,
    val kvK: String,             // f16 | q8_0 | q4_0
    val kvV: String,             // f16 | q8_0
    val flashAttn: Boolean,
    val nBatch: Int,
    val nUbatch: Int,
    val warmup: Boolean,
    val mmap: Boolean,
    val affinityMask: String,
    val autoOffload: Boolean,
    val jniBatchTokens: Int,
    val sseBatchTokens: Int,
    val sseBatchMs: Int,
    val appMaxTokens: Int,
    val maxConcurrent: Int,
)

object Accelerator {
    fun policy(mode: PerfMode, d: DeviceProfile): PerfPolicy {
        val constrained = d.lowRam || !d.is64Bit || d.totalMemMb in 1..4096
        val baseThreads = d.bigCores.coerceIn(2, 6)

        return when (mode) {
            PerfMode.POWER_SAVE -> PerfPolicy(
                threads = baseThreads.coerceAtMost(2), ctxSize = 1024,
                kvK = "f16", kvV = "f16", flashAttn = false,
                nBatch = 256, nUbatch = 64, warmup = false, mmap = true,
                affinityMask = "", autoOffload = true,
                jniBatchTokens = AppConfig.JNI_BATCH_TOKENS,
                sseBatchTokens = AppConfig.SSE_BATCH_TOKENS, sseBatchMs = AppConfig.SSE_BATCH_MS,
                appMaxTokens = 192, maxConcurrent = 2,
            )
            PerfMode.BALANCED -> PerfPolicy(
                threads = baseThreads.coerceAtMost(if (constrained) 4 else 6),
                ctxSize = if (constrained) 1024 else 2048,
                kvK = "q8_0", kvV = "f16", flashAttn = false,   // K-only: never aborts
                nBatch = 512, nUbatch = 128, warmup = true, mmap = true,
                affinityMask = d.affinityMask, autoOffload = true,
                jniBatchTokens = AppConfig.JNI_BATCH_TOKENS,
                sseBatchTokens = AppConfig.SSE_BATCH_TOKENS, sseBatchMs = AppConfig.SSE_BATCH_MS,
                appMaxTokens = 256, maxConcurrent = if (constrained) 2 else 4,
            )
            PerfMode.TURBO -> PerfPolicy(
                threads = d.bigCores.coerceIn(2, 8).coerceAtMost(if (constrained) 4 else 8),
                ctxSize = if (constrained) 2048 else 4096,
                // Never quantize V: llama.cpp aborts at load when V is quantized
                // and flash-attn is unavailable. Flash alone is safe and still helps.
                kvK = "q8_0", kvV = "f16", flashAttn = true,
                nBatch = 512, nUbatch = 256, warmup = true, mmap = true,
                affinityMask = d.affinityMask, autoOffload = false,
                jniBatchTokens = (AppConfig.JNI_BATCH_TOKENS / 2).coerceAtLeast(2),
                sseBatchTokens = 2, sseBatchMs = 12,
                appMaxTokens = 512, maxConcurrent = if (constrained) 3 else AppConfig.MAX_CONCURRENT,
            )
        }
    }

    fun explain(p: PerfPolicy, d: DeviceProfile): String {
        val kv = when {
            p.kvK != "f16" && p.kvV != "f16" -> "KV ${p.kvK} 双量化 + FlashAttn"
            p.kvK != "f16" -> "K ${p.kvK} 量化（V 保持 F16，免 FlashAttn 不会崩）"
            else -> "KV F16"
        }
        val aff = if (p.affinityMask.isBlank()) "不绑核" else "绑大核 ${p.affinityMask}"
        return "${p.threads}线程 · ${p.ctxSize}ctx · $kv · 预填${p.nBatch} · $aff · " +
                "预热${if (p.warmup) "开" else "关"} · 微批${p.jniBatchTokens}tok · " +
                "后台${if (p.autoOffload) "自动卸载" else "常驻"}" +
                if (d.lowRam) " · 低内存保护" else ""
    }
}

/** Prevents the exact native crash PocketPal guards against. */
object ParamValidator {
    data class Safe(val kvK: String, val kvV: String, val flash: Boolean, val note: String)

    fun resolve(p: PerfPolicy): Safe {
        // V quantization without flash attention is a hard abort in llama.cpp.
        return if (p.kvV != "f16" && !p.flashAttn) {
            Safe(p.kvK, "f16", false, "已自动改回 V=F16：量化 V 必须配合 FlashAttn，否则加载会 SIGABRT")
        } else {
            Safe(p.kvK, p.kvV, p.flashAttn, "")
        }
    }
}

// ---------------------------------------------------------------------------
// Memory-first model loading (PocketPal: estimate ×1.5, budget = 60% RAM)
// ---------------------------------------------------------------------------

data class ModelFit(
    val ok: Boolean,
    val estimatedMb: Long,
    val budgetMb: Long,
    val tier: String,
    val advice: String,
)

object MemoryAdvisor {
    fun evaluate(fileBytes: Long, d: DeviceProfile): ModelFit {
        val estimatedMb = (fileBytes / 1024 / 1024 * AppConfig.RAM_OVERHEAD_FACTOR).toLong()
        val budgetMb = (d.totalMemMb * AppConfig.RAM_BUDGET_RATIO).toLong()
        val tier = when {
            d.totalMemMb >= 12288 -> "12GB+：4B 稳，可试 7–8B"
            d.totalMemMb >= 8192 -> "8GB：甜点区 3–4B Q4"
            d.totalMemMb >= 6144 -> "6GB：建议 1.5–3B Q4"
            d.totalMemMb >= 4096 -> "4GB：建议 1B 级 Q4"
            else -> "低于 4GB：只建议 <1B 模型"
        }
        val ok = estimatedMb <= budgetMb
        val advice = if (ok) {
            "预估占用 ${estimatedMb}MB / 预算 ${budgetMb}MB · $tier"
        } else {
            "⚠ 预估 ${estimatedMb}MB 超过预算 ${budgetMb}MB，加载极可能被系统杀掉。$tier"
        }
        return ModelFit(ok, estimatedMb, budgetMb, tier, advice)
    }
}

// ---------------------------------------------------------------------------
// Model formats
// ---------------------------------------------------------------------------

/**
 * Format routing. `runnable` is explicit: formats we do not actually execute are
 * never presented as working models. GGUF → llama.cpp; LiteRT-LM / ExecuTorch
 * are the two engines PocketPal also benchmarks on Android and are the natural
 * next plugins — the EngineFactory interface is already format-routed.
 */
enum class ModelFormat(val label: String, val engine: String, val runnable: Boolean) {
    GGUF("GGUF", "llama.cpp", true),
    LITERT_LM("LiteRT-LM / .task", "LiteRT-LM（预留插件）", false),
    TFLITE("TFLite", "预留插件", false),
    ONNX("ONNX", "ONNX Runtime（预留插件）", false),
    MNN("MNN", "MNN-LLM（预留插件）", false),
    EXECUTORCH("ExecuTorch .pte", "ExecuTorch（预留插件）", false),
    UNKNOWN("未知格式", "无可用引擎", false),
}

object FormatDetector {
    fun detect(f: File): ModelFormat {
        val head = ByteArray(16)
        try { f.inputStream().use { it.read(head) } } catch (t: Throwable) { return ModelFormat.UNKNOWN }
        fun ascii(a: Int, b: Int) = String(head.copyOfRange(a, b), Charsets.US_ASCII)
        if (ascii(0, 4) == "GGUF") return ModelFormat.GGUF
        if (ascii(4, 8) == "TFL3") return ModelFormat.TFLITE
        val ext = f.name.substringAfterLast('.', "").lowercase()
        return when {
            head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() &&
                    ext in listOf("task", "litertlm") -> ModelFormat.LITERT_LM
            ext == "onnx" -> ModelFormat.ONNX
            ext == "mnn" -> ModelFormat.MNN
            ext == "pte" -> ModelFormat.EXECUTORCH
            ext == "gguf" -> ModelFormat.GGUF
            else -> ModelFormat.UNKNOWN
        }
    }
}
