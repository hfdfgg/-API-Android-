package com.yuanbao.localmodel.core

import com.yuanbao.localmodel.AppGraph
import com.yuanbao.localmodel.ChatLine
import com.yuanbao.localmodel.util.ApiClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Chat lives in the APPLICATION scope, not rememberCoroutineScope().
 * Requests survive tab switches, rotation and leaving the Activity — this is
 * the same "background-safe orchestration" pattern PocketPal uses.
 *
 * No typewriter: tokens are accumulated in the client and written to the UI
 * once, when generation finishes. Progress is shown as a single timer.
 */
class ChatController {

    private var job: Job? = null
    private var ticker: Job? = null
    private var lastUserText: String = ""

    val busy: Boolean get() = job?.isActive == true

    fun send(text: String) {
        val state = AppGraph.ui.value
        val clean = text.trim()
        if (clean.isEmpty() || !state.running || busy) return
        lastUserText = clean

        val history = state.chat.filter { it.text.isNotEmpty() }
        val port = state.port
        val key = state.apiKey
        val model = state.modelName
        val maxTokens = AppGraph.policy.value?.appMaxTokens ?: 256

        AppGraph.update {
            it.copy(
                chat = it.chat + ChatLine("user", clean) + ChatLine("assistant", ""),
                streaming = true, progressMs = 0L,
                firstTokenMs = 0L, tps = 0.0,
            )
        }
        job = AppGraph.appScope.launch {
            startTicker()
            try {
                val result = ApiClient.streamChat(
                    port = port, apiKey = key, model = model,
                    history = history, userText = clean, maxTokens = maxTokens)
                AppGraph.update { st ->
                    st.copy(
                        chat = replaceLast(st.chat, result.text.ifEmpty { "（模型没有输出内容）" }),
                        streaming = false, firstTokenMs = result.firstTokenMs, tps = result.tps,
                    )
                }
                AppGraph.logs.info("生成完成：首 token ${result.firstTokenMs}ms · ${"%.1f".format(result.tps)} tok/s")
            } catch (e: CancellationException) {
                AppGraph.update { st -> st.copy(chat = dropEmptyTail(st.chat), streaming = false) }
                throw e
            } catch (e: Exception) {
                AppGraph.update { st ->
                    st.copy(chat = replaceLast(st.chat, "调用失败：${friendly(e)}"), streaming = false)
                }
                AppGraph.logs.error("对话失败：${friendly(e)}")
            } finally {
                stopTicker()
                job = null
            }
        }
    }

    /** Retry the last message without retyping. */
    fun retry() {
        if (busy || lastUserText.isBlank()) return
        val s = AppGraph.ui.value
        // Drop the last user+assistant pair, then re-send.
        var list = s.chat
        if (list.lastOrNull()?.role == "assistant") list = list.dropLast(1)
        if (list.lastOrNull()?.role == "user") list = list.dropLast(1)
        AppGraph.update { it.copy(chat = list) }
        send(lastUserText)
    }

    fun cancel() {
        job?.cancel()
        job = null
        stopTicker()
        AppGraph.update { st -> st.copy(chat = dropEmptyTail(st.chat), streaming = false) }
    }

    private fun startTicker() {
        stopTicker()
        val t0 = System.currentTimeMillis()
        ticker = AppGraph.appScope.launch {
            while (true) {
                delay(250)
                if (!busy) break
                AppGraph.update { it.copy(progressMs = System.currentTimeMillis() - t0) }
            }
        }
    }

    private fun stopTicker() {
        ticker?.cancel()
        ticker = null
    }

    private fun replaceLast(list: List<ChatLine>, text: String): List<ChatLine> {
        val last = list.lastOrNull()
        return if (last != null && last.role == "assistant")
            list.dropLast(1) + ChatLine("assistant", text)
        else list + ChatLine("assistant", text)
    }

    private fun dropEmptyTail(list: List<ChatLine>): List<ChatLine> {
        val last = list.lastOrNull()
        return if (last != null && last.role == "assistant" && last.text.isEmpty())
            list.dropLast(1) else list
    }

    private fun friendly(e: Exception): String {
        val m = e.message ?: e.javaClass.simpleName
        return when {
            m.contains("coroutine", true) -> "请求已被取消"
            m.contains("timeout", true) || m.contains("timed out", true) -> "生成超时，可切「省电」档或缩短问题"
            m.contains("503", true) -> "模型未就绪，请检查控制台日志（可能已后台卸载）"
            m.contains("401", true) -> "密钥不匹配，请重置密钥后重试"
            m.contains("ConnectException", true) || m.contains("ECONNREFUSED", true) -> "本地服务未启动"
            else -> m.take(160)
        }
    }
}
