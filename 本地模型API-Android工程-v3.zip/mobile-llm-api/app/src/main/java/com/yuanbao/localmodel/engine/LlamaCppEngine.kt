package com.yuanbao.localmodel.engine

import com.yuanbao.localmodel.core.BenchResult
import com.yuanbao.localmodel.core.PerfPolicy
import com.yuanbao.localmodel.server.LocalApiServer
import com.yuanbao.localmodel.util.LogBus
import java.io.File

/**
 * Real GGUF inference. All performance-relevant knobs come from one PerfPolicy.
 * Chat formatting prefers the template embedded in the GGUF itself.
 *
 * Thread-safety is NOT implemented here on purpose: ModelSlot serializes every
 * generate() call and every hot-swap on one lock. One context, one decode at a time.
 */
class LlamaCppEngine(
    private val modelPath: String,
    private val policy: PerfPolicy,
    private val templateId: String = "auto",
    private val log: LogBus? = null,
) : LocalApiServer.Engine {

    companion object {
        @Volatile
        var available: Boolean = false
            private set
        private var loadError: String = ""

        init {
            try {
                System.loadLibrary("llama_jni")
                available = true
            } catch (t: Throwable) {
                loadError = t.message ?: t.javaClass.simpleName
                available = false
            }
        }

        fun reason() = loadError
        private const val SEP = "\u0001"
    }

    private var handle: Long = 0L
    private val id = File(modelPath).nameWithoutExtension

    // ---- JNI surface (native-llama/llama_jni.cpp) ----
    private external fun nativeLoad(
        path: String, threads: Int, ctx: Int, kvK: String, kvV: String,
        batch: Int, ubatch: Int, flash: Boolean, affinityMask: String,
    ): Long

    private external fun nativeFree(handle: Long)
    private external fun nativeWarmup(handle: Long)
    private external fun nativeRenderChat(handle: Long, flat: String): String?
    private external fun nativeTokenCount(handle: Long, text: String): Int
    private external fun nativeGenerate(
        handle: Long, prompt: String, maxTokens: Int, temperature: Float,
        topP: Float, jniBatch: Int, sink: LocalApiServer.TokenSink,
    ): Int

    /** Returns "ppTps|tgTps|peakMb" measured on a throwaway context. */
    private external fun nativeBenchmark(handle: Long, pp: Int, tg: Int, warmup: Int): String?

    fun load() {
        check(available) { "未找到 libllama_jni.so：${reason()}" }
        handle = nativeLoad(
            modelPath, policy.threads, policy.ctxSize,
            policy.kvK, policy.kvV, policy.nBatch, policy.nUbatch,
            policy.flashAttn, policy.affinityMask,
        )
        check(handle != 0L) { "模型加载失败：内存不足 / 文件损坏 / 参数组合不被支持" }
    }

    /** Throwaway context warms mmap pages + CPU backend without polluting the main KV. */
    fun warmup() {
        if (handle != 0L) nativeWarmup(handle)
    }

    /** User starts typing → trigger a light warmup ahead of the actual request. */
    fun preBoost() {
        if (handle != 0L && policy.warmup) try { nativeWarmup(handle) } catch (t: Throwable) { }
    }

    fun benchmark(pp: Int, tg: Int, warmup: Int): BenchResult {
        if (handle == 0L) return BenchResult.unsupported("模型未加载")
        val raw = nativeBenchmark(handle, pp, tg, warmup)
            ?: return BenchResult.unsupported("当前 llama.cpp 构建不支持测速")
        val parts = raw.split("|")
        if (parts.size < 3) return BenchResult.unsupported("测速返回格式异常")
        return BenchResult(
            supported = true,
            ppTps = parts[0].toDoubleOrNull() ?: 0.0,
            tgTps = parts[1].toDoubleOrNull() ?: 0.0,
            peakMb = parts[2].toLongOrNull() ?: 0L,
            threads = policy.threads,
            ctx = policy.ctxSize,
            note = "PP ${pp} / TG ${tg} / 预热 ${warmup}",
        )
    }

    fun close() {
        if (handle != 0L) {
            try { nativeFree(handle) } catch (t: Throwable) { log?.warn("释放模型：${t.message}") }
            handle = 0L
        }
    }

    override fun modelId() = id
    override fun isLoaded() = handle != 0L

    override fun generate(prompt: LocalApiServer.Prompt, sink: LocalApiServer.TokenSink): Int {
        check(handle != 0L) { "模型未加载" }
        return nativeGenerate(
            handle, render(prompt), prompt.maxTokens,
            prompt.temperature.toFloat(), prompt.topP.toFloat(),
            policy.jniBatchTokens, sink,
        )
    }

    override fun estimatePromptTokens(prompt: LocalApiServer.Prompt): Int {
        val text = render(prompt)
        if (handle == 0L) return text.length / 3
        return try { nativeTokenCount(handle, text) } catch (t: Throwable) { text.length / 3 }
    }

    /**
     * "auto" asks llama.cpp for llama_model_chat_template() and applies it with
     * llama_chat_apply_template(). Covers Qwen / Llama3 / Gemma / Phi / Mistral
     * without hard-coding per-model strings in Kotlin.
     */
    private fun render(p: LocalApiServer.Prompt): String {
        if (templateId == "auto" && handle != 0L) {
            try {
                val flat = buildString {
                    for (m in p.messages) append(m.role).append(SEP).append(m.content).append(SEP)
                }
                val built = nativeRenderChat(handle, flat)
                if (!built.isNullOrBlank()) return built
            } catch (t: Throwable) {
                log?.warn("GGUF 自带模板不可用，回退本地模板")
            }
        }
        return localRender(p, templateId)
    }

    private fun localRender(p: LocalApiServer.Prompt, tpl: String): String = when (tpl) {
        "raw" -> p.messages.lastOrNull { it.role == "user" }?.content ?: ""
        "llama3" -> buildString {
            append("<|begin_of_text|>")
            for (m in p.messages) {
                append("<|start_header_id|>").append(m.role)
                    .append("<|end_header_id|>\n\n").append(m.content).append("<|eot_id|>")
            }
            append("<|start_header_id|>assistant<|end_header_id|>\n\n")
        }
        "gemma" -> buildString {
            append("<bos>")
            for (m in p.messages) {
                val tag = if (m.role == "user") "user" else "model"
                append("<start_of_turn>").append(tag).append('\n')
                    .append(m.content).append("<end_of_turn>\n")
            }
            append("<start_of_turn>model\n")
        }
        "phi" -> buildString {
            for (m in p.messages) {
                val tag = if (m.role == "user") "user" else "assistant"
                append("<|").append(tag).append("|>\n").append(m.content).append("<|end|>\n")
            }
            append("<|assistant|>\n")
        }
        else -> buildString {
            for (m in p.messages) {
                append("<|im_start|>").append(m.role).append('\n')
                    .append(m.content).append("<|im_end|>\n")
            }
            append("<|im_start|>assistant\n")
        }
    }
}
