package com.yuanbao.localmodel.util

import com.yuanbao.localmodel.server.LocalApiServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Throttled log bus. Under streaming, the server emits several lines per second;
 * emitting a brand-new 200-item List on every line used to recomposition the
 * entire screen. Batching at 100ms collapses that to ~10 UI updates per second.
 */
class LogBus(private val scope: CoroutineScope) : LocalApiServer.LogSink {
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines.asStateFlow()
    private val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val lock = Any()
    private val pending = ArrayList<String>()
    private var flushJob: Job? = null

    override fun log(level: String, message: String) {
        val line = "${stamp.format(Date())}  $level  $message"
        synchronized(lock) {
            pending.add(line)
            if (flushJob == null) {
                flushJob = scope.launch {
                    delay(100)
                    flush()
                }
            }
        }
    }

    private fun flush() {
        val batch: List<String>
        synchronized(lock) {
            batch = ArrayList(pending)
            pending.clear()
            flushJob = null
        }
        if (batch.isNotEmpty()) _lines.value = (_lines.value + batch).takeLast(200)
    }

    fun info(msg: String) = log("INFO", msg)
    fun warn(msg: String) = log("WARN", msg)
    fun error(msg: String) = log("ERROR", msg)

    fun clear() {
        synchronized(lock) {
            pending.clear()
            flushJob?.cancel()
            flushJob = null
        }
        _lines.value = emptyList()
    }
}
