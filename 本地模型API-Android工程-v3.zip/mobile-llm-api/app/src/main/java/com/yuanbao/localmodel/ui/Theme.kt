package com.yuanbao.localmodel.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Brand = Color(0xFF4C8DFF)
private val Bg = Color(0xFF0D1117)
private val Surface = Color(0xFF161B22)
private val OnSurface = Color(0xFFE6EDF3)
private val Muted = Color(0xFF8B949E)

private val Scheme = darkColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    secondary = Color(0xFF3FB950),
    background = Bg,
    onBackground = OnSurface,
    surface = Surface,
    onSurface = OnSurface,
    surfaceVariant = Color(0xFF21262D),
    onSurfaceVariant = Muted,
    error = Color(0xFFF85149),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Scheme,
        typography = Typography(),
        content = content,
    )
}
