# ---- JNI bridge (optional llama.cpp engine) ----
-keepclasseswithmembernames class * { native <methods>; }
-keep class com.yuanbao.localmodel.engine.LlamaCppEngine { *; }

# ---- Server core uses hand-written JSON, no reflection ----
-keep class com.yuanbao.localmodel.server.LocalApiServer$* { *; }

# ---- Compose ----
-dontwarn androidx.compose.**
-keep class kotlin.Metadata { *; }

# ---- Never log or serialize secrets ----
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
}
