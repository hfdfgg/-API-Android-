# 变更日志

## v3（对照 PocketPal / llama.rn 重构）

调研 `a-ghorbani/pocketpal-ai` 四层架构、`llama.rn` 的 `NativeContextParams`、其 `activeModelService` / `ModelStore` 生命周期与 `llama-bench` 测速方法后落地。

**修掉会真闪退的问题**
- **KV 参数兼容**：llama.cpp 在「V cache 量化 + 未启用 FlashAttention」时加载直接 abort（SIGABRT）。v2 同时把 `type_k`/`type_v` 设为 `q8_0` 却没开 FA。现改为 K 量化、V 恒 F16；`ParamValidator` 在 Kotlin 侧 + JNI 硬兜底双重校验。
- **并发生成**：`llama_context` 非线程安全，v2 的并发请求会同时 decode 同一 context。新增 `ModelSlot` 单例 + `ReentrantLock` + `Serialized` 引擎，生成与热切换共用一把锁。

**不卡的关键改动**
- **热切换模型**：`ACTION_SWAP_MODEL` 只调 `server.setEngine()`，端口 / API Key / 公网隧道地址全不变，不再「切一下卡一下」。
- **内存优先加载**：`size × 1.5` 预估、`60% RAM` 预算、机型分档建议；超预算阻止加载，避免 OOM 被杀。
- **3 档降级重试**：极速档失败 → K-only → F16 + 小 ctx + 少线程，任何一档成功即运行，不再直接伪装成自检引擎。
- **Auto Offload / Load**：后台释放 context（服务仍在线），回前台自动重载；冷启动绝不隐式拉起前台服务。
- **CPU 大核亲和**：JNI `sched_setaffinity` 在 context 创建前绑核，ggml 工作线程继承 mask，消除 EAS 迁移 / DVFS 升频滞后造成的首 token 抖动；输入时 3 秒节流的预升频。
- **唤醒锁精细化**：从「常驻 1 小时」改为仅推理期间持有（`GenerateLifecycle`），空闲立即释放。
- **日志节流**：100ms 批量合并，不再每行 emit 一个 200 项新 List 触发整页重组。
- **超长 prompt**：截断为 BOS + 最近内容，不再返回空输出。

**把「卡」量化**
- 新增 `POST /v1/benchmark`：PP 512 / TG 128 / 16-token 预热，独立 context，返回 `pp_tps` / `tg_tps` / `peak_mb` / 配置；控制台一键测速并给评级。
- 对话页显示生成计时、复制、重试；性能档位说明实时展示当前策略。

**验证**
- 协议 28 → 33 项（新增 benchmark 401 / 501 / 200 / 参数 clamp）。
- 静态 27 → 42 项（新增 15 条 v3 防回归约束）。
- 两组均 0 失败。

## v2（真机截图反馈修复）

**修复**
- 对话请求从 `rememberCoroutineScope()` 移到 `AppGraph.appScope`：切换 Tab / 旋转 / 离开页面不再产生 `The coroutine scope left the composition`，也不会误报「对话失败」。
- `CallerRunsPolicy` 改为 `AbortPolicy` + 结构化 503：并发满载不再让慢推理占用 accept 线程。
- `usage.completion_tokens` 改用 `Engine.generate()` 返回的真实 token 数，不再用 SSE 写入次数冒充。
- 修复 `parse_chat` 中 vector 扩容导致 `c_str()` 悬空的潜在崩溃。
- `llama_chat_apply_template` 长度探测改用非空缓冲，兼容不同上游实现。

**性能（加速器）**
- 新增 `core/AppCore.kt`：统一常量、设备画像（大核数/内存/ABI/Android 版本）、三档 `PerfPolicy`、多模型格式识别。
- KV cache `q8_0` 量化、独立 context 预热、大核自适应线程、低内存自动降级。
- JNI 6 token 微批回调、SSE 4 token / 24ms 微批写出；首片仍立即发送保持低首字节延迟。
- APP 默认 `max_tokens` 512 → 256；`Engine.generate` 返回真实 token 数用于 usage/tps 统计。
- 验证结果：SSE chunk 从 51 降到 16（48 token），协议层首字节 1.5ms。

**兼容性**
- `auto` 模板：读取 GGUF 自带 chat template，自动适配 Qwen / Llama3 / Gemma / Phi / Mistral 等；保留手写模板兜底。
- 多模型列表、切换、逐项删除；GGUF / LiteRT `.task` / TFLite / ONNX / MNN 格式识别与诚实路由。
- CMake 对所有 `.so` 加 16KB 页对齐（Android 15 新机）；`-Pabis=` 可扩展 `armeabi-v7a` / `x86_64`。
- 控制台新增「后台保活设置」一键跳转，应对 vivo / OPPO / 小米冻结前台服务。

**UI / 结构**
- 新增 `core/` 业务层与 `ChatController`，Composable 不再承载业务逻辑。
- 取消打字机：生成完成一次性回填，生成中显示占位，可取消。
- 日志页自适应高度、运行概览、中文排版；控制台新增加速器、设备画像、多模型、模板、公网、端口卡片。
- 状态卡片显示真实引擎标识、模型格式与当前性能策略。

**验证**
- 协议回归 26 → 28 项（新增微批合并、真实 token 计数）。
- 工程自检 13 → 27 项（新增 14 条防回归架构约束）。
- 两组检查均 0 失败，已接入 CI。

## v1

初版：Android 工程 + 零依赖 OpenAI 兼容服务端 + Cloudflare 隧道 + 最小权限 + 自动打包；协议 26 项、静态 13 项通过。
