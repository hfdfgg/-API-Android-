# 安全说明与威胁模型

## 资产

| 资产 | 存放位置 | 保护 |
| --- | --- | --- |
| API Key | `filesDir/api_key.txt`，`MODE_PRIVATE` | 不备份、不导出、不入日志、不进文档页、控制台可重置 |
| GGUF 模型 | APP 私有目录 | 不申请外部存储权限，其他应用读不到 |
| 推理内容 | 仅内存 / SSE 响应 | 不落盘、不写日志、不进分析统计 |

## 边界

- **回环**：`LocalApiServer` 默认绑定 `127.0.0.1`。只有用户主动打开「允许局域网访问」才改为 `0.0.0.0`。
- **公网**：永远经 Cloudflare Tunnel（或你自建的 HTTPS 反代）暴露，服务端本身不监听公网端口，不持有 TLS 私钥。
- **明文**：`network_security_config.xml` 只对 `127.0.0.1` / `localhost` 放行，其余一律强制 TLS；`usesCleartextTraffic=false`。

## 已实现的防护

- 所有 `/v1/*` 强制 Bearer Key；SHA-256 摘要 + `MessageDigest.isEqual` 常数时间比对。
- 每 Key 120 次/分钟限流；请求体 ≤ 1 MiB；请求头 ≤ 100 行；空闲 30s；`max_tokens` ≤ 2048；并发按性能档 2–8，满载用 `AbortPolicy` 返回结构化 503，绝不阻塞 accept 线程。
- 401 / 400 / 404 / 413 / 429 / 503 全部返回结构化 JSON，不回显密钥或请求头。
- 日志只记录方法、耗时、状态码；`Authorization` 头、请求正文、隧道 Token 均不写入，Token 在输出中被替换为 `***`。
- `OPTIONS` 预检、CORS 头、`X-Content-Type-Options` / `X-Frame-Options` / `Referrer-Policy` / `Cache-Control: no-store`。
- 二次加固建议：Cloudflare Access 策略（邮箱或 Service Token）、IP 访问规则、定期重置 Key。

## 不在防护范围内

- **拥有 API Key 的人**可以调用模型、看到推理结果。Key 等同于密码，请不要截图分享；泄露后立刻在控制台「重置密钥」。
- Quick 隧道的 `*.trycloudflare.com` 域名是随机公开的，靠「随机域名 + Bearer Key」双重保护；若需要长期稳定与身份管控，请用命名隧道 + Zero Trust Access。
- 手机被 root、或设备被物理接触并解锁，APP 私有目录不再可信——这是 Android 沙盒的边界。
- 厂商 ROM 的后台冻结、电池优化属于系统行为，不属于应用层安全控制。

## 报告问题

发现密钥泄露路径或鉴权绕过，请直接在仓库提 issue（不要贴真实 Key），并附上 `VERIFY_REPORT.md` 的复现命令。
