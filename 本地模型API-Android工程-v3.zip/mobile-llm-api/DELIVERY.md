# 交付状态（v3）

一句话：**照 PocketPal 的实现重学了一遍，挖出并修掉两个会真闪退的坑，把「卡」拆成崩溃、调度抖动、重启、OOM 四类分别处理；协议 33 项 + 工程 42 项全绿。真机端侧推理与公网连通仍需你复核。**

## 从 PocketPal 学到、并且我们确实做错的地方

1. **KV cache 参数不兼容 → 加载时 SIGABRT**。llama.cpp 要求「量化 V cache 必须开 FlashAttention」，v2 把 K、V 都设成 `q8_0` 却没开 FA。这在部分模型/上游版本上会直接 abort，表现就是「模型加载失败 / 闪退 / 卡住」。现在 K 量化、V 恒 F16，Kotlin + JNI 双重校验。
2. **同一个 `llama_context` 被并发 decode**。v2 允许多个请求同时推理，context 非线程安全 → 崩溃或乱码。PocketPal 用 `activeModelService` 单例 + mutex；我们用 `ModelSlot` + `ReentrantLock` 串行化。
3. **切模型要重启整个服务** → 隧道重连、地址/Key 全变。PocketPal 只换 context。现在 `ACTION_SWAP_MODEL` 只替换引擎。
4. **没有内存预检** → 大模型 OOM 被系统杀。现在 `size×1.5` vs `60% RAM` 预算 + 机型分档建议。
5. **一直持 WakeLock + 模型常驻后台** → 被国产 ROM 冻结。现在后台自动卸载、前台自动重载，唤醒锁只在推理期间持有。
6. **说不清「卡」在哪**。现在有 PP/TG 分离测速（PocketPal 用 llama-bench 同一套方法），能读出首 token 慢还是吐字慢。

## ✅ v3 新增（相对 v2）

| 项 | 落地 |
| --- | --- |
| 不崩 | K/V 分离 + FlashAttn 兼容校验 + 3 档加载降级重试 + 推理串行化 |
| 不抖 | JNI 绑大核 `sched_setaffinity`、输入时 3 秒节流预升频、100ms 日志合并 |
| 不重启 | 模型热切换：端口 / Key / 公网地址不变 |
| 不 OOM | 内存预检、机型分档建议、超预算阻止加载、后台自动卸载 |
| 能量化 | `/v1/benchmark` + 控制台测速卡（PP / TG / 峰值内存 / 评级） |
| 更顺 | 生成计时、复制、重试；唤醒锁精细化；超长 prompt 截断而非空输出 |

## ✅ 已跑通（可复现）

```bash
python3 scripts/static-check.py                              # 42 项，0 失败
python3 scripts/verify-protocol.py --report VERIFY_REPORT.md  # 33 项，0 失败
```

- 协议层真实启动 JVM 服务端（与 APK 内同一份 `LocalApiServer.java`），TCP 发 HTTP/SSE 请求，无 mock。
- 新增：benchmark 未鉴权 401 / 无槽位 501 / 注入钩子 200 / 参数 clamp。
- 静态层 42 项，其中 v2 14 条 + v3 15 条是**防回归架构约束**，改坏了 CI 直接失败。
- CI 每次 push 自动重跑两组，任一失败不出 APK。

## ⚠️ 仍需你在真机上复核

1. 重新 push 触发 Actions → 覆盖安装新 APK（保持 `with_llama=true`，否则没有 `libllama_jni.so`）。
2. 控制台点「开始测速」，看 PP / TG 两个数：TG ≥10 算流畅，<2 就是硬件/调度问题，不是代码还能再挤多少。
3. 导入/切换模型：观察公网地址与 API Key **有没有变**（应该不变，日志会写「热切换完成」）。
4. 对话发消息后切到日志页再切回、把 APP 退后台再回来：请求不中断，模型会自动卸载/重载。
5. 对比之前 46621ms 的那次，看 `首 token xx ms · xx tok/s`。
6. vivo / OPPO 记得点「后台保活设置」加白名单。

沙盒没有 Android SDK/NDK、没有真机、没有你的 Cloudflare 域名与 Token，所以这些不写成「已跑通」。

## 明确没做的

- 没有编译出真机 APK，没有真机 tok/s 实测数据
- LiteRT-LM / ONNX / MNN / ExecuTorch 只做格式识别与路由占位，**没有实现推理引擎**（PocketPal 现在也主要跑 GGUF，另测 LiteRT/ExecuTorch）
- 没有做 OpenCL/Vulkan GPU 后端：公开数据表明 Android 上对 decode 只快 20–40%，驱动碎片化严重，优先保证不崩不抖
- 没有「完整手机权限」——Android 沙盒边界，按最小必需权限实现
- 没有往你的仓库推代码，没有使用任何真实密钥或证书
